# Meirvo Client Reels: Cross-Account Setup Kit

This kit recreates the "Meirvo Client Reels" agent on a different hyperagent account. It contains everything portable: the agent's full system prompt, the 3 skills it depends on (docs + all scripts), and these instructions. Credentials and integrations do NOT transfer; they are re-entered on the target account (Step 3).

## Kit layout

```
meirvo-client-reels/
  SETUP.md                  <- you are here
  agent/
    system_prompt.md        <- VERBATIM system prompt, paste as-is, do not paraphrase
    agent_meta.json         <- name, description, icon, model settings, tool list
  skills/
    meirvo-video-pipeline-v3/   SKILL_DOC.md + 12 scripts
    hyperframes-bundle-v2/      SKILL_DOC.md + 3 scripts
    meirvo-delivery/            SKILL_DOC.md + 2 scripts
```

## Instructions for the assistant on the target account

You are recreating a production video agent. Follow these steps exactly.

### Step 1: Create the 3 skills

For EACH of the 3 directories under skills/:

1. Copy the script files into your workspace (e.g. `skills/{name}/` relative to your working directory).
2. Read SKILL_DOC.md. The HTML comment at the top contains the exact CreateSkill field values: name, description, whenToUse, tags, and credentialSchema. The body below the comment is the `documentation` field: pass it VERBATIM, do not summarize or rewrite it. Stale or paraphrased documentation causes production failures.
3. Call CreateSkill with those fields plus a `scripts` array listing every .py file with a one-line description (descriptions for each script are in the SKILL_DOC or can be read from the script docstrings).
4. credentialSchema notes:
   - meirvo-video-pipeline-v3: GEMINI_API_KEY, OPTIONAL password field. Do not require it.
   - hyperframes-bundle-v2: no credentials.
   - meirvo-delivery: MEIRVO_INTAKE_SHARED_SECRET, REQUIRED password field.

The user must confirm each skill draft card. Wait for all 3 to be saved before Step 2.

### Step 2: Create the agent

Call CreateAgentConfig with:

- name, description, icon: from agent/agent_meta.json
- systemPrompt: the ENTIRE contents of agent/system_prompt.md, verbatim
- modelSettings: { "modelId": "claude-opus-4-7", "effort": "high" }
- skills: the IDs of the 3 skills created in Step 1, plus the local "video-prompting" seed skill if this account has it (search the knowledge base; skip if absent, it is a nice-to-have)
- tools: enable native media generation and script execution. Tool IDs are platform-internal and invalid IDs fail SILENTLY, so shotgun kebab-case variants and let the platform keep the valid ones:
  [{"id":"generate-video","enabled":true},{"id":"generate-image","enabled":true},{"id":"generate-audio","enabled":true},{"id":"video-generation","enabled":true},{"id":"image-generation","enabled":true},{"id":"audio-generation","enabled":true},{"id":"media-generation","enabled":true},{"id":"execute-script","enabled":true}]

The user saves the agent from the config card.

### Step 3: Credentials (user does this, in the target account UI)

- On the meirvo-delivery skill: enter MEIRVO_INTAKE_SHARED_SECRET via the encrypted credential UI. It is the same value as the Cloudflare Worker's INTAKE_BUCKET_SHARED_SECRET. Never paste it into chat.
- GEMINI_API_KEY on the pipeline skill: skip. Production runs never need it.

### Step 4: Verify (MANDATORY, do not skip)

Open a new thread as the new agent. First message:

"List all tools you have access to. Confirm you have native GenerateVideo, GenerateAudio, and GenerateImage with image input support, not just Composio GEMINI variants."

- If native GenerateVideo with firstFrameImage support is surfaced: you are live.
- If only a Composio GEMINI_GENERATE_VIDEOS integration shows: the tool enablement failed silently. That variant is text-only and will produce a FAKE home instead of the listing. Fix: ask the agent itself to add the missing tools via its own UpdateAgentConfig (agents can introspect their real internal tool namespace), then save the card and re-verify.

### Step 5: First run notes

- The agent's brand pack is PENDING: supply the client's name and a transparent PNG logo in the thread before the first reel.
- Music: this kit does NOT include audio tracks. Supply a royalty-safe track per run (operator upload), or pull incompetech direct mp3s (CC BY 4.0, attribution in licenses.txt). The agent's audio rules handle the rest.
- The operator render loop needs a local machine with Node 22+, FFmpeg, and ~2GB disk (`unzip bundle.zip && ./render.sh`).
- Costs: ~$3 per Veo generation, ~$27 per 40s reel, billed to THIS account's hyperagent credits.

### Known per-account gotchas

- FetchSkillScripts corrupts binary files (fonts, images). All scripts in this kit are plain .py text, so they survive transit, but never add binary assets to these skills; scripts that need fonts bootstrap them from CDNs at runtime.
- Worker-side requirements (meirvo.com infra) are account-independent: bundle transit and delivery hit the same Cloudflare Worker regardless of which hyperagent account runs the agent.