#!/usr/bin/env python3
"""
meirvo-video-pipeline / stitch_reel.py

Master stitching script. Takes Veo clips + overlays + VO segments + music
mood → produces main_reel.mp4 (720x1280 H.264 @ 30fps).

Pipeline:
  1. For each shot: normalize clip to 720x1280 @ 30fps with blurred-letterbox
     fallback + overlay appropriate PNG at that time
  2. Concat all processed clips into reel_video_only.mp4
  3. Build VO track: pad each vo_NN.wav with silence to exact shot duration,
     concat into one WAV matching reel duration
  4. Build music bed: pick track by mood, loop+trim to reel duration
  5. Mix: VO (vol 1.3) + music (vol 0.22) + alimiter → final audio
  6. Mux final audio onto video → main_reel.mp4

Usage:
    python stitch_reel.py \\
        --shot-plan /path/to/shot_plan.json \\
        --clips-dir /path/to/clips/ \\
        --overlays-dir /path/to/overlays/ \\
        --vo-dir /path/to/vo/ \\
        --output /path/to/main_reel.mp4 \\
        [--music-library ~/workspace/music_library/]

Clip file naming convention: clip_01.mp4 ... clip_0N.mp4 (matching shot slots).
VO file naming convention: vo_01.wav ... vo_0N.wav.

Exit codes: 0 = success, 1 = usage/input error, 2 = ffmpeg failure.
"""

import argparse
import json
import os
import subprocess
import sys
import tempfile
import shutil
from pathlib import Path

import imageio_ffmpeg


FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
FFPROBE = None  # imageio-ffmpeg doesn't ship ffprobe, use ffmpeg -i instead
OUT_W = 720
OUT_H = 1280
# Veo 3.1 outputs at 24fps natively. Force-converting to 30fps on concat causes
# frame drops/dupes that read as stutter ("looks like 10fps"). Keep native 24.
FPS = 24

# Crossfade between clips (seconds). 0.15s is short enough to feel like a cut
# but enough to mask the Veo clip boundaries.
XFADE_S = 0.15

# Audio levels
VO_GAIN = 1.30
MUSIC_GAIN = 0.22
LIMITER_LEVEL = "0.95"  # ceiling for alimiter

# Default music fallback — first track, always available
DEFAULT_TRACK = "01_hopeful_corporate.wav"


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def run_ffmpeg(cmd: list, timeout: int = 600, label: str = "ffmpeg") -> None:
    """Run ffmpeg, raise RuntimeError on failure (include stderr tail)."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"{label}: timed out after {timeout}s")
    if result.returncode != 0:
        tail = result.stderr[-2500:] if result.stderr else "(no stderr)"
        raise RuntimeError(f"{label} failed (exit {result.returncode}):\n{tail}")


def resolve_music_track(music_library: Path, requested: str) -> Path:
    """Locate the music track file, falling back if missing."""
    candidate = music_library / requested
    if candidate.exists():
        return candidate
    eprint(f"  ! music track {requested} missing — falling back to {DEFAULT_TRACK}")
    fallback = music_library / DEFAULT_TRACK
    if not fallback.exists():
        raise RuntimeError(
            f"Music library missing at {music_library} "
            f"(neither '{requested}' nor '{DEFAULT_TRACK}' found). "
            f"Upload the 5 Icons8 Fugue tracks to {music_library}."
        )
    return fallback


def process_clip(
    clip_path: Path,
    duration_s: float,
    overlay_path: Path | None,
    out_path: Path,
) -> None:
    """Normalize one Veo clip to 720x1280 @ 30fps with blurred letterbox + optional overlay."""
    if overlay_path is None:
        # No overlay — simple normalize with blurred letterbox
        filter_complex = (
            f"[0:v]trim=duration={duration_s},setpts=PTS-STARTPTS,"
            f"fps={FPS},"
            f"scale={OUT_W}:{OUT_H}:force_original_aspect_ratio=decrease[fg];"
            f"[0:v]trim=duration={duration_s},setpts=PTS-STARTPTS,"
            f"scale={OUT_W}:{OUT_H}:force_original_aspect_ratio=increase,"
            f"crop={OUT_W}:{OUT_H},boxblur=40:3[bg];"
            f"[bg][fg]overlay=(W-w)/2:(H-h)/2:format=auto,"
            f"setsar=1,format=yuv420p,fps={FPS}[outv]"
        )
        cmd = [
            FFMPEG, "-y",
            "-i", str(clip_path),
            "-filter_complex", filter_complex,
            "-map", "[outv]",
            "-an",
            "-t", f"{duration_s}",
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "medium", "-crf", "19",
            "-r", str(FPS),
            str(out_path),
        ]
    else:
        # Normalize + overlay PNG (with fade in/out)
        fade_in = 0.3
        fade_out = 0.4
        fade_out_start = max(0.0, duration_s - fade_out)
        # Overlay is loaded with -loop 1; we explicitly trim it in the filter
        # to prevent the graph from running forever.
        filter_complex = (
            f"[0:v]trim=duration={duration_s},setpts=PTS-STARTPTS,"
            f"fps={FPS},"
            f"scale={OUT_W}:{OUT_H}:force_original_aspect_ratio=decrease[fg];"
            f"[0:v]trim=duration={duration_s},setpts=PTS-STARTPTS,"
            f"scale={OUT_W}:{OUT_H}:force_original_aspect_ratio=increase,"
            f"crop={OUT_W}:{OUT_H},boxblur=40:3[bg];"
            f"[bg][fg]overlay=(W-w)/2:(H-h)/2:format=auto,"
            f"setsar=1,format=yuv420p,fps={FPS}[base];"
            f"[1:v]trim=duration={duration_s},setpts=PTS-STARTPTS,"
            f"fps={FPS},format=rgba,"
            f"fade=in:st=0:d={fade_in}:alpha=1,"
            f"fade=out:st={fade_out_start:.2f}:d={fade_out}:alpha=1[ov];"
            f"[base][ov]overlay=0:0:shortest=1[outv]"
        )
        cmd = [
            FFMPEG, "-y",
            "-i", str(clip_path),
            "-loop", "1", "-i", str(overlay_path),
            "-filter_complex", filter_complex,
            "-map", "[outv]",
            "-an",
            "-t", f"{duration_s}",
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "medium", "-crf", "19",
            "-r", str(FPS),
            str(out_path),
        ]

    run_ffmpeg(cmd, timeout=180, label=f"process_clip({clip_path.name})")


def xfade_clips(clip_paths: list, durations: list, out_path: Path) -> float:
    """Chain N processed clips with xfade transitions between each pair.

    Returns the output reel duration (seconds) after xfade accumulation.
    For N clips of durations [d0,d1,...,dN-1], the xfaded total is:
        sum(durations) - (N-1) * XFADE_S
    """
    n = len(clip_paths)
    total_dur = sum(durations) - max(0, n - 1) * XFADE_S

    if n == 1:
        # Single clip — just copy
        cmd = [FFMPEG, "-y", "-i", str(clip_paths[0]), "-c", "copy", str(out_path)]
        run_ffmpeg(cmd, timeout=60, label="xfade_single")
        return total_dur

    # Build xfade filter chain. `offset` is measured from the start of the
    # accumulated output, which grows by (dur[i] - XFADE_S) each step.
    inputs = []
    for p in clip_paths:
        inputs += ["-i", str(p)]

    filter_parts = []
    # First xfade bridges clip 0 and clip 1
    offset = durations[0] - XFADE_S
    last_label = "0:v"
    for i in range(1, n):
        next_label = f"vx{i}" if i < n - 1 else "vout"
        filter_parts.append(
            f"[{last_label}][{i}:v]xfade=transition=fade:duration={XFADE_S}:"
            f"offset={offset:.3f}[{next_label}]"
        )
        last_label = next_label
        if i < n - 1:
            # Next offset: add this clip's duration minus one more xfade
            offset += durations[i] - XFADE_S
    filter_complex = ";".join(filter_parts)

    cmd = [FFMPEG, "-y"] + inputs + [
        "-filter_complex", filter_complex,
        "-map", "[vout]",
        "-an",
        "-c:v", "libx264", "-pix_fmt", "yuv420p",
        "-preset", "medium", "-crf", "19",
        str(out_path),
    ]
    run_ffmpeg(cmd, timeout=600, label="xfade_chain")
    return total_dur


def build_vo_track(vo_paths: list, shot_durations: list, out_path: Path, tmp_dir: Path) -> None:
    """Pad each VO segment to its effective (post-xfade) shot duration, then concat.

    Critical: xfade between clips overlaps XFADE_S seconds. Each clip except the
    last has its tail overlapped by the next clip's head. So the effective
    on-screen duration of clip i (for i < N-1) is (shot_durations[i] - XFADE_S).
    The last clip plays its full duration.

    If we pad VO segments to raw shot_durations, the VO track is longer than
    the xfaded video and amix=shortest truncates the last line abruptly.
    """
    n = len(vo_paths)
    effective_durations = []
    for i, dur in enumerate(shot_durations):
        if i < n - 1:
            effective_durations.append(max(0.1, dur - XFADE_S))
        else:
            effective_durations.append(dur)

    padded_paths = []
    for i, (vo_path, effective_dur, raw_dur) in enumerate(
            zip(vo_paths, effective_durations, shot_durations)):
        padded = tmp_dir / f"vo_padded_{i+1:02d}.wav"
        if vo_path is None or not Path(vo_path).exists():
            # Generate pure silence if VO missing
            cmd = [
                FFMPEG, "-y",
                "-f", "lavfi", "-i", f"anullsrc=channel_layout=mono:sample_rate=24000",
                "-t", f"{effective_dur}",
                "-c:a", "pcm_s16le",
                str(padded),
            ]
        else:
            # Pad VO to effective (post-xfade) duration with silence tail
            # apad=whole_dur ensures output is exactly effective_dur long,
            # even if the source TTS is shorter
            cmd = [
                FFMPEG, "-y",
                "-i", str(vo_path),
                "-af", (
                    f"apad=whole_dur={effective_dur},"
                    f"atrim=duration={effective_dur},"
                    f"asetpts=PTS-STARTPTS"
                ),
                "-ar", "24000", "-ac", "1", "-c:a", "pcm_s16le",
                str(padded),
            ]
        run_ffmpeg(cmd, timeout=60, label=f"vo_pad({i+1})")
        padded_paths.append(padded)

    concat_list = tmp_dir / "vo_concat.txt"
    with open(concat_list, "w") as f:
        for p in padded_paths:
            f.write(f"file '{p.resolve()}'\n")

    cmd = [
        FFMPEG, "-y",
        "-f", "concat", "-safe", "0",
        "-i", str(concat_list),
        "-c:a", "pcm_s16le",
        "-ar", "24000", "-ac", "1",
        str(out_path),
    ]
    run_ffmpeg(cmd, timeout=60, label="vo_concat")


def build_music_bed(music_path: Path, reel_duration_s: float, out_path: Path) -> None:
    """Loop music if needed, trim to reel duration, convert to 24kHz mono WAV."""
    cmd = [
        FFMPEG, "-y",
        "-stream_loop", "-1",
        "-i", str(music_path),
        "-t", f"{reel_duration_s}",
        "-af", f"afade=in:st=0:d=0.8,afade=out:st={max(0, reel_duration_s - 1.2):.2f}:d=1.2",
        "-ar", "24000", "-ac", "1", "-c:a", "pcm_s16le",
        str(out_path),
    ]
    run_ffmpeg(cmd, timeout=60, label="music_bed")


def mix_audio(vo_wav: Path, music_wav: Path, out_path: Path) -> None:
    """Mix VO + music with gain + alimiter."""
    cmd = [
        FFMPEG, "-y",
        "-i", str(vo_wav),
        "-i", str(music_wav),
        "-filter_complex",
        (
            f"[0:a]volume={VO_GAIN}[vo_a];"
            f"[1:a]volume={MUSIC_GAIN}[m_a];"
            f"[vo_a][m_a]amix=inputs=2:duration=shortest:normalize=0[mixed];"
            f"[mixed]alimiter=level_in=1.0:level_out={LIMITER_LEVEL}:limit=0.95:attack=5:release=50[a_out]"
        ),
        "-map", "[a_out]",
        "-c:a", "pcm_s16le", "-ar", "24000", "-ac", "2",
        str(out_path),
    ]
    run_ffmpeg(cmd, timeout=90, label="mix_audio")


def mux_final(video_in: Path, audio_in: Path, out_path: Path) -> None:
    """Mux final audio onto concatenated video."""
    cmd = [
        FFMPEG, "-y",
        "-i", str(video_in),
        "-i", str(audio_in),
        "-map", "0:v:0", "-map", "1:a:0",
        "-c:v", "copy",
        "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
        "-shortest",
        "-movflags", "+faststart",
        str(out_path),
    ]
    run_ffmpeg(cmd, timeout=120, label="mux_final")


def main():
    p = argparse.ArgumentParser(description="Stitch Veo clips + overlays + VO + music into main reel")
    p.add_argument("--shot-plan", required=True, help="Path to shot_plan.json")
    p.add_argument("--clips-dir", required=True, help="Directory with clip_01.mp4 ... clip_0N.mp4")
    p.add_argument("--overlays-dir", required=True, help="Directory with PNG overlays")
    p.add_argument("--vo-dir", required=True, help="Directory with vo_01.wav ... vo_0N.wav")
    p.add_argument("--output", required=True, help="Output MP4 path (main_reel.mp4)")
    p.add_argument("--music-library", default="~/workspace/music_library",
                   help="Music library directory (default ~/workspace/music_library)")
    p.add_argument("--keep-tmp", action="store_true", help="Keep temp files for debugging")
    args = p.parse_args()

    # ── Load + validate inputs ──
    shot_plan_path = Path(args.shot_plan).expanduser()
    try:
        plan = json.loads(shot_plan_path.read_text(encoding="utf-8"))
    except Exception as e:
        eprint(f"error: could not read shot_plan.json: {e}")
        sys.exit(1)

    shots = plan.get("shots", [])
    if not shots:
        eprint("error: shot plan has no shots")
        sys.exit(1)

    clips_dir = Path(args.clips_dir).expanduser()
    overlays_dir = Path(args.overlays_dir).expanduser()
    vo_dir = Path(args.vo_dir).expanduser()
    music_library = Path(args.music_library).expanduser()
    out_path = Path(args.output).expanduser()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Verify every shot has a clip file
    clip_paths = []
    for shot in shots:
        slot = shot["slot_number"]
        expected = clips_dir / f"clip_{slot:02d}.mp4"
        if not expected.exists():
            eprint(f"error: missing clip {expected}")
            sys.exit(1)
        clip_paths.append(expected)

    # Resolve overlay PNGs per shot
    overlay_paths = []
    for shot in shots:
        key = shot.get("overlay_key")
        if key:
            opath = overlays_dir / f"{key}.png"
            if not opath.exists():
                eprint(f"error: missing overlay {opath}")
                sys.exit(1)
            overlay_paths.append(opath)
        else:
            overlay_paths.append(None)

    # Resolve VO paths
    vo_paths = []
    for shot in shots:
        slot = shot["slot_number"]
        vo = vo_dir / f"vo_{slot:02d}.wav"
        vo_paths.append(vo if vo.exists() else None)

    shot_durations = [shot["duration_s"] for shot in shots]
    reel_duration = sum(shot_durations)

    # Resolve music track
    requested_track = plan.get("music_track", DEFAULT_TRACK)
    music_track = resolve_music_track(music_library, requested_track)
    eprint(f"music: {music_track.name}")
    eprint(f"reel duration: {reel_duration:.2f}s over {len(shots)} shots")

    # ── Work in a temp directory ──
    tmp_dir = Path(tempfile.mkdtemp(prefix="meirvo_stitch_"))
    eprint(f"tmp dir: {tmp_dir}")

    try:
        # Step 1: process each clip (normalize + overlay)
        processed_clips = []
        for i, (clip_path, overlay, duration) in enumerate(
                zip(clip_paths, overlay_paths, shot_durations)):
            slot = i + 1
            proc_out = tmp_dir / f"proc_{slot:02d}.mp4"
            eprint(f"  [{slot}/{len(shots)}] processing {clip_path.name}"
                   f"{' + ' + overlay.name if overlay else ''} ({duration}s)")
            process_clip(clip_path, duration, overlay, proc_out)
            processed_clips.append(proc_out)

        # Step 2: xfade chain processed clips
        reel_video = tmp_dir / "reel_video_only.mp4"
        eprint(f"  xfade chain {len(processed_clips)} processed clip(s) → reel_video_only.mp4")
        actual_video_duration = xfade_clips(processed_clips, shot_durations, reel_video)
        eprint(f"  video-only reel duration after xfade: {actual_video_duration:.2f}s")

        # Step 3: build VO track (use raw shot durations; we'll trim to video dur later)
        vo_track = tmp_dir / "vo_track.wav"
        eprint("  building VO track (padded + concat)")
        build_vo_track(vo_paths, shot_durations, vo_track, tmp_dir)

        # Step 4: build music bed — match the actual (xfaded) video duration
        music_bed = tmp_dir / "music_bed.wav"
        eprint(f"  building music bed ({actual_video_duration:.2f}s looped + trimmed + faded)")
        build_music_bed(music_track, actual_video_duration, music_bed)

        # Step 5: mix audio
        mixed_audio = tmp_dir / "mixed_audio.wav"
        eprint("  mixing VO + music + alimiter")
        mix_audio(vo_track, music_bed, mixed_audio)

        # Step 6: mux
        eprint(f"  mux final → {out_path}")
        mux_final(reel_video, mixed_audio, out_path)

        eprint(f"  ✓ wrote {out_path} ({out_path.stat().st_size:,} bytes)")
        print(json.dumps({
            "output": str(out_path.resolve()),
            "duration_s": reel_duration,
            "n_shots": len(shots),
            "music_track": music_track.name,
            "bytes": out_path.stat().st_size,
        }, indent=2))

    except RuntimeError as e:
        eprint(f"error: {e}")
        sys.exit(2)
    finally:
        if not args.keep_tmp:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        else:
            eprint(f"kept temp dir: {tmp_dir}")


if __name__ == "__main__":
    main()
