#!/usr/bin/env python3
"""
meirvo-video-pipeline / prep_audio.py  (v5)

Deterministic loudness prep so the final mix lands the same way every run.
Run AFTER generating narration (GenerateAudio) and selecting music, BEFORE
build_meirvo_bundle.py.

v5 change: the music is no longer buried. v4 parked it at -28 LUFS for the
whole reel, which read as background wallpaper. Fast-cut reels are music-
forward: the bed now sits at -20 LUFS and DUCKS under the narration window,
then comes back up for the back half of the reel.

What it does:
  narration (VO):
    - loudness-normalize to -16 LUFS integrated, true peak -1.5 dBTP
    - resample 48 kHz stereo
    -> {out_dir}/tts.wav
  music bed:
    - loudness-normalize to -20 LUFS integrated
    - duck by --duck-db (default 8 dB) under the narration window with
      smooth ramps (0.4s down ending at VO start, 0.9s up after VO ends)
    - trim to exactly --total seconds
    - bake 0.5s fade-in and --fade-out (default 2.8s) fade-out
    -> {out_dir}/music.wav

The bundle runs both tracks at volume 1.0; qc_bundle.py verifies VO -16,
music -20 on the open (post-VO) section, and the duck depth.

Usage:
  python3 prep_audio.py --vo narration_raw.wav --music track.wav \\
      --out-dir ~/workspace/{sessionId} [--total 40.0] [--tts-start 1.6]
  (omit --vo for a music-only reel: no duck is applied)
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

VO_LUFS = -16.0
MUSIC_LUFS = -20.0
TRUE_PEAK = -1.5


def get_ffmpeg() -> str:
    found = shutil.which("ffmpeg")
    if found:
        return found
    try:
        import imageio_ffmpeg  # type: ignore
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "imageio-ffmpeg"], check=True)
        import imageio_ffmpeg  # type: ignore
    return imageio_ffmpeg.get_ffmpeg_exe()


def run(ff: str, args: list[str]) -> str:
    proc = subprocess.run([ff, *args], capture_output=True, text=True)
    if proc.returncode != 0:
        raise SystemExit(f"ffmpeg failed: {' '.join(args[:8])}...\n{proc.stderr[-1500:]}")
    return proc.stderr + proc.stdout


def measure_lufs(ff: str, path: Path, ss: float | None = None, t: float | None = None) -> float | None:
    cmd = ["-nostats"]
    if ss is not None:
        cmd += ["-ss", f"{ss:.3f}"]
    if t is not None:
        cmd += ["-t", f"{t:.3f}"]
    cmd += ["-i", str(path), "-af", "ebur128", "-f", "null", "-"]
    proc = subprocess.run([ff, *cmd], capture_output=True, text=True)
    matches = re.findall(r"I:\s*(-?\d+(?:\.\d+)?)\s*LUFS", proc.stderr + proc.stdout)
    return float(matches[-1]) if matches else None


def duration_of(ff: str, path: Path) -> float:
    proc = subprocess.run([ff, "-i", str(path)], capture_output=True, text=True)
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.?\d*)", proc.stderr)
    if not m:
        return 0.0
    return float(m.group(1)) * 3600 + float(m.group(2)) * 60 + float(m.group(3))


def normalize(ff: str, src: Path, dst: Path, target_lufs: float) -> None:
    run(ff, [
        "-y", "-i", str(src),
        "-af", f"loudnorm=I={target_lufs}:TP={TRUE_PEAK}:LRA=11",
        "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le",
        str(dst),
    ])


def duck_expr(vo_start: float, vo_end: float, duck_gain: float) -> str:
    """Piecewise gain envelope: 1.0 -> duck_gain under VO -> 1.0.

    Ramp down over 0.4s ending at vo_start; hold; ramp up over 0.9s
    starting 0.3s after vo_end.
    """
    a = max(vo_start - 0.4, 0.0)   # ramp-down start
    b = vo_start                    # duck reached
    c = vo_end + 0.3                # ramp-up start
    d = vo_end + 1.2                # back to full
    g = duck_gain
    return (
        f"volume='if(lt(t,{a:.3f}),1,"
        f"if(lt(t,{b:.3f}),1-{1 - g:.4f}*(t-{a:.3f})/{b - a:.3f},"
        f"if(lt(t,{c:.3f}),{g:.4f},"
        f"if(lt(t,{d:.3f}),{g:.4f}+{1 - g:.4f}*(t-{c:.3f})/{d - c:.3f},1))))':eval=frame"
    )


def main() -> int:
    p = argparse.ArgumentParser(description="Normalize + shape reel audio (Meirvo v5)")
    p.add_argument("--vo", help="Raw narration wav/mp3 (optional for music-only reels)")
    p.add_argument("--music", required=True, help="Raw music track")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--total", type=float, default=40.0, help="Reel total seconds (music trimmed to this)")
    p.add_argument("--tts-start", type=float, default=1.6,
                   help="Narration timeline start (must match build_meirvo_bundle --tts-start)")
    p.add_argument("--duck-db", type=float, default=8.0, help="Music duck depth under narration (dB)")
    p.add_argument("--no-duck", action="store_true", help="Skip ducking even when --vo is given")
    p.add_argument("--music-lufs", type=float, default=MUSIC_LUFS)
    p.add_argument("--fade-in", type=float, default=0.5)
    p.add_argument("--fade-out", type=float, default=2.8,
                   help="Music tail fade. With a 3.0s end card the music hits the final cut "
                        "at full energy and decays over the black card.")
    args = p.parse_args()

    ff = get_ffmpeg()
    out_dir = Path(args.out_dir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)
    report: dict = {"total_s": args.total}

    vo_dur = None
    if args.vo:
        vo_src = Path(args.vo).expanduser()
        vo_dst = out_dir / "tts.wav"
        normalize(ff, vo_src, vo_dst, VO_LUFS)
        vo_dur = duration_of(ff, vo_dst)
        report["vo"] = {
            "out": str(vo_dst),
            "duration_s": round(vo_dur, 2),
            "lufs": measure_lufs(ff, vo_dst),
            "target": VO_LUFS,
            "timeline_start": args.tts_start,
            "timeline_end": round(args.tts_start + vo_dur, 2),
        }

    music_src = Path(args.music).expanduser()
    music_norm = out_dir / ".music_norm_tmp.wav"
    music_dst = out_dir / "music.wav"
    normalize(ff, music_src, music_norm, args.music_lufs)

    filters = []
    duck = None
    if vo_dur and not args.no_duck:
        vo_start = args.tts_start
        vo_end = args.tts_start + vo_dur
        duck_gain = 10 ** (-abs(args.duck_db) / 20.0)
        filters.append(duck_expr(vo_start, vo_end, duck_gain))
        duck = {"depth_db": abs(args.duck_db), "window": [round(vo_start, 2), round(vo_end, 2)]}
    fade_start = max(args.total - args.fade_out, 0)
    filters.append(f"atrim=0:{args.total},asetpts=PTS-STARTPTS")
    filters.append(f"afade=t=in:st=0:d={args.fade_in}")
    filters.append(f"afade=t=out:st={fade_start}:d={args.fade_out}")

    run(ff, [
        "-y", "-i", str(music_norm),
        "-af", ",".join(filters),
        "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le",
        str(music_dst),
    ])
    music_norm.unlink(missing_ok=True)

    # Measure the OPEN section (after the VO window) for the report; that is
    # what qc_bundle.py checks against the -20 target.
    open_lufs = None
    if duck:
        open_start = min(duck["window"][1] + 1.2, max(args.total - 6.0, 0))
        open_len = max(args.total - args.fade_out - open_start - 0.3, 2.0)
        open_lufs = measure_lufs(ff, music_dst, ss=open_start, t=open_len)
    report["music"] = {
        "out": str(music_dst),
        "lufs_integrated": measure_lufs(ff, music_dst),
        "lufs_open_section": open_lufs,
        "target": args.music_lufs,
        "duck": duck or "none",
        "trimmed_to_s": args.total,
        "fade_out_s": args.fade_out,
    }

    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
