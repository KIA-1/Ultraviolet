<!-- CreateSkill fields for recreation:
name: meirvo-video-pipeline-v3
description: Meirvo v5 fast-cut video pipeline. ONE vertical 9:16 main reel, default 40.00s (manifest-driven, 12-90s supported): 9 Veo source generations sliced into ~16 speed-ramped segments (1.25-1.6x, avg cut ~2.3s) + 3.0s black end card. Hard cuts default, 2 chapter dissolves. Veo contract: 8s/1080p/9:16, mode standard, NO personGeneration param (API rejects dont_allow since Jun 2026). Agent classifies photos multimodally (photo_map + extras + anchors), grade_clips.py unifies grade on sources, slice_clips.py bakes speed ramps, prep_audio.py levels VO -16 LUFS and music -20 LUFS with 8dB duck under narration. Ships only when qc_bundle.py (preset fast) exits 0.
whenToUse: Step 4 of the Meirvo Producer pipeline: video generation and editing. v5 FAST-CUT contract: default 40.00s reel = 9 Veo gens (7 core + 2 extras from photo_map) sliced into ~16 cuts + 3.0s end card. Workflow: classify photos (photo_map with extras + anchors), reframe_916.py prep, plan_shots.py (--total/--end-card configurable), GenerateVideo per veo_shots entry at 8s/1080p/9:16/standard WITHOUT personGeneration, frame-check first/mid/late of every gen, grade_clips.py on src dir, slice_clips.py, make_endcard.py --seconds 3.0, agent-written narration + prep_audio.py (music -20 LUFS ducked), build via hyperframes-bundle-v2, ship ONLY when qc_bundle.py exits 0. GEMINI_API_KEY optional (legacy --vo-mode gemini only).
tags: meirvo, video, veo, ffmpeg, producer-pipeline, cinematic
credentialSchema: [{"name":"GEMINI_API_KEY","label":"Gemini API Key (OPTIONAL)","type":"password","hint":"OPTIONAL for v6 native-only flow. If set, plan_shots.py will call Gemini for VO script generation. If unset, vo_text is blank and the agent writes the narration itself (or skips narration entirely for Voiceover=Music only listings). Production runs never require this key.","required":false}]
-->

# meirvo-video-pipeline v5 (fast-cut, Jun 10 2026)

Produces the Meirvo deliverable: ONE main_reel.mp4, vertical 1080x1920 (9:16), 24fps. Default 40.00s total because meirvo.com promises a 40-second video; duration is now a parameter, not a hardcode.

Structure (default): 9 Veo source generations sliced into ~16 timeline segments (average cut ~2.3s) + 3.0s black end card. Hard cuts everywhere except two chapter dissolves (hook into hero reveal 0.35s, closer into end card 0.5s). Every segment plays at 1.25-1.6x speed.

## Why v5 exists

The v4 reel passed its own QC and still watched like a screensaver: 7 slow 5-second pushes glued with half-second dissolves over music buried at -28 LUFS. Root cause was the spec, not the execution. v5 keeps Veo generations slow and geometrically safe (fast camera moves melt architecture) and manufactures pace in the edit:

1. Each 8s generation is SLICED into 1-2 segments (slice_clips.py).
2. Every segment gets a baked speed ramp (1.25-1.6x playback).
3. Hard cuts by default; dissolves only at the 2 chapter moments.
4. Music rides at -20 LUFS and ducks 8 dB under the narration, instead of hiding at -28 the whole reel.
5. The QC gate now FAILS slow edits (P1 pacing check: 12+ cuts, avg <= 3.0s).

## Veo generation contract (every source clip)

```
GenerateVideo({
  prompt: veo_shot.veo_prompt,         // from shot_plan.json, anchors baked in
  firstFrameImage: <9:16-prepped photo>,  // SaveFile viewUrl works directly
  aspectRatio: "9:16",
  durationSeconds: 8,                  // 1080p image-to-video REQUIRES 8s
  resolution: "1080p",
  mode: "standard"                     // "fast" ONLY for smoke tests
})
```

DO NOT pass personGeneration. The API rejects "dont_allow" for image-to-video since Jun 2026 (HTTP 400 INVALID_ARGUMENT). The no-people guard rides in the prompt negatives plus the mandatory frame checks.

Prompt grammar: "steady", "confident", "one continuous move". Never "slow" or "very gentle" (v4 language, reads dead even after speed ramps) and never "fast", "whip", orbit, arc, crane, or zoom into textured surfaces (geometry melts). Perceived speed comes from playback ramps, not from Veo. Segments use the 0.0-7.2s window of each 8s clip; the drift tail is never played.

## Agent workflow (one-shot sequence)

### STEP 0. Music preflight
Confirm tracks exist at `~/workspace/music_library/` or the operator supplied a track in-thread. Missing: HALT and ask. Never improvise an unlicensed track.

### STEP 1. Classify photos (MULTIMODAL, mandatory for production)
Read every listing photo. Write:
- `photo_map.json`: {shot_type: filename} for the 7 core slots (detail_hook, hero_exterior, living_room, kitchen, primary_bedroom, feature_space, exterior_closer) PLUS an `extras` array: `[{"file": "...", "category": "detail|room|exterior", "anchors": "..."}]`. The default 40s contract NEEDS 2 extras (9 generations total); pick the listing's next-best spaces (bath, office, dining, backyard, pool). Under 3 photos: HALT, ask for more.
- `anchors.json`: {shot_type: "1-2 concrete VISIBLE details + light direction"} read off each actual photo. Anchoring real details is the strongest hallucination guard.

### STEP 2. Prep 9:16 first frames (NON-GENERATIVE ONLY)
`reframe_916.py --mode crop --focus-x N` for interiors, `--mode blur-extend` for wide exteriors. Generative outpainting stays BANNED (E&O, May 1 2026: zero invented pixels of the property). Read each prepped frame before generating. Feed frames to Veo via SaveFile result.viewUrl.

### STEP 3. Plan
```
python3 plan_shots.py listing.json --photos-dir <prepped> \
  --photo-map photo_map.json --anchors anchors.json \
  --out {session}/video/shot_plan.json [--total 40.0] [--end-card 3.0]
```
Emits `veo_shots` (what you generate: src_01..src_NN.mp4) and `shots` (the timeline segments the bundle plays: clip_01..clip_MM + end card), with per-segment src_in/speed/duration/xfade_out, narration_spec, and qc_contract. The planner hard-fails with guidance when the math cannot close (e.g. 40s with only 7 gens: add extras or lower --total). 30s works with 7 gens, 40s needs 9. `photo_assignment: "BLIND_FALLBACK_DO_NOT_SHIP"` means STEP 1 was skipped: never ship that.

### STEP 4. Generate sources + frame checks
GenerateVideo per veo_shots entry, save as `video/src/src_NN.mp4`. Retry a failed slot twice (reword anchors); after 2 failures use ken_burns_fallback.py for THAT SLOT ONLY (a sliced 2-3s KB segment at 1.4x disappears into the cut; never plan-wide). Native GenerateVideo missing entirely: HALT "BLOCKED at STEP 4: native Veo tool missing". Then extract first, middle, AND late (~6.5s) frames of every gen and Read them: no people, no invented text, no warped lines, room matches source photo. v5 slices reach deeper into each clip than v4 did, so the LATE frame check is not optional.

### STEP 5. Grade + slice + end card
```
python3 grade_clips.py --clips-dir {session}/video/src
python3 slice_clips.py --shot-plan {session}/video/shot_plan.json \
  --src-dir {session}/video/src --out-dir {session}/video/clips
python3 make_endcard.py --out {session}/video/clips/clip_{last}.mp4 --seconds 3.0
```
grade_clips applies ONE unified warm grade + conform + strips Veo audio on the sources; slice_clips cuts segments and bakes speed ramps; the end card closes the clips dir (filename from the plan's last shot).

### STEP 6. Narration + audio
Write the narration yourself per narration_spec: ONE track, 40-46 words (~15-18s), starts 1.6s, ends by content minus 2s. Confident and present; the cut is fast, the voice stays composed. Open on the hook, one concrete sensory detail per beat, close with a short human invitation. No em dashes, no cliches (stunning, nestled, boasts, oasis, must-see). Generate with native GenerateAudio (Autonoe), then:
```
python3 prep_audio.py --vo narration_raw.wav --music <track> \
  --out-dir {session} --total 40.0 --tts-start 1.6
```
v5 levels: VO -16 LUFS; music -20 LUFS with an 8 dB duck under the narration window and a 2.8s tail fade. Music-only reels: omit --vo.

### STEP 7. Bundle + QC gate
Build with hyperframes-bundle-v2's build_meirvo_bundle.py (defaults correct), then:
```
python3 qc_bundle.py --bundle {session}/render_bundle --expect-total 40.0
```
Exit 0 is the ONLY ship condition. The v5 gate adds P1 (pacing: 12+ cuts, avg <= 3.0s) and A6 (duck depth) and checks music at -20 on the open section. Non-default durations: pass the matching --expect-total.

### STEP 8. Ship to operator (ONE link)
Zip the bundle, then upload via the meirvo-delivery skill:
```
RunWithCredentials(meirvo-delivery,
  "python3 .../upload_bundle.py --zip {session}/render_bundle.zip --session-id {sessionId}")
```
Post the returned downloadUrl + `unzip bundle.zip && ./render.sh` instructions, HALT. No Drive uploads, no 3-part SaveFile splits. When main_reel.mp4 comes back, ffprobe it (total +/- 0.1s, 1080x1920) before delivery.

## Cost

~$3 per Veo generation. Default 9 gens: ~$27 standard, ~$11 fast-mode smoke test. 30s reel: 7 gens, ~$21. Retries add ~$3 each. Hyperagent platform credits ONLY; never external API keys mid-pipeline.

## Duration flexibility

--total 12-90s, --end-card 2-6s. Default stays 40.00 to match the meirvo.com promise; change the site copy before changing the default. Veo's 8s per generation is a Google-side ceiling, invisible after slicing.

## Fallbacks

- Per-slot Ken Burns after 2 Veo failures (never plan-wide; slice it like any source).
- v3 ffmpeg sandbox render (run_pipeline.py) remains for --editor=v3 runs; lower quality, not default.

## Music library

5 Icons8 Fugue tracks at `~/workspace/music_library/` (01_hopeful_corporate default). Operator-supplied tracks allowed per run directives. prep_audio trims/fades regardless of source length. Copyrighted repertoire: warn the operator once that platforms may flag it on repost.