#!/usr/bin/env python3
"""
meirvo-video-pipeline / reframe_916.py  (v4.1)

NON-GENERATIVE 9:16 reframe for Veo first frames. Generative reframing
(GenerateImage / NB Pro outpaint) is BANNED for listing media (May 1 2026
E&O decision: the video must show only the actual property, zero invented
pixels). Two compliant modes:

  crop         Crop the photo to 9:16. Best for interiors and any shot with
               a clear focal feature. --focus-x biases the crop window
               (0.0 = left edge, 0.5 = center, 1.0 = right edge).
  blur-extend  Facade-saver for wide exteriors a crop would decapitate:
               the original fits by WIDTH, and a blurred, darkened copy of
               the SAME photo fills the bands above/below. Classic vertical
               letterbox treatment; every pixel originates from the photo.

Usage:
  python3 reframe_916.py --photo ext_front.jpg --out prepped/ext_front.jpg --mode blur-extend
  python3 reframe_916.py --photo kitchen.jpg --out prepped/kitchen.jpg --mode crop --focus-x 0.42
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

TARGET_W, TARGET_H = 1080, 1920


def ensure_pillow():
    try:
        from PIL import Image  # noqa: F401
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "pillow"], check=True)


def reframe_crop(img, focus_x: float):
    from PIL import Image
    w, h = img.size
    target_ratio = TARGET_W / TARGET_H  # 0.5625
    if w / h > target_ratio:
        # Too wide: crop width, keep full height
        crop_w = int(h * target_ratio)
        center = int(focus_x * w)
        left = max(0, min(center - crop_w // 2, w - crop_w))
        box = (left, 0, left + crop_w, h)
    else:
        # Too tall: crop height, keep full width (rare for listing photos)
        crop_h = int(w / target_ratio)
        top = max(0, (h - crop_h) // 2)
        box = (0, top, w, top + crop_h)
    return img.crop(box).resize((TARGET_W, TARGET_H), Image.LANCZOS)


def reframe_blur_extend(img):
    from PIL import Image, ImageFilter, ImageEnhance
    # Background: cover-fill the canvas with the same photo, blurred + darkened
    w, h = img.size
    scale = max(TARGET_W / w, TARGET_H / h)
    bg = img.resize((int(w * scale) + 1, int(h * scale) + 1), Image.LANCZOS)
    bw, bh = bg.size
    bg = bg.crop(((bw - TARGET_W) // 2, (bh - TARGET_H) // 2,
                  (bw - TARGET_W) // 2 + TARGET_W, (bh - TARGET_H) // 2 + TARGET_H))
    bg = bg.filter(ImageFilter.GaussianBlur(42))
    bg = ImageEnhance.Brightness(bg).enhance(0.55)
    # Foreground: original fits by width, vertically centered
    fg_h = int(h * (TARGET_W / w))
    fg = img.resize((TARGET_W, fg_h), Image.LANCZOS)
    canvas = bg.copy()
    canvas.paste(fg, (0, (TARGET_H - fg_h) // 2))
    return canvas


def main() -> int:
    p = argparse.ArgumentParser(description="Non-generative 9:16 reframe (crop or blur-extend)")
    p.add_argument("--photo", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--mode", choices=["crop", "blur-extend"], default="crop")
    p.add_argument("--focus-x", type=float, default=0.5,
                   help="crop mode: horizontal focus 0.0-1.0 (default 0.5 center)")
    args = p.parse_args()

    ensure_pillow()
    from PIL import Image

    src = Path(args.photo).expanduser()
    if not src.is_file():
        print(f"error: photo not found: {src}", file=sys.stderr)
        return 1
    img = Image.open(src).convert("RGB")
    if img.size[0] < 800:
        print(f"  ! low-res source ({img.size[0]}px wide): expect soft output", file=sys.stderr)

    out = reframe_crop(img, max(0.0, min(args.focus_x, 1.0))) if args.mode == "crop" else reframe_blur_extend(img)

    dst = Path(args.out).expanduser()
    dst.parent.mkdir(parents=True, exist_ok=True)
    out.save(dst, quality=92)
    print(f"reframed ({args.mode}): {src.name} -> {dst} ({TARGET_W}x{TARGET_H}, zero invented pixels)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
