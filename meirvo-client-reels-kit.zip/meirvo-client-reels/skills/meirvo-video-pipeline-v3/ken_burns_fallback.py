#!/usr/bin/env python3
"""
meirvo-video-pipeline / ken_burns_fallback.py

When a Veo clip fails (2x retry exhausted), this script generates a Ken Burns
pan/zoom on the source photo to produce a replacement clip at the target
duration. Uses blurred-letterbox for 4:3 photos into 9:16 without center-crop.

Output: MP4 at 720x1280 @ 30fps H.264, duration matching the target.

Usage:
    python ken_burns_fallback.py \\
        --photo /path/to/photo.jpg \\
        --duration 5.0 \\
        --output /path/to/clip_03.mp4 \\
        [--zoom-direction in|out|pan-lr|pan-rl]

Exit codes: 0 = success, 1 = usage error, 2 = ffmpeg failure.
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

import imageio_ffmpeg


FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
# Match Veo 3.1 native framerate so Ken Burns fallback clips slot into the
# reel without a framerate seam.
FPS = 24
OUT_W = 720
OUT_H = 1280


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def build_filter(duration_s: float, direction: str) -> str:
    """Build ffmpeg filter_complex for Ken Burns + blurred letterbox."""
    total_frames = int(duration_s * FPS)

    # Zoompan expression — 'in' (push-in) or 'out' (pull-back)
    if direction == "in":
        z_expr = f"min(zoom+0.0010,1.25)"
        x_expr = "iw/2-(iw/zoom/2)"
        y_expr = "ih/2-(ih/zoom/2)"
    elif direction == "out":
        z_expr = f"if(eq(on,1),1.25,max(zoom-0.0010,1.0))"
        x_expr = "iw/2-(iw/zoom/2)"
        y_expr = "ih/2-(ih/zoom/2)"
    elif direction == "pan-lr":
        z_expr = "1.15"
        x_expr = f"(iw-(iw/zoom))*on/{total_frames}"
        y_expr = "ih/2-(ih/zoom/2)"
    else:  # pan-rl
        z_expr = "1.15"
        x_expr = f"(iw-(iw/zoom))*(1-on/{total_frames})"
        y_expr = "ih/2-(ih/zoom/2)"

    # Strategy:
    #   [0:v] = static image, looped
    #   Split into bg (blurred letterbox) + fg (Ken Burns zoompan)
    #   Composite fg centered over bg
    filt = (
        f"[0:v]loop=loop=-1:size=1:start=0,trim=duration={duration_s},setpts=PTS-STARTPTS,"
        f"format=yuv420p,fps={FPS}[src];"
        f"[src]split=2[bg_src][fg_src];"
        # Background: scale to fill 720x1280 with overflow, then blur heavily
        f"[bg_src]scale={OUT_W}:{OUT_H}:force_original_aspect_ratio=increase,"
        f"crop={OUT_W}:{OUT_H},boxblur=40:3,eq=brightness=-0.15[bg];"
        # Foreground: Ken Burns zoompan — zoompan outputs hd image we then scale to fit
        f"[fg_src]zoompan=z='{z_expr}':x='{x_expr}':y='{y_expr}':"
        f"d=1:s={OUT_W*2}x{OUT_H*2}:fps={FPS},"
        f"scale={OUT_W}:-2:flags=lanczos,"
        f"trim=duration={duration_s},setpts=PTS-STARTPTS[fg];"
        # Composite
        f"[bg][fg]overlay=(W-w)/2:(H-h)/2:format=auto,format=yuv420p,fps={FPS}[outv]"
    )
    return filt


def main():
    p = argparse.ArgumentParser(description="Ken Burns fallback clip generator")
    p.add_argument("--photo", required=True, help="Source photo path")
    p.add_argument("--duration", type=float, required=True, help="Target duration in seconds")
    p.add_argument("--output", required=True, help="Output MP4 path")
    p.add_argument("--zoom-direction", default="in",
                   choices=["in", "out", "pan-lr", "pan-rl"],
                   help="Ken Burns direction (default: in)")
    args = p.parse_args()

    photo = Path(args.photo).expanduser()
    if not photo.exists():
        eprint(f"error: photo not found: {photo}")
        sys.exit(1)

    out_path = Path(args.output).expanduser()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    filt = build_filter(args.duration, args.zoom_direction)
    cmd = [
        FFMPEG, "-y",
        "-loop", "1",
        "-i", str(photo),
        "-filter_complex", filt,
        "-map", "[outv]",
        "-t", f"{args.duration}",
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-preset", "medium",
        "-crf", "20",
        "-movflags", "+faststart",
        "-r", str(FPS),
        str(out_path),
    ]

    eprint(f"  ken burns: {photo.name} → {out_path.name} ({args.duration}s {args.zoom_direction})")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired:
        eprint("error: ffmpeg timed out")
        sys.exit(2)

    if result.returncode != 0:
        eprint("ffmpeg failed:")
        eprint(result.stderr[-2000:])
        sys.exit(2)

    eprint(f"  ✓ wrote {out_path.stat().st_size:,} bytes")
    print(json.dumps({
        "output": str(out_path.resolve()),
        "duration_s": args.duration,
        "direction": args.zoom_direction,
        "bytes": out_path.stat().st_size,
    }, indent=2))


if __name__ == "__main__":
    main()
