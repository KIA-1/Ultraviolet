#!/usr/bin/env python3
"""
meirvo-video-pipeline / render_overlays.py

Renders 4 transparent PNG overlays for the listing reel:
  intro_title.png       — address + price, full-bleed card
  data_card.png         — BR / BA / sqft, lower-third strip
  agent_lower_third.png — agent name + brokerage, corner
  cta_card.png          — CTA line, lower-center strip

All overlays are 720x1280 RGBA with transparency. ffmpeg overlays them at
the appropriate beats of the reel.

Usage:
    python render_overlays.py \\
        --shot-plan ~/workspace/{sessionId}/video/shot_plan.json \\
        --out ~/workspace/{sessionId}/video/overlays/ \\
        [--size 720x1280]

No credentials. Pure Pillow.

Exit codes: 0 = success, 1 = usage error.
"""

import argparse
import json
import sys
import urllib.request
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageFilter

# Meirvo brand
IVORY = (244, 240, 232)
INK = (14, 12, 10)
RUST = (198, 90, 46)
EMBER = (122, 43, 28)
GRAPHITE = (42, 38, 36)
WHITE = (255, 255, 255)

SCRIPT_DIR = Path(__file__).parent
FONT_DIR = SCRIPT_DIR.parent / "fonts"

# Font bootstrap sources (jsDelivr fontsource mirrors, clean TTFs)
FONT_SOURCES = {
    "InstrumentSerif-Regular.ttf":
        "https://cdn.jsdelivr.net/fontsource/fonts/instrument-serif@latest/latin-400-normal.ttf",
    "InstrumentSerif-Italic.ttf":
        "https://cdn.jsdelivr.net/fontsource/fonts/instrument-serif@latest/latin-400-italic.ttf",
    "Inter-Regular.ttf":
        "https://cdn.jsdelivr.net/fontsource/fonts/inter@latest/latin-400-normal.ttf",
}


def _font_loadable(path: Path) -> bool:
    """Verify a font file loads as TTF (catches UTF-8 corruption on transport)."""
    try:
        ImageFont.truetype(str(path), 24)
        return True
    except Exception:
        return False


def ensure_fonts(font_dir: Path) -> None:
    """If any bundled font is missing or corrupted, download clean TTFs from jsDelivr."""
    font_dir.mkdir(parents=True, exist_ok=True)
    for name, url in FONT_SOURCES.items():
        path = font_dir / name
        if path.exists() and _font_loadable(path):
            continue
        print(f"  ⇣ downloading {name} from jsDelivr", file=sys.stderr)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "meirvo-video-pipeline/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                path.write_bytes(r.read())
            if not _font_loadable(path):
                raise RuntimeError(f"downloaded {name} is still not loadable")
        except Exception as e:
            raise RuntimeError(f"font bootstrap failed for {name}: {e}")


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def load_fonts(w: int, h: int) -> dict:
    """Scale fonts to canvas size. Designed around 720x1280."""
    ensure_fonts(FONT_DIR)
    scale = h / 1280.0
    serif = str(FONT_DIR / "InstrumentSerif-Regular.ttf")
    serif_italic = str(FONT_DIR / "InstrumentSerif-Italic.ttf")
    sans = str(FONT_DIR / "Inter-Regular.ttf")
    return {
        "title_xl": ImageFont.truetype(serif, int(68 * scale)),
        "title_lg": ImageFont.truetype(serif, int(52 * scale)),
        "title_md": ImageFont.truetype(serif, int(42 * scale)),
        "price": ImageFont.truetype(serif, int(54 * scale)),
        "data_num": ImageFont.truetype(serif, int(48 * scale)),
        "data_label": ImageFont.truetype(sans, int(15 * scale)),
        "agent_name": ImageFont.truetype(serif, int(32 * scale)),
        "brokerage": ImageFont.truetype(sans, int(18 * scale)),
        "cta": ImageFont.truetype(serif_italic, int(46 * scale)),
        "small": ImageFont.truetype(sans, int(16 * scale)),
        "watermark": ImageFont.truetype(serif_italic, int(18 * scale)),
    }


def text_width(draw: ImageDraw.Draw, text: str, font: ImageFont.FreeTypeFont) -> int:
    bbox = draw.textbbox((0, 0), text, font=font)
    return bbox[2] - bbox[0]


def wrap_text(draw, text: str, font, max_w: int) -> list:
    words = text.split()
    lines = []
    current = ""
    for w in words:
        test = f"{current} {w}".strip()
        if text_width(draw, test, font) > max_w and current:
            lines.append(current)
            current = w
        else:
            current = test
    if current:
        lines.append(current)
    return lines


def draw_accent_bar(draw, x, y, w, h, color):
    draw.rectangle([x, y, x + w, y + h], fill=color)


def render_intro_title(canvas_w: int, canvas_h: int, address: str, price: str,
                       fonts: dict) -> Image.Image:
    """Bottom-anchored intro card: address (wrapped) + price + rust accent bar."""
    img = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Soft bottom gradient (darkens the image behind the text)
    overlay = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    odraw = ImageDraw.Draw(overlay)
    for y in range(int(canvas_h * 0.55), canvas_h):
        progress = (y - canvas_h * 0.55) / (canvas_h * 0.45)
        alpha = int(255 * 0.7 * progress)
        odraw.line([(0, y), (canvas_w, y)], fill=(0, 0, 0, alpha))
    img = Image.alpha_composite(img, overlay)
    draw = ImageDraw.Draw(img)

    margin = int(canvas_w * 0.08)
    content_w = canvas_w - 2 * margin

    # Accent bar above address
    bar_y = int(canvas_h * 0.68)
    draw_accent_bar(draw, margin, bar_y, int(canvas_w * 0.14), 4, RUST)

    # Address (wrap if needed)
    addr_y = bar_y + 22
    addr_font = fonts["title_lg"]
    if len(address) > 36:
        addr_font = fonts["title_md"]
    lines = wrap_text(draw, address, addr_font, content_w)
    for line in lines:
        draw.text((margin, addr_y), line, fill=WHITE, font=addr_font)
        addr_y += int(addr_font.size * 1.2)

    # Price
    if price:
        price_y = addr_y + 12
        draw.text((margin, price_y), price, fill=(255, 255, 255, 230), font=fonts["price"])

    # Meirvo watermark (top right)
    wm_text = "MEIRVO"
    wm_font = fonts["watermark"]
    wm_w = text_width(draw, wm_text, wm_font)
    draw.text((canvas_w - margin - wm_w, margin), wm_text,
              fill=(255, 255, 255, 180), font=wm_font)
    return img


def render_data_card(canvas_w: int, canvas_h: int, bedrooms: str, bathrooms: str,
                     interior_size: str, fonts: dict) -> Image.Image:
    """Lower-third with 3 data cells separated by thin rules."""
    img = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    margin = int(canvas_w * 0.08)
    content_w = canvas_w - 2 * margin
    cell_w = content_w // 3

    # Darkened strip behind the data cells
    strip_top = int(canvas_h * 0.75)
    strip_bottom = int(canvas_h * 0.92)
    strip_overlay = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    sdraw = ImageDraw.Draw(strip_overlay)
    sdraw.rectangle([0, strip_top, canvas_w, strip_bottom],
                    fill=(14, 12, 10, 170))
    img = Image.alpha_composite(img, strip_overlay)
    draw = ImageDraw.Draw(img)

    # Three cells: Bedrooms / Bathrooms / sqft
    cells = [
        ("BEDROOMS", bedrooms or "-"),
        ("BATHROOMS", bathrooms or "-"),
        ("INTERIOR", interior_size or "-"),
    ]

    row_mid = (strip_top + strip_bottom) // 2
    for i, (label, value) in enumerate(cells):
        cell_center_x = margin + (i * cell_w) + (cell_w // 2)
        # Value
        v_font = fonts["data_num"]
        # shrink font if value too wide
        while text_width(draw, str(value), v_font) > cell_w - 24 and v_font.size > 24:
            v_font = ImageFont.truetype(v_font.path, v_font.size - 2)
        v_w = text_width(draw, str(value), v_font)
        v_h = v_font.size
        draw.text((cell_center_x - v_w // 2, row_mid - v_h), str(value),
                  fill=WHITE, font=v_font)
        # Label below
        l_font = fonts["data_label"]
        l_w = text_width(draw, label, l_font)
        draw.text((cell_center_x - l_w // 2, row_mid + 8), label,
                  fill=(255, 255, 255, 200), font=l_font)
        # Divider rule (not after last cell)
        if i < len(cells) - 1:
            div_x = margin + ((i + 1) * cell_w)
            draw.line([(div_x, row_mid - 30), (div_x, row_mid + 30)],
                      fill=(255, 255, 255, 90), width=1)
    return img


def render_agent_lower_third(canvas_w: int, canvas_h: int, agent_name: str,
                              brokerage: str, fonts: dict) -> Image.Image:
    """Bottom-left lower-third: rust accent bar + agent name + brokerage."""
    img = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    margin = int(canvas_w * 0.08)
    # Subtle bottom gradient
    overlay = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    odraw = ImageDraw.Draw(overlay)
    for y in range(int(canvas_h * 0.75), canvas_h):
        progress = (y - canvas_h * 0.75) / (canvas_h * 0.25)
        alpha = int(255 * 0.6 * progress)
        odraw.line([(0, y), (canvas_w, y)], fill=(0, 0, 0, alpha))
    img = Image.alpha_composite(img, overlay)
    draw = ImageDraw.Draw(img)

    # Accent bar
    bar_x = margin
    bar_y = int(canvas_h * 0.82)
    draw_accent_bar(draw, bar_x, bar_y, int(canvas_w * 0.12), 3, RUST)

    # Agent name
    name_y = bar_y + 18
    draw.text((margin, name_y), agent_name or "Your Agent", fill=WHITE,
              font=fonts["agent_name"])

    # Brokerage
    if brokerage:
        brk_y = name_y + int(fonts["agent_name"].size * 1.15)
        draw.text((margin, brk_y), brokerage.upper(),
                  fill=(255, 255, 255, 200), font=fonts["brokerage"])
    return img


def render_cta_card(canvas_w: int, canvas_h: int, cta_line: str, address: str,
                    fonts: dict) -> Image.Image:
    """Centered closer: CTA line + address + Meirvo mark."""
    img = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Strong bottom gradient
    overlay = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
    odraw = ImageDraw.Draw(overlay)
    for y in range(int(canvas_h * 0.4), canvas_h):
        progress = (y - canvas_h * 0.4) / (canvas_h * 0.6)
        alpha = int(255 * 0.85 * progress)
        odraw.line([(0, y), (canvas_w, y)], fill=(0, 0, 0, alpha))
    img = Image.alpha_composite(img, overlay)
    draw = ImageDraw.Draw(img)

    # CTA line (centered)
    cta_y = int(canvas_h * 0.65)
    cta_font = fonts["cta"]
    cta_w = text_width(draw, cta_line, cta_font)
    draw.text(((canvas_w - cta_w) // 2, cta_y), cta_line, fill=WHITE, font=cta_font)

    # Address subline
    if address:
        addr_y = cta_y + int(cta_font.size * 1.3)
        addr_w = text_width(draw, address, fonts["small"])
        draw.text(((canvas_w - addr_w) // 2, addr_y), address,
                  fill=(255, 255, 255, 210), font=fonts["small"])

    # Meirvo wordmark — centered near bottom
    wm_font = ImageFont.truetype(str(FONT_DIR / "InstrumentSerif-Regular.ttf"),
                                  int(canvas_h * 0.045))
    wm_text = "MEIRVO"
    wm_w = text_width(draw, wm_text, wm_font)
    wm_y = int(canvas_h * 0.90)
    draw.text(((canvas_w - wm_w) // 2, wm_y), wm_text, fill=WHITE, font=wm_font)
    # Rust accent dot under the wordmark
    dot_y = wm_y + wm_font.size + 8
    draw.ellipse([(canvas_w // 2 - 3, dot_y), (canvas_w // 2 + 3, dot_y + 6)],
                  fill=RUST)
    return img


def main():
    p = argparse.ArgumentParser(description="Render Meirvo reel overlays")
    p.add_argument("--shot-plan", required=True, help="Path to shot_plan.json")
    p.add_argument("--out", required=True, help="Output directory for PNGs")
    p.add_argument("--size", default="720x1280",
                   help="WxH of overlay canvas (default 720x1280)")
    args = p.parse_args()

    try:
        w_s, h_s = args.size.lower().split("x")
        canvas_w = int(w_s)
        canvas_h = int(h_s)
    except ValueError:
        eprint(f"error: invalid --size '{args.size}' (expected WxH)")
        sys.exit(1)

    shot_plan_path = Path(args.shot_plan).expanduser()
    try:
        plan = json.loads(shot_plan_path.read_text(encoding="utf-8"))
    except Exception as e:
        eprint(f"error: could not read shot_plan.json: {e}")
        sys.exit(1)

    out_dir = Path(args.out).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    fonts = load_fonts(canvas_w, canvas_h)
    overlay_text = plan.get("overlay_text", {})

    manifest = []

    # Always render all 4 overlay types (even if not strictly used —
    # keeps output predictable for stitching step).
    intro_data = overlay_text.get("intro_title", {})
    img = render_intro_title(canvas_w, canvas_h,
                              intro_data.get("address", ""),
                              intro_data.get("price", ""),
                              fonts)
    out = out_dir / "intro_title.png"
    img.save(out, "PNG")
    manifest.append({"key": "intro_title", "localPath": str(out.resolve()),
                     "size": f"{canvas_w}x{canvas_h}"})
    eprint(f"  ✓ intro_title.png")

    data_data = overlay_text.get("data_card", {})
    img = render_data_card(canvas_w, canvas_h,
                            data_data.get("bedrooms", ""),
                            data_data.get("bathrooms", ""),
                            data_data.get("interiorSize", ""),
                            fonts)
    out = out_dir / "data_card.png"
    img.save(out, "PNG")
    manifest.append({"key": "data_card", "localPath": str(out.resolve()),
                     "size": f"{canvas_w}x{canvas_h}"})
    eprint(f"  ✓ data_card.png")

    agent_data = overlay_text.get("agent_lower_third", {})
    img = render_agent_lower_third(canvas_w, canvas_h,
                                    agent_data.get("agentName", ""),
                                    agent_data.get("brokerage", ""),
                                    fonts)
    out = out_dir / "agent_lower_third.png"
    img.save(out, "PNG")
    manifest.append({"key": "agent_lower_third", "localPath": str(out.resolve()),
                     "size": f"{canvas_w}x{canvas_h}"})
    eprint(f"  ✓ agent_lower_third.png")

    cta_data = overlay_text.get("cta_card", {})
    img = render_cta_card(canvas_w, canvas_h,
                           cta_data.get("cta_line", "Come see it in person"),
                           cta_data.get("address", ""),
                           fonts)
    out = out_dir / "cta_card.png"
    img.save(out, "PNG")
    manifest.append({"key": "cta_card", "localPath": str(out.resolve()),
                     "size": f"{canvas_w}x{canvas_h}"})
    eprint(f"  ✓ cta_card.png")

    print(json.dumps({
        "outDir": str(out_dir.resolve()),
        "count": len(manifest),
        "overlays": manifest,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
