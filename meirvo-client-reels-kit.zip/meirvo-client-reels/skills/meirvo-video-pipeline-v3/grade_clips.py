#!/usr/bin/env python3
"""
meirvo-video-pipeline / grade_clips.py  (v4)

Applies ONE subtle unified grade to every Veo clip and conforms format.
Mismatched white balance between clips is the single fastest "AI-assembled"
tell; a uniform grade is the highest-leverage perceived-quality fix.

Per clip:
  - gentle shared grade: slight contrast lift, mild saturation, faint warmth
  - conform: 1080x1920 (scale + center-crop if needed), exactly 24 fps, yuv420p
  - strip audio (the native GenerateVideo tool cannot disable Veo's baked
    audio, and the edit must never let it bleed through)
  - re-encode libx264 crf 17 (visually lossless for this use)

Skips the black end card automatically (grading pure black shifts its hue).

Usage:
  python3 grade_clips.py --clips-dir ~/workspace/{sessionId}/video/clips
      [--width 1080] [--height 1920] [--no-grade]   # --no-grade = conform only
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

# Subtle editorial-warm grade. Deliberately conservative: the job is unifying
# the clips, not restyling the property (the video must show the real house).
GRADE_FILTER = "eq=contrast=1.04:saturation=1.05:gamma=0.99,colorbalance=rs=.012:gs=.004:bs=-.008:rm=.006:bm=-.004"


def get_ffmpeg() -> str:
    found = shutil.which("ffmpeg")
    if found:
        return found
    try:
        import imageio_ffmpeg  # type: ignore
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "imageio-ffmpeg"], check=True)
        import imageio_ffmpeg  # type: ignore
    return imageio_ffmpeg.get_ffmpeg_exe()


def is_black_card(ff: str, path: Path) -> bool:
    """Cheap luma probe on one frame at t=1s."""
    proc = subprocess.run(
        [ff, "-nostats", "-ss", "1.0", "-i", str(path), "-frames:v", "1",
         "-vf", "signalstats,metadata=print", "-f", "null", "-"],
        capture_output=True, text=True,
    )
    out = proc.stderr + proc.stdout
    for line in out.splitlines():
        if "YAVG" in line:
            try:
                # signalstats reports the limited-range Y plane (black = 16).
                # Meirvo Ink #0E0C0A lands around 22-26 there.
                return float(line.rsplit("=", 1)[-1]) < 34.0
            except ValueError:
                return False
    return False


def main() -> int:
    p = argparse.ArgumentParser(description="Unified grade + conform for Meirvo reel clips")
    p.add_argument("--clips-dir", required=True)
    p.add_argument("--width", type=int, default=1080)
    p.add_argument("--height", type=int, default=1920)
    p.add_argument("--no-grade", action="store_true", help="Conform format only, skip the grade")
    args = p.parse_args()

    ff = get_ffmpeg()
    clips_dir = Path(args.clips_dir).expanduser()
    clips = sorted(p for p in clips_dir.iterdir() if p.suffix.lower() in {".mp4", ".mov", ".webm"})
    if not clips:
        print(f"no clips in {clips_dir}", file=sys.stderr)
        return 1

    conform = (
        f"scale={args.width}:{args.height}:force_original_aspect_ratio=increase,"
        f"crop={args.width}:{args.height},fps=24,format=yuv420p"
    )

    for clip in clips:
        if is_black_card(ff, clip):
            print(f"  - {clip.name}: black end card, skipping grade")
            continue
        vf = conform if args.no_grade else f"{GRADE_FILTER},{conform}"
        tmp = clip.with_suffix(".graded.mp4")
        proc = subprocess.run(
            [ff, "-y", "-i", str(clip), "-vf", vf,
             "-c:v", "libx264", "-crf", "17", "-preset", "medium",
             "-an", str(tmp)],
            capture_output=True, text=True,
        )
        if proc.returncode != 0:
            print(f"  x {clip.name}: grade failed\n{proc.stderr[-800:]}", file=sys.stderr)
            return 1
        tmp.replace(clip)
        print(f"  + {clip.name}: graded + conformed ({args.width}x{args.height} 24fps, audio stripped)")

    print(f"grade_clips: {len(clips)} file(s) processed with one unified grade")
    return 0


if __name__ == "__main__":
    sys.exit(main())
