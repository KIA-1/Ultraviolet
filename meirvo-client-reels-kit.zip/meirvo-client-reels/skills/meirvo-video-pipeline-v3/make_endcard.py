#!/usr/bin/env python3
"""
meirvo-video-pipeline / make_endcard.py  (v4)

Generates the mandatory solid-black end card clip that closes every Meirvo
reel. End-card text (price, agent, CTA) is composited by hyperframes ON TOP
of this clip, so it must be pure Ink (#0E0C0A), exactly 24fps, and match the
canvas. Always the LAST clip in clips/ and shot_plan.json.

Usage:
  python3 make_endcard.py --out ~/workspace/{sessionId}/video/clips/clip_17.mp4
      [--seconds 3.0] [--width 1080] [--height 1920]

v5 default is 3.0s (v4 used 5.0s, which read as dead air at the end of a
fast-cut reel). Match the shot plan's end_card_seconds.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys


def get_ffmpeg() -> str:
    found = shutil.which("ffmpeg")
    if found:
        return found
    try:
        import imageio_ffmpeg  # type: ignore
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "imageio-ffmpeg"], check=True)
        import imageio_ffmpeg  # type: ignore
    return imageio_ffmpeg.get_ffmpeg_exe()


def main() -> int:
    p = argparse.ArgumentParser(description="Generate the Meirvo black end-card clip")
    p.add_argument("--out", required=True)
    p.add_argument("--seconds", type=float, default=3.0)
    p.add_argument("--width", type=int, default=1080)
    p.add_argument("--height", type=int, default=1920)
    p.add_argument("--color", default="#0E0C0A", help="Meirvo Ink")
    args = p.parse_args()

    ff = get_ffmpeg()
    cmd = [
        ff, "-y",
        "-f", "lavfi",
        "-i", f"color=c={args.color}:s={args.width}x{args.height}:d={args.seconds}:r=24",
        "-c:v", "libx264", "-crf", "20", "-preset", "fast",
        "-pix_fmt", "yuv420p",
        "-an",
        args.out,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        print(proc.stderr[-1500:], file=sys.stderr)
        return 1
    print(f"end card written: {args.out} ({args.seconds}s {args.width}x{args.height} 24fps {args.color})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
