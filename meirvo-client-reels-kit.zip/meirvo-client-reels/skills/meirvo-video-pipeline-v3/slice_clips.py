#!/usr/bin/env python3
"""
meirvo-video-pipeline / slice_clips.py  (v5)

Cuts each graded Veo source generation (video/src/src_NN.mp4) into its
timeline segments (video/clips/clip_NN.mp4) per shot_plan.json, baking the
per-segment speed ramp. This is where the fast-cut pace is manufactured:
Veo footage is generated at a steady confident pace (fast camera moves melt
geometry) and played back at 1.25-1.6x.

Run AFTER grade_clips.py on the src dir and BEFORE make_endcard.py +
build_meirvo_bundle.py. The output dir becomes the bundle's clips dir.

Per segment:
  - seek src_in, take ((duration + xfade_out) * speed + pad) seconds of source
  - retime: setpts / speed, re-lock 24fps, yuv420p
  - re-encode libx264 crf 17, no audio
  - verify with ffprobe: output must cover duration + xfade_out

The end_card entry in the plan is skipped here; generate it with
make_endcard.py directly into the out dir as the final clip.

Usage:
  python3 slice_clips.py --shot-plan {session}/video/shot_plan.json \\
      --src-dir {session}/video/src --out-dir {session}/video/clips
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

SRC_PAD = 0.12  # extra source seconds taken per slice so media always covers slot + dissolve


def get_ffmpeg() -> str:
    found = shutil.which("ffmpeg")
    if found:
        return found
    try:
        import imageio_ffmpeg  # type: ignore
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "imageio-ffmpeg"], check=True)
        import imageio_ffmpeg  # type: ignore
    return imageio_ffmpeg.get_ffmpeg_exe()


def probe_duration(ff: str, path: Path) -> float:
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        try:
            out = subprocess.check_output(
                [ffprobe, "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
                text=True, stderr=subprocess.DEVNULL)
            return float(out.strip())
        except Exception:
            pass
    proc = subprocess.run([ff, "-i", str(path)], capture_output=True, text=True)
    import re
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.?\d*)", proc.stderr)
    if not m:
        return 0.0
    return float(m.group(1)) * 3600 + float(m.group(2)) * 60 + float(m.group(3))


def main() -> int:
    p = argparse.ArgumentParser(description="Slice graded Veo generations into fast-cut segments")
    p.add_argument("--shot-plan", required=True)
    p.add_argument("--src-dir", required=True, help="Dir of graded source generations (src_NN.mp4)")
    p.add_argument("--out-dir", required=True, help="Output dir for timeline segments (clip_NN.mp4)")
    args = p.parse_args()

    ff = get_ffmpeg()
    plan = json.loads(Path(args.shot_plan).expanduser().read_text())
    shots = plan.get("shots") or []
    if not shots:
        print("error: shot plan has no shots[]", file=sys.stderr)
        return 1

    src_dir = Path(args.src_dir).expanduser()
    out_dir = Path(args.out_dir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    report = {"segments": [], "skipped": [], "errors": []}
    for s in shots:
        if s.get("shot_type") == "end_card" or not s.get("source_clip"):
            report["skipped"].append({"filename": s.get("filename"),
                                      "reason": "end card; generate with make_endcard.py"})
            continue
        src = src_dir / s["source_clip"]
        if not src.is_file():
            report["errors"].append(f"{s['filename']}: source {src} missing")
            continue
        speed = float(s.get("speed", 1.0))
        need_timeline = float(s["duration"]) + float(s.get("xfade_out") or 0.0)
        take_src = need_timeline * speed + SRC_PAD
        src_in = float(s.get("src_in", 0.0))
        out_path = out_dir / s["filename"]

        src_dur = probe_duration(ff, src)
        if src_in + take_src > src_dur + 0.05:
            report["errors"].append(
                f"{s['filename']}: needs source {src_in:.2f}..{src_in + take_src:.2f}s "
                f"but {src.name} is only {src_dur:.2f}s")
            continue

        vf = f"setpts=(PTS-STARTPTS)/{speed},fps=24,format=yuv420p"
        proc = subprocess.run(
            [ff, "-y", "-ss", f"{src_in:.3f}", "-i", str(src), "-t", f"{take_src:.3f}",
             "-vf", vf, "-c:v", "libx264", "-crf", "17", "-preset", "medium",
             "-an", str(out_path)],
            capture_output=True, text=True)
        if proc.returncode != 0:
            report["errors"].append(f"{s['filename']}: ffmpeg failed: {proc.stderr[-400:]}")
            continue

        out_dur = probe_duration(ff, out_path)
        if out_dur + 0.02 < need_timeline:
            report["errors"].append(
                f"{s['filename']}: sliced media {out_dur:.2f}s < required {need_timeline:.2f}s")
            continue
        report["segments"].append({
            "filename": s["filename"], "source": s["source_clip"],
            "src_in": src_in, "speed": speed,
            "timeline_s": float(s["duration"]), "media_s": round(out_dur, 2),
        })
        print(f"  + {s['filename']}: {s['source_clip']} @ {src_in:.2f}s x{speed} "
              f"-> {out_dur:.2f}s media for {s['duration']:.2f}s slot", file=sys.stderr)

    report["ok"] = not report["errors"]
    print(json.dumps(report, indent=2))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
