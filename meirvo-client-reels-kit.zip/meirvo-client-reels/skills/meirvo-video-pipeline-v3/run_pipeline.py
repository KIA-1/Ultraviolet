#!/usr/bin/env python3
"""
meirvo-video-pipeline / run_pipeline.py

Master orchestrator. Runs the full video assembly pipeline after the agent has
(a) called plan_shots.py to produce a shot_plan.json, and (b) invoked the
GenerateVideo tool N times to produce clip_01.mp4 ... clip_0N.mp4 in clips_dir.

Steps:
  1. Verify shot_plan.json + clip files present
  2. Run generate_vo.py   → vo_dir
  3. Run render_overlays.py → overlays_dir
  4. Run stitch_reel.py   → main_reel.mp4
  5. Run derive_cuts.py   → tiktok.mp4 + story.mp4

Usage:
    python run_pipeline.py \\
        --shot-plan /path/to/shot_plan.json \\
        --clips-dir /path/to/clips/ \\
        --output-dir /path/to/video_output/ \\
        [--music-library ~/workspace/music_library/]

Credentials (env): GEMINI_API_KEY

Exit codes:
    0 = success (main_reel + tiktok + story written)
    1 = usage / precondition failure
    2 = a pipeline step failed
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path


SCRIPT_DIR = Path(__file__).parent


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def run_step(name: str, cmd: list, timeout: int = 900) -> dict:
    """Run a subprocess, return parsed stdout JSON (or {}) on success; raise on failure."""
    eprint(f"\n=== STEP: {name} ===")
    eprint(f"  cmd: {' '.join(str(c) for c in cmd)}")
    t0 = time.time()
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"{name}: timeout after {timeout}s")
    elapsed = time.time() - t0
    eprint(f"  (took {elapsed:.1f}s, exit={result.returncode})")
    # Forward stderr to our stderr for live feedback
    if result.stderr:
        for line in result.stderr.splitlines():
            eprint(f"    │ {line}")
    if result.returncode != 0:
        raise RuntimeError(f"{name} failed with exit {result.returncode}")
    # Try parsing last non-empty stdout line as JSON
    stdout = result.stdout.strip()
    if stdout:
        try:
            # Full stdout should be a JSON doc
            return json.loads(stdout)
        except json.JSONDecodeError:
            # Find last JSON object
            for chunk in reversed(stdout.split("\n\n")):
                try:
                    return json.loads(chunk.strip())
                except Exception:
                    continue
    return {}


def main():
    p = argparse.ArgumentParser(description="Run the Meirvo video pipeline end-to-end")
    p.add_argument("--shot-plan", required=True, help="Path to shot_plan.json")
    p.add_argument("--clips-dir", required=True, help="Directory with clip_01.mp4 ... clip_0N.mp4")
    p.add_argument("--output-dir", required=True, help="Root output directory for all artifacts")
    p.add_argument("--music-library", default="~/workspace/music_library",
                   help="Music library directory")
    p.add_argument("--skip-vo", action="store_true",
                   help="Skip TTS generation (uses silence for VO track)")
    args = p.parse_args()

    shot_plan = Path(args.shot_plan).expanduser()
    clips_dir = Path(args.clips_dir).expanduser()
    output_dir = Path(args.output_dir).expanduser()

    if not shot_plan.exists():
        eprint(f"error: shot_plan.json not found at {shot_plan}")
        sys.exit(1)

    # Parse shot plan to validate clip count
    try:
        plan = json.loads(shot_plan.read_text(encoding="utf-8"))
    except Exception as e:
        eprint(f"error: could not parse shot_plan.json: {e}")
        sys.exit(1)

    shots = plan.get("shots", [])
    n = len(shots)
    eprint(f"shot plan: {n} shots, reel duration {plan.get('reel_duration_s')}s")

    # Precondition: all clips must exist in clips_dir
    missing = []
    for shot in shots:
        slot = shot["slot_number"]
        expected = clips_dir / f"clip_{slot:02d}.mp4"
        if not expected.exists():
            missing.append(str(expected))
    if missing:
        eprint(f"error: missing {len(missing)} clip(s):")
        for m in missing:
            eprint(f"  - {m}")
        eprint("(run GenerateVideo for each shot from shot_plan, name outputs clip_NN.mp4)")
        sys.exit(1)

    # Output subdirs
    output_dir.mkdir(parents=True, exist_ok=True)
    vo_dir = output_dir / "vo"
    overlays_dir = output_dir / "overlays"
    vo_dir.mkdir(parents=True, exist_ok=True)
    overlays_dir.mkdir(parents=True, exist_ok=True)
    main_reel_path = output_dir / "main_reel.mp4"

    manifest = {
        "shot_plan": str(shot_plan.resolve()),
        "clips_dir": str(clips_dir.resolve()),
        "output_dir": str(output_dir.resolve()),
        "n_shots": n,
        "reel_duration_s": plan.get("reel_duration_s"),
        "music_track": plan.get("music_track"),
        "steps": {},
    }

    try:
        # Step 1: TTS (can skip if --skip-vo)
        if args.skip_vo:
            eprint("\n=== STEP: generate_vo (SKIPPED per --skip-vo) ===")
            manifest["steps"]["generate_vo"] = {"skipped": True}
        else:
            vo_out = run_step(
                "generate_vo",
                [sys.executable, str(SCRIPT_DIR / "generate_vo.py"),
                 "--shot-plan", str(shot_plan),
                 "--out", str(vo_dir)],
                timeout=600,
            )
            manifest["steps"]["generate_vo"] = vo_out

        # Step 2: render overlays
        ov_out = run_step(
            "render_overlays",
            [sys.executable, str(SCRIPT_DIR / "render_overlays.py"),
             "--shot-plan", str(shot_plan),
             "--out", str(overlays_dir)],
            timeout=60,
        )
        manifest["steps"]["render_overlays"] = ov_out

        # Step 3: stitch main reel
        stitch_out = run_step(
            "stitch_reel",
            [sys.executable, str(SCRIPT_DIR / "stitch_reel.py"),
             "--shot-plan", str(shot_plan),
             "--clips-dir", str(clips_dir),
             "--overlays-dir", str(overlays_dir),
             "--vo-dir", str(vo_dir),
             "--output", str(main_reel_path),
             "--music-library", args.music_library],
            timeout=900,
        )
        manifest["steps"]["stitch_reel"] = stitch_out

        # Step 4: derive cuts
        cuts_out = run_step(
            "derive_cuts",
            [sys.executable, str(SCRIPT_DIR / "derive_cuts.py"),
             "--main-reel", str(main_reel_path),
             "--out-dir", str(output_dir)],
            timeout=300,
        )
        manifest["steps"]["derive_cuts"] = cuts_out

    except RuntimeError as e:
        eprint(f"\nPIPELINE FAILURE: {e}")
        manifest["error"] = str(e)
        print(json.dumps(manifest, indent=2, ensure_ascii=False))
        sys.exit(2)

    # Final manifest
    manifest["outputs"] = {
        "main_reel": str(main_reel_path.resolve()),
        "tiktok": str((output_dir / "tiktok.mp4").resolve()),
        "story": str((output_dir / "story.mp4").resolve()),
    }
    eprint("\n=== PIPELINE COMPLETE ===")
    for k, v in manifest["outputs"].items():
        size = Path(v).stat().st_size if Path(v).exists() else 0
        eprint(f"  {k}: {v} ({size:,} bytes)")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
