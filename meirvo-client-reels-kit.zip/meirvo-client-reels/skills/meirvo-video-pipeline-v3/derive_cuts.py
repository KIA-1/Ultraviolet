#!/usr/bin/env python3
"""
meirvo-video-pipeline / derive_cuts.py

Derives TikTok (15s) and Story (6s) cuts from main_reel.mp4.

TikTok cut: first 15s, hard cut on the last frame, same audio as main.
Story cut:  first 6s, fade out last 0.5s on audio + video.

Usage:
    python derive_cuts.py \\
        --main-reel /path/to/main_reel.mp4 \\
        --out-dir /path/to/output/

Produces:
    tiktok.mp4  — 15s (or reel duration if shorter)
    story.mp4   — 6s with fade-out (or reel duration if shorter)

Exit codes: 0 = success, 1 = usage, 2 = ffmpeg failure.
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

import imageio_ffmpeg


FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()

TIKTOK_DURATION = 15.0
STORY_DURATION = 6.0
STORY_FADE_OUT = 0.5


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def probe_duration(path: Path) -> float:
    """Get video duration in seconds via ffmpeg -i stderr parsing."""
    result = subprocess.run(
        [FFMPEG, "-i", str(path)],
        capture_output=True, text=True,
    )
    # ffmpeg prints duration to stderr: "Duration: 00:00:40.00, ..."
    for line in result.stderr.splitlines():
        if "Duration:" in line:
            try:
                dur_str = line.split("Duration:")[1].split(",")[0].strip()
                h, m, s = dur_str.split(":")
                return int(h) * 3600 + int(m) * 60 + float(s)
            except Exception:
                pass
    return 0.0


def has_audio(path: Path) -> bool:
    """True if the input has at least one audio stream."""
    result = subprocess.run(
        [FFMPEG, "-i", str(path)],
        capture_output=True, text=True,
    )
    return "Audio:" in result.stderr


def cut_tiktok(main_reel: Path, out_path: Path, target_dur: float,
               with_audio: bool = True) -> None:
    """Hard cut, no fade. Clean musical trim."""
    cmd = [
        FFMPEG, "-y",
        "-i", str(main_reel),
        "-t", f"{target_dur}",
        "-c:v", "libx264", "-pix_fmt", "yuv420p",
        "-preset", "medium", "-crf", "19",
    ]
    if with_audio:
        cmd += ["-c:a", "aac", "-b:a", "192k", "-ar", "44100"]
    else:
        cmd += ["-an"]
    cmd += ["-movflags", "+faststart", str(out_path)]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    if result.returncode != 0:
        raise RuntimeError(f"tiktok cut failed:\n{result.stderr[-2000:]}")


def cut_story(main_reel: Path, out_path: Path, target_dur: float,
              with_audio: bool = True) -> None:
    """Story teaser: 6s with fade-out on both audio and video."""
    fade_start = max(0.0, target_dur - STORY_FADE_OUT)
    if with_audio:
        filt = (
            f"[0:v]fade=out:st={fade_start}:d={STORY_FADE_OUT}[v];"
            f"[0:a]afade=out:st={fade_start}:d={STORY_FADE_OUT}[a]"
        )
        cmd = [
            FFMPEG, "-y",
            "-i", str(main_reel),
            "-t", f"{target_dur}",
            "-filter_complex", filt,
            "-map", "[v]", "-map", "[a]",
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "medium", "-crf", "19",
            "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
            "-movflags", "+faststart",
            str(out_path),
        ]
    else:
        # Video-only fade
        filt = f"[0:v]fade=out:st={fade_start}:d={STORY_FADE_OUT}[v]"
        cmd = [
            FFMPEG, "-y",
            "-i", str(main_reel),
            "-t", f"{target_dur}",
            "-filter_complex", filt,
            "-map", "[v]",
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "medium", "-crf", "19",
            "-movflags", "+faststart",
            str(out_path),
        ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if result.returncode != 0:
        raise RuntimeError(f"story cut failed:\n{result.stderr[-2000:]}")


def main():
    p = argparse.ArgumentParser(description="Derive TikTok + Story cuts from main reel")
    p.add_argument("--main-reel", required=True, help="Path to main_reel.mp4")
    p.add_argument("--out-dir", required=True, help="Output directory")
    args = p.parse_args()

    main_reel = Path(args.main_reel).expanduser()
    if not main_reel.exists():
        eprint(f"error: main reel not found: {main_reel}")
        sys.exit(1)

    out_dir = Path(args.out_dir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    main_dur = probe_duration(main_reel)
    audio_present = has_audio(main_reel)
    eprint(f"main reel duration: {main_dur:.2f}s, audio: {'yes' if audio_present else 'no'}")

    tiktok_dur = min(TIKTOK_DURATION, main_dur)
    story_dur = min(STORY_DURATION, main_dur)

    results = []

    tiktok_path = out_dir / "tiktok.mp4"
    eprint(f"  cutting tiktok.mp4 (0-{tiktok_dur:.1f}s)")
    try:
        cut_tiktok(main_reel, tiktok_path, tiktok_dur, with_audio=audio_present)
        results.append({
            "file": "tiktok.mp4",
            "path": str(tiktok_path.resolve()),
            "duration_s": tiktok_dur,
            "bytes": tiktok_path.stat().st_size,
        })
        eprint(f"    ✓ {tiktok_path.stat().st_size:,} bytes")
    except RuntimeError as e:
        eprint(f"error: {e}")
        sys.exit(2)

    story_path = out_dir / "story.mp4"
    eprint(f"  cutting story.mp4 (0-{story_dur:.1f}s with fade)")
    try:
        cut_story(main_reel, story_path, story_dur, with_audio=audio_present)
        results.append({
            "file": "story.mp4",
            "path": str(story_path.resolve()),
            "duration_s": story_dur,
            "bytes": story_path.stat().st_size,
        })
        eprint(f"    ✓ {story_path.stat().st_size:,} bytes")
    except RuntimeError as e:
        eprint(f"error: {e}")
        sys.exit(2)

    print(json.dumps({
        "main_reel": str(main_reel.resolve()),
        "main_duration_s": main_dur,
        "outputs": results,
    }, indent=2))


if __name__ == "__main__":
    main()
