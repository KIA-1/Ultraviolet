#!/usr/bin/env python3
"""
meirvo-video-pipeline / generate_vo.py

Reads shot_plan.json, calls Gemini TTS (Autonoe voice) once per shot to
produce per-slot voiceover WAVs.

Gemini TTS returns raw 16-bit PCM at 24kHz mono; we wrap each response in
a minimal WAV header and write vo_01.wav ... vo_0N.wav.

Usage:
    python generate_vo.py \\
        --shot-plan ~/workspace/{sessionId}/video/shot_plan.json \\
        --out ~/workspace/{sessionId}/video/vo/ \\
        [--voice Autonoe] [--model gemini-2.5-flash-preview-tts]

Credentials (env):
    GEMINI_API_KEY

Exit codes: 0 = success, 1 = usage, 2 = some segments failed.
"""

import argparse
import base64
import concurrent.futures
import json
import os
import struct
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

DEFAULT_MODEL = "gemini-2.5-flash-preview-tts"
DEFAULT_VOICE = "Autonoe"
GEMINI_TTS_ENDPOINT_TPL = (
    "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
)
REQUEST_TIMEOUT = 180
MAX_RETRIES = 2

# Gemini TTS returns raw PCM 16-bit at 24000 Hz mono
PCM_SAMPLE_RATE = 24000
PCM_SAMPLE_WIDTH = 2   # bytes per sample (16-bit)
PCM_CHANNELS = 1


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def pcm16_to_wav(pcm_bytes: bytes, sample_rate: int = PCM_SAMPLE_RATE) -> bytes:
    """Wrap raw 16-bit PCM mono bytes in a minimal WAV header."""
    byte_rate = sample_rate * PCM_CHANNELS * PCM_SAMPLE_WIDTH
    block_align = PCM_CHANNELS * PCM_SAMPLE_WIDTH
    data_size = len(pcm_bytes)
    fmt_chunk_size = 16
    riff_size = 4 + (8 + fmt_chunk_size) + (8 + data_size)

    header = b"RIFF"
    header += struct.pack("<I", riff_size)
    header += b"WAVE"
    header += b"fmt "
    header += struct.pack("<I", fmt_chunk_size)
    header += struct.pack("<H", 1)  # PCM format
    header += struct.pack("<H", PCM_CHANNELS)
    header += struct.pack("<I", sample_rate)
    header += struct.pack("<I", byte_rate)
    header += struct.pack("<H", block_align)
    header += struct.pack("<H", PCM_SAMPLE_WIDTH * 8)
    header += b"data"
    header += struct.pack("<I", data_size)
    return header + pcm_bytes


def phonetic_hint(text: str) -> str:
    """Add a phonetic spelling hint for long number strings or obvious stumble cases.

    Simple rule: if a token is a long digit/alphanumeric (likely house number or ZIP),
    wrap it with spaces so the model reads digits individually.
    """
    # Keep simple — let Gemini TTS handle addresses directly.
    # This is a hook for future address-specific tuning.
    return text


def call_tts(api_key: str, text: str, voice: str, model: str) -> bytes:
    """Call Gemini TTS; return raw PCM bytes."""
    endpoint = GEMINI_TTS_ENDPOINT_TPL.format(model=model)
    url = f"{endpoint}?key={api_key}"
    body = json.dumps({
        "contents": [{"parts": [{"text": text}]}],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
            "speechConfig": {
                "voiceConfig": {
                    "prebuiltVoiceConfig": {"voiceName": voice},
                },
            },
        },
    }).encode("utf-8")

    req = urllib.request.Request(
        url, data=body, method="POST",
        headers={
            "Content-Type": "application/json",
            "User-Agent": "meirvo-video-pipeline/1.0",
        },
    )

    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
        raw = resp.read()

    data = json.loads(raw.decode("utf-8"))
    candidates = data.get("candidates", [])
    if not candidates:
        raise RuntimeError(f"TTS returned no candidates: {data!r}")
    parts = candidates[0].get("content", {}).get("parts", [])
    for part in parts:
        inline = part.get("inlineData") or part.get("inline_data")
        if inline and inline.get("data"):
            return base64.b64decode(inline["data"])
    raise RuntimeError(f"TTS response missing audio data: {data!r}")


def generate_one(idx: int, text: str, api_key: str, voice: str, model: str,
                 out_dir: Path) -> dict:
    """Generate one VO segment with retries. Returns manifest entry."""
    slot = idx + 1
    hinted = phonetic_hint(text)
    last_err = None
    for attempt in range(1, MAX_RETRIES + 2):
        try:
            pcm = call_tts(api_key, hinted, voice, model)
            wav = pcm16_to_wav(pcm)
            filename = f"vo_{slot:02d}.wav"
            filepath = out_dir / filename
            filepath.write_bytes(wav)
            duration_s = len(pcm) / (PCM_SAMPLE_RATE * PCM_SAMPLE_WIDTH * PCM_CHANNELS)
            eprint(f"  ✓ vo_{slot:02d}: {duration_s:.2f}s ({len(pcm):,} bytes PCM)")
            return {
                "slot": slot,
                "text": text,
                "localPath": str(filepath.resolve()),
                "duration_s": round(duration_s, 3),
                "ok": True,
            }
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                detail = e.read().decode("utf-8", errors="replace")[:200]
            except Exception:
                pass
            last_err = f"HTTP {e.code}: {detail}"
            eprint(f"  ! vo_{slot:02d} attempt {attempt} failed: {last_err}")
        except Exception as e:
            last_err = str(e)
            eprint(f"  ! vo_{slot:02d} attempt {attempt} failed: {last_err}")
        if attempt <= MAX_RETRIES:
            time.sleep(1.5 * attempt)

    return {
        "slot": slot,
        "text": text,
        "localPath": None,
        "duration_s": 0,
        "ok": False,
        "error": last_err,
    }


def main():
    p = argparse.ArgumentParser(description="Generate Gemini TTS voiceover segments")
    p.add_argument("--shot-plan", required=True, help="Path to shot_plan.json")
    p.add_argument("--out", required=True, help="Output directory for WAV files")
    p.add_argument("--voice", default=DEFAULT_VOICE, help=f"TTS voice (default {DEFAULT_VOICE})")
    p.add_argument("--model", default=DEFAULT_MODEL, help=f"TTS model (default {DEFAULT_MODEL})")
    p.add_argument("--max-workers", type=int, default=4,
                   help="Parallel TTS calls (default 4)")
    args = p.parse_args()

    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not api_key:
        eprint("error: GEMINI_API_KEY env var not set")
        sys.exit(1)

    shot_plan_path = Path(args.shot_plan).expanduser()
    try:
        plan = json.loads(shot_plan_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, FileNotFoundError) as e:
        eprint(f"error: could not load shot_plan.json: {e}")
        sys.exit(1)

    shots = plan.get("shots", [])
    if not shots:
        eprint("error: shot_plan.json has no shots")
        sys.exit(1)

    out_dir = Path(args.out).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    eprint(f"generating {len(shots)} TTS segment(s) with voice={args.voice} model={args.model}")

    results = [None] * len(shots)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.max_workers) as pool:
        futures = {
            pool.submit(generate_one, i, s["vo_text"], api_key,
                        args.voice, args.model, out_dir): i
            for i, s in enumerate(shots) if s.get("vo_text")
        }
        for fut in concurrent.futures.as_completed(futures):
            i = futures[fut]
            results[i] = fut.result()

    ok_count = sum(1 for r in results if r and r.get("ok"))
    fail_count = sum(1 for r in results if r and not r.get("ok"))
    manifest = {
        "n_segments": len(shots),
        "ok": ok_count,
        "failed": fail_count,
        "outDir": str(out_dir.resolve()),
        "segments": results,
    }
    print(json.dumps(manifest, indent=2, ensure_ascii=False))

    if fail_count > 0:
        sys.exit(2)


if __name__ == "__main__":
    main()
