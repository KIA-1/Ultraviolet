#!/usr/bin/env python3
"""
meirvo-video-pipeline / plan_shots.py  (v5 fast-cut, Jun 2026)

Deterministic shot planner for the Meirvo fast-cut reel contract.

WHAT CHANGED IN v5 (the "no more screensaver" revision):
  v4 played 7 slow Veo clips of ~5s each with 0.5s dissolves everywhere.
  Technically clean, editorially dead. Nobody watches a 5-second slow push.
  v5 keeps Veo generations slow and geometrically safe (fast camera moves
  melt architecture) but manufactures PACE in the edit:

    1. Each 8s Veo generation is sliced into 1-2 timeline SEGMENTS.
    2. Every segment plays at 1.25-1.6x speed (baked by slice_clips.py).
    3. Hard cuts by default. Dissolves only at 2 chapter moments
       (hook into hero reveal, closer into end card).
    4. Default 40.00s reel = ~16 cuts, average cut ~2.3s.

  Duration is no longer hardcoded: --total and --end-card are parameters.
  Default stays 40.00s because meirvo.com promises "40-second cinematic
  listing video". Change the site copy before changing the default.

STRUCTURE (defaults):
  9 Veo source generations (7 core shot types + 2 extras from photo_map)
  -> 16 timeline segments + 3.0s black end card = 40.00s total.
  Cost: ~$3 per generation, so ~$27 standard / ~$11 fast-mode smoke test.

VEO GENERATION CONTRACT (per source clip, unchanged geometry guards):
  durationSeconds 8, resolution 1080p, aspectRatio 9:16, mode standard
  (fast only for smoke tests). DO NOT pass personGeneration: the API
  rejects "dont_allow" since Jun 2026; the no-people guard rides in the
  prompt text plus the mandatory first/mid/late frame checks.

AGENT INPUTS (production quality):
  --photo-map map.json   {shot_type: filename} for the 7 core slots, decided
                         by LOOKING at the photos (multimodal). May also carry
                         "extras": [{"file": "...", "category":
                         "detail|room|exterior", "anchors": "..."}] entries.
                         The default 40s contract NEEDS 2 extras (9 gens).
  --anchors anchors.json {shot_type: "1-2 concrete visible details + light
                         direction"} baked into each Veo prompt.

Usage:
    python3 plan_shots.py listing.json \\
        --photos-dir ~/workspace/{sessionId}/prepped \\
        --photo-map ~/workspace/{sessionId}/photo_map.json \\
        --anchors ~/workspace/{sessionId}/anchors.json \\
        --out ~/workspace/{sessionId}/video/shot_plan.json \\
        [--total 40.0] [--end-card 3.0]

Pipeline after this script:
    GenerateVideo per veo_shots entry -> video/src/src_NN.mp4
    grade_clips.py --clips-dir video/src
    slice_clips.py --shot-plan shot_plan.json --src-dir video/src --out-dir video/clips
    make_endcard.py --out video/clips/clip_{last}.mp4 --seconds {end_card}
    prep_audio.py (music -20 LUFS, ducked under VO)
    build_meirvo_bundle.py + qc_bundle.py (exit 0 = ship)

Exit codes: 0 = success, 1 = usage error, 2 = Gemini API error (legacy vo only).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request
import urllib.error
from pathlib import Path

DEFAULT_MODEL = "gemini-2.5-flash"
GEMINI_ENDPOINT_TPL = (
    "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
)
REQUEST_TIMEOUT = 120

# ---------------------------------------------------------------------------
# v5 fast-cut grammar
# ---------------------------------------------------------------------------
# Each core slot: (shot_type, n_segments, (speed per segment,))
# Speeds are PLAYBACK multipliers baked at slice time. Veo is asked for
# steady confident moves; the cut supplies the energy. 2-segment slots
# slice one continuous move into two beats separated by a small source gap
# (reads as an intentional jump cut on the same shot language).
CORE_SEQUENCE = [
    ("detail_hook",     1, (1.6,)),
    ("hero_exterior",   2, (1.35, 1.45)),
    ("living_room",     2, (1.40, 1.50)),
    ("kitchen",         2, (1.35, 1.45)),
    ("primary_bedroom", 2, (1.40, 1.50)),
    ("feature_space",   2, (1.25, 1.30)),
    # extras are inserted here (each 2 segments)
    ("exterior_closer", 1, (1.25,)),
]
EXTRA_SPEEDS = {"detail": (1.45, 1.55), "room": (1.40, 1.50), "exterior": (1.30, 1.40)}

# Source-consumption guards (per 8s Veo generation)
MAX_SRC_END = 7.2    # never slice past this point (drift tail); late-frame check still mandatory
SRC_GAP = 0.4        # source seconds skipped between segment A and B (intentional jump cut)
SEG_SPLIT = 0.55     # segment A share of a 2-seg slot's timeline
SEG_ROUND = 0.05     # timeline durations land on this grid

# Chapter dissolves (everything else is a hard cut, xfade_out 0.0)
HOOK_DISSOLVE = 0.35     # hook -> hero exterior reveal
CLOSER_DISSOLVE = 0.5    # closer -> black end card

# Veo 3.1 generation contract (native GenerateVideo tool).
# personGeneration intentionally ABSENT: the API rejects "dont_allow" for
# image-to-video since Jun 2026. Omit the parameter entirely.
VEO_GEN = {
    "durationSeconds": 8,
    "resolution": "1080p",
    "aspectRatio": "9:16",
    "mode_production": "standard",
    "mode_smoke_test": "fast",
}

# Maps shot_type to overlay key (render_overlays.py) for the v3 ffmpeg FALLBACK only.
SHOT_OVERLAY_MAP = {
    "detail_hook": "intro_title",
    "hero_exterior": "data_card",
    "kitchen": None,
    "living_room": None,
    "primary_bedroom": None,
    "feature_space": None,
    "exterior_closer": "cta_card",
    "end_card": None,
}

# Locked guard appended to every Veo prompt. The native GenerateVideo tool has
# no negativePrompt parameter, so all negatives ride inside the prompt text.
VEO_STATIC_RULE = (
    " Locked rules: only the camera moves; every object stays static. "
    "No people, no human figures, no pets, no vehicles. No text, no labels, "
    "no signage, no logos, no captions, no graphic overlays. Preserve all "
    "existing architectural features exactly: no modifications to walls, "
    "floors, windows, doors, or structural elements. Correct architectural "
    "proportions, straight edges on all surfaces, rigid rectilinear lines, "
    "all furniture physically grounded on the floor. No new furniture or "
    "objects appear."
)

# v5 prompt grammar: "steady" and "confident", never "slow" or "very gentle"
# (v4's language produced footage that read as a screensaver even before the
# edit), and never "fast" or "whip" (fast camera moves melt geometry; the
# 1.25-1.6x playback supplies the perceived speed). "One continuous move"
# matters because both slices of a generation must share shot language.
VEO_PROMPT_TEMPLATES = {
    "detail_hook": (
        "Confident cinematic push-in on {anchors}. The camera is already moving "
        "on the very first frame and holds one continuous steady push for the "
        "entire shot. Warm natural light, shallow depth of field implied, "
        "editorial real estate photography aesthetic. "
        "Camera: steady dolly forward at a confident pace, no rotation, one "
        "continuous move." + VEO_STATIC_RULE
    ),
    "hero_exterior": (
        "Steady forward approach toward the home. {anchors}. Natural daylight "
        "with long soft shadows, photorealistic exterior architectural shot. "
        "Camera: smooth dolly forward at a confident steady pace, no rotation, "
        "constant height, one continuous move for the entire shot." + VEO_STATIC_RULE
    ),
    "living_room": (
        "Smooth dolly forward through the living space. {anchors}. Natural "
        "window light, consistent white balance, warm editorial tone. "
        "Camera: steady dolly forward at a confident pace, no rotation, one "
        "continuous move." + VEO_STATIC_RULE
    ),
    "kitchen": (
        "Smooth lateral truck across the kitchen. {anchors}. Cabinet faces, "
        "countertop edges, and grout lines stay perfectly straight and rigid. "
        "Natural window light. "
        "Camera: steady truck left to right at an even pace, no zoom toward "
        "surfaces, one continuous move." + VEO_STATIC_RULE
    ),
    "primary_bedroom": (
        "Steady push-in through the primary bedroom. {anchors}. Soft natural "
        "window light, calm and composed. "
        "Camera: smooth dolly forward at an even confident pace, no rotation, "
        "one continuous move." + VEO_STATIC_RULE
    ),
    "feature_space": (
        "Locked-off camera with lively atmospheric motion: light shifting "
        "through the windows, soft shadow movement. {anchors}. Calm, premium, "
        "editorial. Camera: static, atmosphere only." + VEO_STATIC_RULE
    ),
    "exterior_closer": (
        "Steady backward pull-back revealing the home and its setting. "
        "{anchors}. Warm late-afternoon light, interior lights glowing through "
        "the windows, photorealistic. "
        "Camera: smooth dolly backward at a confident pace, no rotation, one "
        "continuous move." + VEO_STATIC_RULE
    ),
    # extras
    "extra_detail": (
        "Confident cinematic push-in on {anchors}. The camera is already moving "
        "on the very first frame. Warm natural light, editorial real estate "
        "photography aesthetic. "
        "Camera: steady dolly forward at a confident pace, no rotation, one "
        "continuous move." + VEO_STATIC_RULE
    ),
    "extra_room": (
        "Steady dolly forward through the space. {anchors}. Natural window "
        "light, consistent white balance, editorial tone. "
        "Camera: smooth dolly forward at a confident pace, no rotation, one "
        "continuous move." + VEO_STATIC_RULE
    ),
    "extra_exterior": (
        "Smooth lateral drift across the exterior space. {anchors}. Natural "
        "daylight, photorealistic. "
        "Camera: very steady truck at constant height, no rotation, one "
        "continuous move." + VEO_STATIC_RULE
    ),
}

# Music mood -> track filename (from ~/workspace/music_library/)
MUSIC_MOOD_MAP = {
    "warm": "01_hopeful_corporate.wav",
    "hopeful": "01_hopeful_corporate.wav",
    "corporate": "01_hopeful_corporate.wav",
    "default": "01_hopeful_corporate.wav",
    "inspiring": "02_inspiring_violins.wav",
    "uplifting": "02_inspiring_violins.wav",
    "violins": "02_inspiring_violins.wav",
    "energetic": "03_unchained.wav",
    "unchained": "03_unchained.wav",
    "upbeat": "03_unchained.wav",
    "epic": "04_uplifting_epic.wav",
    "cinematic": "04_uplifting_epic.wav",
    "dramatic": "04_uplifting_epic.wav",
    "positive": "05_positive.wav",
    "happy": "05_positive.wav",
    "playful": "05_positive.wav",
}

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".heic", ".heif", ".webp"}

CORE_TYPES = [st for st, _, _ in CORE_SEQUENCE]


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def resolve_music(music_mood: str) -> str:
    mood = (music_mood or "").strip().lower()
    if not mood:
        return MUSIC_MOOD_MAP["default"]
    if mood in MUSIC_MOOD_MAP:
        return MUSIC_MOOD_MAP[mood]
    for token in mood.replace(",", " ").split():
        if token in MUSIC_MOOD_MAP:
            return MUSIC_MOOD_MAP[token]
    eprint(f"  ? unknown musicMood '{music_mood}', falling back to default track")
    return MUSIC_MOOD_MAP["default"]


def list_photos(photos_dir: Path) -> list:
    if not photos_dir.exists():
        return []
    return [p for p in sorted(photos_dir.iterdir())
            if p.is_file() and p.suffix.lower() in IMAGE_EXTS]


def resolve_photo(ref: str, by_name: dict) -> Path | None:
    photo = by_name.get(str(ref)) or by_name.get(Path(str(ref)).name)
    if photo is None and Path(str(ref)).expanduser().is_file():
        photo = Path(str(ref)).expanduser()
    return photo


def build_slots(photos: list, photo_map: dict | None, anchors: dict) -> list:
    """Build the ordered list of Veo source slots.

    Returns list of dicts: {shot_type, template_key, photo, n_segs, speeds, anchors}.
    Core 7 from photo_map (or blind fallback); extras from photo_map["extras"].
    """
    if len(photos) < 3:
        raise SystemExit(
            f"only {len(photos)} photo(s) found; need at least 3 (intake asks for 10-30). "
            "Ask the operator for more photos instead of producing a thin reel."
        )
    by_name = {p.name: p for p in photos}

    generic_anchor = {
        "detail_hook": "the room's single strongest visual feature",
        "hero_exterior": "the home's facade and architectural lines",
        "living_room": "the main living space and its window light",
        "kitchen": "the kitchen's counters and cabinetry",
        "primary_bedroom": "the primary bedroom and its natural light",
        "feature_space": "the space's strongest feature",
        "exterior_closer": "the home and its surrounding setting",
    }

    core_slots = []
    extras = []
    if photo_map:
        missing = [st for st in CORE_TYPES if st not in photo_map]
        if missing:
            raise SystemExit(
                f"photo_map is missing core shot types: {missing}. Map every core slot "
                "(reuse a photo if the listing lacks a room; pick the closest match)."
            )
        for shot_type, n_segs, speeds in CORE_SEQUENCE:
            photo = resolve_photo(photo_map[shot_type], by_name)
            if photo is None:
                raise SystemExit(f"photo_map[{shot_type}] = {photo_map[shot_type]!r} not found in photos dir")
            anchor_text = str(anchors.get(shot_type, "")).strip() or generic_anchor[shot_type]
            core_slots.append({
                "shot_type": shot_type, "template_key": shot_type, "photo": photo,
                "n_segs": n_segs, "speeds": list(speeds), "anchors": anchor_text,
            })
        for i, ex in enumerate(photo_map.get("extras", []) or []):
            ref = ex.get("file") or ex.get("filename") or ""
            photo = resolve_photo(ref, by_name)
            if photo is None:
                raise SystemExit(f"photo_map extras[{i}] file {ref!r} not found in photos dir")
            category = str(ex.get("category", "room")).strip().lower()
            if category not in EXTRA_SPEEDS:
                category = "room"
            anchor_text = (str(ex.get("anchors", "")).strip()
                           or str(anchors.get(f"extra_{i + 1}", "")).strip()
                           or "the space's strongest visible feature")
            extras.append({
                "shot_type": f"extra_{i + 1}_{category}",
                "template_key": f"extra_{category}", "photo": photo,
                "n_segs": 2, "speeds": list(EXTRA_SPEEDS[category]), "anchors": anchor_text,
            })
    else:
        eprint(
            "  !! BLIND ASSIGNMENT: no --photo-map given. Photos assigned to room "
            "slots by sort order, so prompts may describe the wrong room. NEVER "
            "ship production output from this path."
        )
        for i, (shot_type, n_segs, speeds) in enumerate(CORE_SEQUENCE):
            core_slots.append({
                "shot_type": shot_type, "template_key": shot_type,
                "photo": photos[i % len(photos)], "n_segs": n_segs,
                "speeds": list(speeds), "anchors": generic_anchor[shot_type],
            })

    # Editorial order: hook, hero, living, kitchen, primary, feature, extras, closer
    ordered = core_slots[:-1] + extras + [core_slots[-1]]
    return ordered


def slot_capacity(slot: dict, xf_by_seg: list) -> float:
    """Max timeline seconds this slot can carry from one 8s generation."""
    k = slot["n_segs"]
    speeds = slot["speeds"]
    budget = MAX_SRC_END - SRC_GAP * (k - 1)
    # source = sum((dur_j + xf_j) * speed_j); with dur_j = share_j * T
    shares = [1.0] if k == 1 else [SEG_SPLIT, 1.0 - SEG_SPLIT]
    denom = sum(shares[j] * speeds[j] for j in range(k))
    fixed = sum(xf_by_seg[j] * speeds[j] for j in range(k))
    return max((budget - fixed) / denom, 0.0)


def allocate_durations(slots: list, content: float, hook_s: float, closer_s: float) -> list:
    """Assign timeline duration to every slot. Returns per-slot totals.

    Hook and closer are fixed (bumpable to caps when there is residual time).
    Middle slots share the remainder equally, clamped by per-generation
    source capacity. Hard-fails with guidance when the math cannot close.
    """
    HOOK_CAP, CLOSER_CAP = 2.6, 4.2
    n = len(slots)
    totals = [0.0] * n
    totals[0] = hook_s
    totals[-1] = closer_s

    # xfades per slot segment (only hook and closer carry dissolves)
    def xfades_for(idx: int, slot: dict) -> list:
        k = slot["n_segs"]
        xf = [0.0] * k
        if idx == 0:
            xf[-1] = HOOK_DISSOLVE
        if idx == n - 1:
            xf[-1] = CLOSER_DISSOLVE
        return xf

    caps = [slot_capacity(s, xfades_for(i, s)) for i, s in enumerate(slots)]
    if hook_s > caps[0] + 1e-6 or closer_s > caps[-1] + 1e-6:
        raise SystemExit(f"hook/closer seconds exceed per-generation capacity "
                         f"(hook cap {caps[0]:.2f}, closer cap {caps[-1]:.2f})")

    middle = list(range(1, n - 1))
    remaining = content - hook_s - closer_s
    if remaining <= 0:
        raise SystemExit("content too short for hook + closer; raise --total")

    # Equal fair share, clamped by capacity; iterate to redistribute clamped surplus
    unassigned = set(middle)
    while unassigned:
        fair = remaining / len(unassigned)
        clamped = [i for i in unassigned if caps[i] < fair - 1e-9]
        if not clamped:
            for i in unassigned:
                totals[i] = fair
            remaining = 0.0
            unassigned = set()
            break
        for i in clamped:
            totals[i] = caps[i]
            remaining -= caps[i]
            unassigned.discard(i)
        if remaining < -1e-6:
            raise SystemExit("internal allocation error (negative remainder)")

    # Residual (middle slots all capped): bump closer then hook toward caps
    if remaining > 1e-6:
        bump = min(remaining, CLOSER_CAP - totals[-1])
        totals[-1] += bump
        remaining -= bump
    if remaining > 1e-6:
        bump = min(remaining, HOOK_CAP - totals[0])
        totals[0] += bump
        remaining -= bump
    if remaining > 1e-6:
        need = remaining
        raise SystemExit(
            f"cannot fill {content:.2f}s of content from {n} Veo generations "
            f"({need:.2f}s short). Fix: add extras to photo_map (each extra adds "
            f"~4.5s of capacity) or lower --total. The default 40.00s contract "
            f"needs 9 generations: 7 core + 2 extras."
        )
    return totals


def build_segments(slots: list, totals: list, end_card_s: float, content: float) -> list:
    """Expand slots into orderd timeline segments with slice geometry."""
    n = len(slots)
    segs = []
    for i, (slot, T) in enumerate(zip(slots, totals)):
        k = slot["n_segs"]
        shares = [1.0] if k == 1 else [SEG_SPLIT, 1.0 - SEG_SPLIT]
        for j in range(k):
            xf = 0.0
            if i == 0 and j == k - 1:
                xf = HOOK_DISSOLVE
            if i == n - 1 and j == k - 1:
                xf = CLOSER_DISSOLVE
            segs.append({
                "slot_index": i, "seg_index": j,
                "shot_type": slot["shot_type"],
                "speed": slot["speeds"][j],
                "duration": shares[j] * T,
                "xfade_out": xf,
            })

    # Round to grid, absorb drift in the final content segment (the closer)
    for s in segs:
        s["duration"] = round(round(s["duration"] / SEG_ROUND) * SEG_ROUND, 2)
    drift = round(content - sum(s["duration"] for s in segs), 2)
    segs[-1]["duration"] = round(segs[-1]["duration"] + drift, 2)
    if segs[-1]["duration"] < 1.0:
        raise SystemExit("rounding drift collapsed the closer segment; adjust --total/--end-card")

    # Slice geometry per source generation
    by_slot: dict = {}
    for s in segs:
        by_slot.setdefault(s["slot_index"], []).append(s)
    for slot_idx, slot_segs in by_slot.items():
        cursor = 0.0
        for s in sorted(slot_segs, key=lambda x: x["seg_index"]):
            need_src = (s["duration"] + s["xfade_out"]) * s["speed"]
            s["src_in"] = round(cursor, 3)
            s["src_out"] = round(cursor + need_src, 3)
            cursor += need_src + SRC_GAP
        last = max(s["src_out"] for s in slot_segs)
        if last > MAX_SRC_END + 0.05:
            raise SystemExit(
                f"slot {slot_idx + 1} ({slot_segs[0]['shot_type']}) needs source up to "
                f"{last:.2f}s > {MAX_SRC_END}s budget. Internal capacity bug; report."
            )
    return segs


def build_vo_prompt(listing: dict, slots: list) -> str:
    """Legacy Gemini per-slot VO (v3 ffmpeg fallback only)."""
    addr = listing.get("address", "this home")
    features = listing.get("features", "")
    if isinstance(features, list):
        features = ", ".join(features)
    shot_lines = [f"  Shot {i+1}: {s['shot_type']} (VO max 10 words)" for i, s in enumerate(slots)]
    return (
        f"Write a voiceover script for a real estate listing video.\n\n"
        f"Address: {addr}\nFeatures: {features}\n\n"
        f"SHOT PLAN:\n" + "\n".join(shot_lines) + "\n\n"
        f"Write exactly ONE line per shot, numbered. Max 10 words each. Warm, "
        f"confident, editorial. No em dashes, no real estate cliches (stunning, "
        f"nestled, boasts, oasis, must-see). Output only the numbered lines."
    )


def call_gemini(api_key: str, prompt: str, model: str) -> str:
    endpoint = GEMINI_ENDPOINT_TPL.format(model=model)
    url = f"{endpoint}?key={api_key}"
    body = json.dumps({
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.85, "maxOutputTokens": 2048, "topP": 0.95},
    }).encode("utf-8")
    req = urllib.request.Request(
        url, data=body, method="POST",
        headers={"Content-Type": "application/json", "User-Agent": "meirvo-video-pipeline/1.0"},
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")[:500]
        raise RuntimeError(f"Gemini HTTP {e.code}: {detail}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Gemini network error: {e.reason}") from e
    data = json.loads(raw.decode("utf-8"))
    candidates = data.get("candidates", [])
    if not candidates:
        raise RuntimeError(f"Gemini returned no candidates: {data!r}")
    parts = candidates[0].get("content", {}).get("parts", [])
    text = "".join(p.get("text", "") for p in parts if "thought" not in p).strip()
    if not text:
        raise RuntimeError("Gemini returned empty text")
    return text


def parse_vo_lines(raw: str, expected: int) -> list:
    import re
    lines_raw = [ln.rstrip() for ln in raw.splitlines()]
    lines = [None] * expected
    current_idx, current_text = None, []
    number_pat = re.compile(r"^\s*(\d+)\s*[.\):\-]\s*(.*)")
    for ln in lines_raw:
        m = number_pat.match(ln)
        if m:
            if current_idx is not None and 0 <= current_idx - 1 < expected:
                lines[current_idx - 1] = " ".join(current_text).strip()
            current_idx = int(m.group(1))
            current_text = [m.group(2)] if m.group(2) else []
        elif current_idx is not None and ln.strip():
            current_text.append(ln.strip())
    if current_idx is not None and 0 <= current_idx - 1 < expected:
        lines[current_idx - 1] = " ".join(current_text).strip()
    if all(x is None for x in lines):
        fallback = [ln.strip() for ln in lines_raw if ln.strip()][:expected]
        for i, v in enumerate(fallback):
            lines[i] = v
    defaults = ["Come walk through it.", "Worth seeing in person.", "Book a showing and feel it yourself."]
    for i in range(expected):
        if not lines[i]:
            lines[i] = defaults[i % len(defaults)]
    return lines


def main():
    p = argparse.ArgumentParser(description="Plan a Meirvo fast-cut listing reel (v5)")
    p.add_argument("listing", help="Listing JSON file, or '-' for stdin")
    p.add_argument("--photos-dir", required=True, help="Directory containing prepped 9:16 photos")
    p.add_argument("--out", required=True, help="Output path for shot_plan.json")
    p.add_argument("--photo-map", help="JSON {shot_type: filename} + optional extras list. "
                                       "Required for production quality.")
    p.add_argument("--anchors", help="JSON {shot_type: 'concrete visible details + light direction'}")
    p.add_argument("--total", type=float, default=40.0,
                   help="Reel total seconds INCLUDING end card (default 40.0; meirvo.com promises 40)")
    p.add_argument("--end-card", type=float, default=3.0,
                   help="Black end card seconds (default 3.0; was 5.0 in v4, too slow)")
    p.add_argument("--hook-seconds", type=float, default=2.2)
    p.add_argument("--closer-seconds", type=float, default=3.0)
    p.add_argument("--vo-mode", choices=["agent", "gemini", "none"], default="agent",
                   help="agent (default): single agent-written narration track, no API key. "
                        "gemini: legacy per-shot VO for the v3 ffmpeg fallback. none: music-only.")
    p.add_argument("--model", default=DEFAULT_MODEL)
    # Deprecated flags kept so old invocations don't crash:
    p.add_argument("--max-shots", type=int, default=None, help="DEPRECATED, ignored")
    p.add_argument("--shot-duration", type=float, default=None, help="DEPRECATED, ignored")
    p.add_argument("--skip-gemini", action="store_true", help="DEPRECATED: same as --vo-mode agent")
    args = p.parse_args()

    if args.max_shots is not None or args.shot_duration is not None:
        eprint("  ! --max-shots/--shot-duration are deprecated and ignored (v5 derives "
               "structure from photo_map + --total)")
    if args.skip_gemini:
        args.vo_mode = "agent"
    if not (12.0 <= args.total <= 90.0):
        eprint(f"error: --total {args.total} outside sane range 12-90s")
        sys.exit(1)
    if not (2.0 <= args.end_card <= 6.0):
        eprint(f"error: --end-card {args.end_card} outside sane range 2-6s")
        sys.exit(1)

    try:
        raw = sys.stdin.read() if args.listing == "-" else Path(args.listing).read_text()
        listing = json.loads(raw)
    except (json.JSONDecodeError, FileNotFoundError, IOError) as e:
        eprint(f"error: could not load listing JSON: {e}")
        sys.exit(1)

    photos_dir = Path(args.photos_dir).expanduser()
    photos = list_photos(photos_dir)
    if not photos:
        eprint(f"error: no image files found in {photos_dir}")
        sys.exit(1)
    eprint(f"found {len(photos)} photo(s) in {photos_dir}")

    photo_map = None
    if args.photo_map:
        with open(args.photo_map) as f:
            photo_map = json.load(f)
    anchors: dict = {}
    if args.anchors:
        with open(args.anchors) as f:
            anchors = json.load(f)
    else:
        eprint("  ! no --anchors file: Veo prompts will use generic room language.")

    slots = build_slots(photos, photo_map, anchors)
    content = round(args.total - args.end_card, 2)
    totals = allocate_durations(slots, content, args.hook_seconds, args.closer_seconds)
    segs = build_segments(slots, totals, args.end_card, content)

    n_gens = len(slots)
    n_segs = len(segs)
    avg_cut = content / n_segs
    eprint(f"planning {n_gens} Veo generations -> {n_segs} timeline cuts "
           f"(avg {avg_cut:.2f}s) + {args.end_card:.1f}s end card = {args.total:.2f}s")

    # Legacy gemini VO (per source slot)
    vo_lines = [""] * n_gens
    if args.vo_mode == "gemini":
        api_key = os.environ.get("GEMINI_API_KEY", "").strip()
        if not api_key:
            eprint("error: GEMINI_API_KEY env var not set (use --vo-mode agent instead)")
            sys.exit(1)
        try:
            vo_lines = parse_vo_lines(call_gemini(api_key, build_vo_prompt(listing, slots), args.model),
                                      expected=n_gens)
        except RuntimeError as e:
            eprint(f"error: Gemini call failed: {e}")
            sys.exit(2)

    music_mood = listing.get("musicMood", "default")
    music_track = resolve_music(music_mood)

    # --- veo_shots: what the agent generates (one per source slot) ---
    veo_shots = []
    for i, slot in enumerate(slots):
        veo_prompt = VEO_PROMPT_TEMPLATES[slot["template_key"]].replace("{anchors}", slot["anchors"])
        veo_shots.append({
            "slot_number": i + 1,
            "filename": f"src_{i + 1:02d}.mp4",
            "shot_type": slot["shot_type"],
            "source_photo": str(slot["photo"].resolve()),
            "source_photo_name": slot["photo"].name,
            "anchors": slot["anchors"],
            "vo_text": vo_lines[i],
            "overlay_key": SHOT_OVERLAY_MAP.get(slot["shot_type"].split("_")[0] if slot["shot_type"].startswith("extra") else slot["shot_type"]),
            "n_segments": slot["n_segs"],
            "veo_duration_s": VEO_GEN["durationSeconds"],
            "veo_resolution": VEO_GEN["resolution"],
            "veo_aspect_ratio": VEO_GEN["aspectRatio"],
            "veo_prompt": veo_prompt,
        })

    # --- shots: the timeline segments the bundle plays (1:1 with clips/) ---
    shots = []
    for i, s in enumerate(segs):
        shots.append({
            "index": i,
            "slot_number": i + 1,
            "filename": f"clip_{i + 1:02d}.mp4",
            "shot_type": s["shot_type"],
            "source_clip": f"src_{s['slot_index'] + 1:02d}.mp4",
            "src_in": s["src_in"],
            "src_out": s["src_out"],
            "speed": s["speed"],
            "duration": s["duration"],
            "duration_s": s["duration"],
            "xfade_out": s["xfade_out"],
            "vo_text": "",
        })
    shots.append({
        "index": len(shots),
        "slot_number": len(shots) + 1,
        "filename": f"clip_{len(shots) + 1:02d}.mp4",
        "shot_type": "end_card",
        "source_clip": None,
        "speed": 1.0,
        "duration": args.end_card,
        "duration_s": args.end_card,
        "xfade_out": 0.0,
        "vo_text": "",
        "note": f"python3 make_endcard.py --out video/clips/clip_{len(shots) + 1:02d}.mp4 "
                f"--seconds {args.end_card} (solid #0E0C0A, 1080x1920, 24fps)",
    })

    total_duration = round(sum(s["duration"] for s in shots), 2)
    narration_end_by = round(content - 2.0, 2)
    plan = {
        "address": listing.get("address", ""),
        "plan_version": "v5",
        "pacing": "fast-cut",
        "n_veo_generations": n_gens,
        "n_timeline_cuts": n_segs,
        "avg_cut_s": round(avg_cut, 2),
        "n_shots": len(shots),
        "reel_duration_s": total_duration,
        "content_seconds": content,
        "end_card_seconds": args.end_card,
        "photo_assignment": "agent_classified" if photo_map else "BLIND_FALLBACK_DO_NOT_SHIP",
        "music_mood": music_mood,
        "music_track": music_track,
        "veo_generation_contract": {
            "durationSeconds": VEO_GEN["durationSeconds"],
            "resolution": VEO_GEN["resolution"],
            "aspectRatio": VEO_GEN["aspectRatio"],
            "mode": "standard for production, fast for smoke tests",
            "personGeneration": "OMIT THIS PARAMETER. The API rejects dont_allow for "
                                "image-to-video (Jun 2026). No-people guard = prompt "
                                "negatives + mandatory frame checks.",
            "why_8s": "Veo 3.1 image-to-video at 1080p only accepts 8s; segments slice "
                      "the 0.0-7.2s window and the late tail is never used",
            "frame_checks": "extract + Read first, middle, AND late (~6.5s) frames of "
                            "every generation before slicing; regenerate on warp/text/people",
        },
        "edit_contract": {
            "transitions": "hard cuts everywhere except hook dissolve "
                           f"({HOOK_DISSOLVE}s) and closer-to-end-card ({CLOSER_DISSOLVE}s)",
            "speed_ramps": "per-segment playback 1.25-1.6x baked by slice_clips.py",
            "slicer": "slice_clips.py --shot-plan ... --src-dir video/src --out-dir video/clips",
        },
        "narration_spec": {
            "mode": "single_track",
            "engine": "native GenerateAudio (Gemini TTS, voice Autonoe) unless operator supplies VO",
            "start_at_s": 1.6,
            "must_end_by_s": narration_end_by,
            "target_seconds": [15, 18],
            "word_budget": [40, 46],
            "style": [
                "confident and present; the cut is fast, the voice stays composed",
                "open on the property's strongest hook, not the address",
                "one concrete sensory detail per beat: a material, a light quality, a proportion",
                "close with a short human invitation, e.g. 'Come walk through it.'",
                "no em dashes; no real-estate cliches (stunning, nestled, boasts, oasis, must-see)",
            ],
        },
        "narration_script": "",
        "qc_contract": {
            "expect_total_s": args.total,
            "canvas": [1080, 1920],
            "fps": 24,
            "vo_lufs": -16,
            "music_lufs": -20,
            "music_duck": "music ducks >= 4 dB under narration (prep_audio.py bakes it)",
            "min_content_cuts": 12,
            "max_avg_cut_s": 3.0,
            "end_card_seconds": args.end_card,
            "validator": f"qc_bundle.py --expect-total {args.total} (preset fast): must exit 0 before shipping",
        },
        "veo_shots": veo_shots,
        "shots": shots,
        "listing_snapshot": {
            "address": listing.get("address", ""),
            "price": listing.get("price", ""),
            "bedrooms": listing.get("bedrooms", ""),
            "bathrooms": listing.get("bathrooms", ""),
            "interiorSize": listing.get("interiorSize", ""),
            "agentName": listing.get("agentName", ""),
            "brokerage": listing.get("brokerage", ""),
        },
    }

    out_path = Path(args.out).expanduser()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(plan, indent=2, ensure_ascii=False))
    eprint(f"wrote shot plan -> {out_path}")

    print(json.dumps({
        "outPath": str(out_path.resolve()),
        "plan_version": "v5",
        "n_veo_generations": n_gens,
        "n_timeline_cuts": n_segs,
        "avg_cut_s": round(avg_cut, 2),
        "reel_duration_s": total_duration,
        "est_veo_cost_usd": f"~${n_gens * 3} standard mode (~$3/generation)",
        "photo_assignment": plan["photo_assignment"],
        "music_track": music_track,
        "narration": "agent writes narration_script (see narration_spec), then GenerateAudio + prep_audio.py",
        "veo_generations_preview": [
            {
                "slot": v["slot_number"],
                "file": v["filename"],
                "shot_type": v["shot_type"],
                "source_photo": v["source_photo_name"],
                "segments": v["n_segments"],
                "anchors": v["anchors"],
            } for v in veo_shots
        ],
        "segments_preview": [
            {
                "clip": s["filename"], "type": s["shot_type"], "dur": s["duration"],
                "speed": s.get("speed"), "src": s.get("source_clip"),
                "src_in": s.get("src_in"), "xfade": s["xfade_out"],
            } for s in shots
        ],
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
