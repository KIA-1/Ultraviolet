#!/usr/bin/env python3
"""
hyperframes-bundle · build_meirvo_bundle.py

Meirvo-specific wrapper around build_bundle.py. Takes a Meirvo session dir
(as produced by meirvo-video-pipeline-v3 Phases A + B) plus a listing JSON,
constructs Meirvo brand overlays, and invokes build_bundle.py.

Expected session dir layout (from meirvo-video-pipeline-v3):
  {session_dir}/
    clips/
      clip_01.mp4 ... clip_06.mp4
    shot_plan.json
    tts.wav           (optional: pass via --tts if elsewhere)
    music.wav         (optional: pass via --music if elsewhere)

Listing JSON contract (minimum):
  {
    "address": "742 Evergreen Terrace",
    "short_address": "742 EVERGREEN TER",   // optional, falls back to address uppercased
    "price": 485000,
    "price_display": "$485,000",            // optional, falls back to formatted price
    "beds": 3,
    "baths": 2,
    "sqft": 1840,
    "agent_name": "Ned Flanders",           // optional, used in README only
    "session_id": "smoke-test-610214005764"
  }

Usage:
  python3 build_meirvo_bundle.py \\
      --session-dir ~/workspace/smoke-test-610214005764 \\
      --listing ~/workspace/smoke-test-610214005764/listing.json \\
      --tts  ~/workspace/smoke-test-610214005764/tts.wav \\
      --music ~/workspace/smoke-test-610214005764/music.wav \\
      --output ~/workspace/smoke-test-610214005764/render_bundle \\
      --zip

Sandbox-safe. No render, no Chrome, no ffmpeg beyond optional probe.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Meirvo brand tokens (locked Apr 20 2026)
# ---------------------------------------------------------------------------

REEL_BRAND = {
    # The wordmark TEXT is looked up dynamically per-listing below
    # (listing.brokerage first, then listing.agent_name, then a safe fallback).
    # These tokens are the style layer only.
    "name": "LISTING",  # placeholder; overridden at runtime from listing dict
    "bg": "#0E0C0A",       # Ink
    "ink": "#F4F0E8",      # Ivory on dark
    "accent": "#C65A2E",   # Rust
    "muted": "#6B6560",
    "heading_font": "Instrument Serif",
    "body_font": "Inter",
    "font_import_url": "https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Inter:wght@400;500;600;700&display=block",
    "wordmark_position": "top-right",
}

# Aliases kept for backwards compat with any tooling that imports the old names.
SPECTOWER_BRAND = REEL_BRAND
MEIRVO_BRAND = REEL_BRAND


def resolve_wordmark(listing: dict) -> str:
    """Pick the top-right wordmark text for a listing reel.

    Order of preference:
      1. listing.brokerage           (the brokerage / company sourcing the listing)
      2. listing.brokerage_name      (alt key)
      3. listing.company             (alt key)
      4. listing.agent_name          (fallback: solo agents brand as themselves)
      5. listing.agentName           (alt camelCase)
      6. "LISTING"                   (last-resort placeholder)

    Result is uppercased, trimmed, and capped at 32 chars so long brokerage
    names don't blow the top-right layout.
    """
    for key in ("brokerage", "brokerage_name", "company", "agent_name", "agentName"):
        val = listing.get(key)
        if val and str(val).strip():
            return str(val).strip().upper()[:32]
    return "LISTING"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def log(msg: str) -> None:
    print(f"[meirvo-bundle] {msg}", file=sys.stderr)


def format_price(listing: dict) -> str:
    if "price_display" in listing and listing["price_display"]:
        return str(listing["price_display"])
    price = listing.get("price")
    if price is None:
        return "$-"
    try:
        return f"${int(price):,}"
    except (TypeError, ValueError):
        return str(price)


def format_specs(listing: dict) -> str:
    """3 BD · 2 BA · 1,840 SQFT: with middot separator."""
    parts = []
    beds = listing.get("beds")
    baths = listing.get("baths")
    sqft = listing.get("sqft")
    if beds is not None:
        parts.append(f"{beds} BD")
    if baths is not None:
        parts.append(f"{baths} BA")
    if sqft is not None:
        try:
            parts.append(f"{int(sqft):,} SQFT")
        except (TypeError, ValueError):
            parts.append(f"{sqft} SQFT")
    return " · ".join(parts) if parts else ""


def short_address(listing: dict) -> str:
    if listing.get("short_address"):
        return str(listing["short_address"]).upper()
    # Fallback: uppercase first 40 chars of address
    addr = str(listing.get("address", "")).strip()
    return addr.upper()[:40]


def _autoscale_font(base_px: int, text: str, max_chars: int, floor_px: int) -> str:
    """Scale a display font down for long strings so it never overflows the safe area."""
    n = max(len(text), 1)
    if n <= max_chars:
        return f"{base_px}px"
    return f"{max(int(base_px * max_chars / n), floor_px)}px"


def build_meirvo_overlays(listing: dict, total_duration: float, end_card_duration: float = 5.0) -> list[dict]:
    """
    Listing-reel overlay deck on track 4+:
      - wordmark           (top-right, always on · reads dynamically from listing.brokerage)
      - intro card (first ~6s):
          address          (bottom-left 1.2s-5.7s)
          spec             (bottom-left 1.6s-5.7s)
      - end card (last `end_card_duration` seconds · intended to land on a solid
        black card appended after the final Veo clip, so text is always legible):
          price            (huge Rust, centered)
          agent_name       (Instrument Serif, Ivory)
          cta_line         ("Contact us for more info", Inter caps)
          cta_address      (full address, Inter)

    The skill expects the operator to inject a solid-black 5s clip as the final
    item in the clips dir + shot_plan. That keeps composition continuous (no
    hard-coded black layer in HTML) and lets the crossfade engine fade into
    black naturally before the text animates in.
    """
    addr_short = short_address(listing)
    addr_full = str(listing.get("address", "")).strip() or addr_short
    spec = format_specs(listing)
    price = format_price(listing)
    agent_name = str(listing.get("agent_name") or listing.get("agentName") or "").strip()
    wordmark_text = resolve_wordmark(listing)

    end_card_start = max(total_duration - end_card_duration, 0.0)
    end_card_dur = round(total_duration - end_card_start, 2)

    # SAFE ZONES (1080x1920, verified Jun 2026 against IG Reels + TikTok UI):
    #   top >= 210px      (IG username/audio attribution; TikTok follow UI)
    #   bottom >= 380px   (caption bar + action row; 370px in ad placements)
    #   right >= 144px    (like/comment/share rail, 120px TikTok + margin)
    #   left >= 90px      (universal cross-platform margin)
    # Every coordinate below respects these. qc_bundle.py enforces them.
    overlays = [
        # Brand wordmark, always on
        {
            "id": "wordmark",
            "text": wordmark_text,
            "start": 0,
            "duration": total_duration,
            "top": "232px",
            "right": "144px",
            "font_family": REEL_BRAND["heading_font"],
            "font_size": "40px",
            "letter_spacing": "0.04em",
            "color": REEL_BRAND["ink"],
            "entrance_ease": "power2.out",
        },
        # Intro card. Text hook on screen inside the first 1.5s (skip decisions
        # happen before 1.5s; a first-frame text hook lifts view-through).
        {
            "id": "address",
            "text": addr_short,
            "start": 0.5,
            "duration": 5.2,
            "bottom": "460px",
            "left": "96px",
            "font_family": REEL_BRAND["heading_font"],
            "font_size": _autoscale_font(112, addr_short, 17, 64),
            "letter_spacing": "-0.02em",
            "color": REEL_BRAND["ink"],
            "entrance_ease": "power3.out",
        },
        {
            "id": "spec",
            "text": spec,
            "start": 0.9,
            "duration": 4.8,
            "bottom": "400px",
            "left": "100px",
            "font_family": REEL_BRAND["body_font"],
            "font_size": "28px",
            "letter_spacing": "0.1em",
            "text_transform": "uppercase",
            "font_weight": "500",
            "color": REEL_BRAND["ink"],
            "entrance_ease": "power2.out",
        },
        # End card (on the trailing black clip): price + agent + CTA + address, centered stack
        {
            "id": "price",
            "text": price,
            "start": round(end_card_start + 0.1, 2),
            "duration": round(end_card_dur - 0.1, 2),
            "top": "760px",
            "left": "100px",
            "right": "144px",
            "text_align": "center",
            "font_family": REEL_BRAND["heading_font"],
            "font_size": _autoscale_font(150, price, 10, 96),
            "letter_spacing": "-0.02em",
            "color": REEL_BRAND["accent"],
            "entrance_ease": "expo.out",
        },
        {
            "id": "agent_name",
            "text": agent_name or "Listing Agent",
            "start": round(end_card_start + 0.5, 2),
            "duration": round(end_card_dur - 0.5, 2),
            "top": "988px",
            "left": "100px",
            "right": "144px",
            "text_align": "center",
            "font_family": REEL_BRAND["heading_font"],
            "font_size": _autoscale_font(68, agent_name or "Listing Agent", 22, 44),
            "letter_spacing": "-0.01em",
            "color": REEL_BRAND["ink"],
            "entrance_ease": "power3.out",
        },
        {
            "id": "cta_line",
            "text": "CONTACT US FOR MORE INFO",
            "start": round(end_card_start + 0.9, 2),
            "duration": round(end_card_dur - 0.9, 2),
            "top": "1106px",
            "left": "100px",
            "right": "144px",
            "text_align": "center",
            "font_family": REEL_BRAND["body_font"],
            "font_size": "30px",
            "letter_spacing": "0.22em",
            "font_weight": "500",
            "color": REEL_BRAND["ink"],
            "entrance_ease": "power2.out",
        },
        {
            "id": "cta_address",
            "text": addr_full,
            "start": round(end_card_start + 1.2, 2),
            "duration": round(end_card_dur - 1.2, 2),
            "top": "1186px",
            "left": "100px",
            "right": "144px",
            "text_align": "center",
            "font_family": REEL_BRAND["body_font"],
            "font_size": _autoscale_font(38, addr_full, 38, 28),
            "letter_spacing": "0.02em",
            "color": REEL_BRAND["ink"],
            "entrance_ease": "power2.out",
            "final": True,  # last overlay, fades cleanly before composition ends
        },
    ]
    return overlays


def totals_from_shot_plan(shot_plan_path: Path) -> tuple[float, float]:
    """Returns (total_duration, end_card_duration).

    End card duration = the LAST shot's duration (the plan always ends on the
    black end card). v3 hardcoded 5.0s here, which desynced end-card overlay
    timing the moment the plan moved to a 3.0s card.
    """
    with shot_plan_path.open() as f:
        data = json.load(f)
    shots = data.get("shots") if isinstance(data, dict) else data
    if not isinstance(shots, list) or not shots:
        raise SystemExit(f"invalid shot_plan.json at {shot_plan_path}")
    durations = [float(s.get("duration", s.get("duration_seconds", 0))) for s in shots]
    return float(sum(durations)), float(durations[-1])


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> int:
    p = argparse.ArgumentParser(description="Build a Meirvo-branded hyperframes render bundle.")
    p.add_argument("--session-dir", required=True, help="Meirvo session dir (contains clips/ + shot_plan.json)")
    p.add_argument("--listing", required=True, help="listing.json with address/price/beds/baths/sqft")
    p.add_argument("--clips-dir", help="Override clips dir (defaults to {session}/clips)")
    p.add_argument("--shot-plan", help="Override shot plan path (defaults to {session}/shot_plan.json)")
    p.add_argument("--tts", help="TTS audio file (defaults to {session}/tts.wav if present)")
    p.add_argument("--music", help="Music bed audio (defaults to {session}/music.wav if present)")
    p.add_argument("--output", required=True, help="Output bundle directory")
    p.add_argument("--total-duration", type=float, default=None,
                   help="ASSERTION ONLY: error if the shot-plan sum differs by more than 0.05s. "
                        "The timeline length always comes from the shot plan (single source of truth). "
                        "Meirvo contract: 40.00 (35.00s of Veo content + 5.00s black end card).")
    p.add_argument("--width", type=int, default=1080)
    p.add_argument("--height", type=int, default=1920)
    p.add_argument("--xfade", type=float, default=0.5,
                   help="Default dissolve between clips (per-shot override via xfade_out in shot plan)")
    p.add_argument("--tts-start", type=float, default=1.6,
                   help="Narration begins this many seconds in (no wav padding needed)")
    p.add_argument("--tts-volume", type=float, default=1.0)
    p.add_argument("--music-volume", type=float, default=1.0,
                   help="1.0 when audio was pre-leveled by prep_audio.py (VO -16 LUFS, music -20 LUFS "
                        "ducked under VO). Use 0.22 only for legacy un-normalized music files.")
    p.add_argument("--zip", action="store_true")
    p.add_argument("--clean", action="store_true")
    args = p.parse_args()

    session_dir = Path(args.session_dir).resolve()
    listing_path = Path(args.listing).resolve()

    if not session_dir.is_dir():
        log(f"ERROR: session dir not found: {session_dir}")
        return 1
    if not listing_path.is_file():
        log(f"ERROR: listing.json not found: {listing_path}")
        return 1

    clips_dir = Path(args.clips_dir) if args.clips_dir else session_dir / "clips"
    shot_plan = Path(args.shot_plan) if args.shot_plan else session_dir / "shot_plan.json"
    tts = Path(args.tts) if args.tts else (session_dir / "tts.wav" if (session_dir / "tts.wav").exists() else None)
    music = Path(args.music) if args.music else (session_dir / "music.wav" if (session_dir / "music.wav").exists() else None)

    for required, path in (("clips dir", clips_dir), ("shot_plan.json", shot_plan)):
        if not path.exists():
            log(f"ERROR: {required} not found: {path}")
            return 1

    with listing_path.open() as f:
        listing = json.load(f)
    log(f"loaded listing: {listing.get('address','<no address>')}")

    # Single source of truth: the shot plan. v2 let --total-duration (default 40)
    # silently override the plan, which desynced end-card timing from the actual
    # timeline whenever the two disagreed. Now the flag only asserts.
    total_duration, end_card_s = totals_from_shot_plan(shot_plan)
    if args.total_duration is not None and abs(total_duration - args.total_duration) > 0.05:
        log(
            f"ERROR: shot plan sums to {total_duration:.2f}s but --total-duration asserts "
            f"{args.total_duration:.2f}s. Fix the shot plan (or the assertion); refusing to "
            "build a bundle whose end card would land on the wrong clip."
        )
        return 1
    log(f"total duration (from shot plan): {total_duration:.2f}s (end card {end_card_s:.2f}s)")

    # Build overlays json in a temp file next to the output
    output_dir = Path(args.output).resolve()
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    workdir = output_dir.parent / f".{output_dir.name}-work"
    workdir.mkdir(exist_ok=True)
    overlays_path = workdir / "overlays.json"
    brand_path = workdir / "brand.json"
    with overlays_path.open("w") as f:
        json.dump(build_meirvo_overlays(listing, total_duration, end_card_duration=end_card_s),
                  f, indent=2)
    # Write a per-run brand payload (with the resolved wordmark baked in so
    # downstream tools can see the final text too).
    run_brand = dict(REEL_BRAND)
    run_brand["name"] = resolve_wordmark(listing)
    with brand_path.open("w") as f:
        json.dump(run_brand, f, indent=2)
    log(f"overlays + brand written to {workdir} (wordmark='{run_brand['name']}')")

    # Build the title string
    title = listing.get("address") or listing.get("short_address") or "Listing Reel"
    session_id = listing.get("session_id") or session_dir.name
    package_name = f"listing-{session_id}".lower().replace(" ", "-").replace("_", "-")

    # Invoke build_bundle.py as a subprocess for clean argparse reuse
    build_bundle_py = Path(__file__).parent / "build_bundle.py"
    cmd = [
        sys.executable,
        str(build_bundle_py),
        "--clips-dir", str(clips_dir),
        "--shot-plan", str(shot_plan),
        "--overlays", str(overlays_path),
        "--brand", str(brand_path),
        "--metadata", str(listing_path),
        "--output", str(output_dir),
        "--title", str(title),
        "--package-name", package_name,
        "--total-duration", str(total_duration),
        "--width", str(args.width),
        "--height", str(args.height),
        "--xfade", str(args.xfade),
        "--tts-start", str(args.tts_start),
        "--tts-volume", str(args.tts_volume),
        "--music-volume", str(args.music_volume),
    ]
    if tts:
        cmd += ["--tts", str(tts)]
    if music:
        cmd += ["--music", str(music)]
    if args.zip:
        cmd += ["--zip"]
    if args.clean:
        cmd += ["--clean"]

    log(f"invoking: {' '.join(cmd)}")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        log(f"ERROR: build_bundle.py failed with code {result.returncode}")
        return result.returncode

    log(f"meirvo bundle ready: {output_dir}")
    if args.zip:
        log(f"zip: {output_dir.with_suffix('.zip')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
