#!/usr/bin/env python3
"""
hyperframes-bundle · qc_bundle.py

Deterministic quality gate for a built bundle. Run AFTER build_meirvo_bundle.py
and BEFORE zipping/shipping. The agent must not present a bundle to the
operator unless this exits 0.

Checks (Meirvo fast-cut contract, Jun 2026 v5):
  T1  composition total == --expect-total (default 40.00) within 0.05s
  T2  shot count matches clip elements; every <video> is muted
  T3  every clip's media file is long enough for its slot + dissolve (no
      freeze/black mid-crossfade)
  T4  every clip is the expected resolution (default 1080x1920), ~24 fps,
      yuv420p
  T5  final clip is a true black end card (mean luma < 16), length >=
      --end-card-min (default 2.8; v5 ships a 3.0s card)
  P1  pacing (preset fast only): >= --min-cuts content clips (default 12)
      and average content cut <= --max-avg-cut (default 3.0s). A reel that
      passes everything else but plays like a screensaver fails HERE.
  A1  narration (tts) ends at least 1.0s before the end card starts
  A2  narration integrated loudness ~ -16 LUFS (+/- 2.5)
  A3  music covers the full timeline (>= total - 0.25s)
  A4  music loudness ~ target +/- 2.5. Preset fast: target -20, measured on
      the OPEN section after the narration window (the bed is ducked under
      VO, so whole-file integrated would read low). Preset classic: -28,
      whole file.
  A5  music fades out (last 1.0s at least 10 dB quieter than mid-track)
  A6  duck depth (preset fast, music + narration present): music under the
      VO window at least 3.5 dB quieter than the open section
  O1  overlays inside platform safe zones (top >= 210, bottom >= 380,
      left >= 90, right >= 130 on a 1080x1920 canvas, scaled otherwise)
  O2  overlay timings inside the composition

Output: human-readable table on stdout + qc_report.json in the bundle dir.
Exit 0 = ship it. Exit 1 = fix and re-run. Never ship on a FAIL.

Usage:
  python3 qc_bundle.py --bundle ./render_bundle [--expect-total 40.0]
      [--preset fast|classic] [--width 1080] [--height 1920] [--no-lufs]
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SAFE_TOP = 210     # IG attribution / TikTok follow UI
SAFE_BOTTOM = 380  # caption bar + action row (370 in ad placements + margin)
SAFE_LEFT = 90     # universal cross-platform margin
SAFE_RIGHT = 130   # like/comment/share rail
BASE_W, BASE_H = 1080, 1920


# ---------------------------------------------------------------------------
# ffmpeg / ffprobe access (sandbox-safe: bootstraps imageio-ffmpeg if needed)
# ---------------------------------------------------------------------------

_FFMPEG: str | None = None


def get_ffmpeg() -> str | None:
    global _FFMPEG
    if _FFMPEG:
        return _FFMPEG
    found = shutil.which("ffmpeg")
    if found:
        _FFMPEG = found
        return _FFMPEG
    try:
        import imageio_ffmpeg  # type: ignore
    except ImportError:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet", "imageio-ffmpeg"],
            check=False,
        )
        try:
            import imageio_ffmpeg  # type: ignore
        except ImportError:
            return None
    try:
        _FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None
    return _FFMPEG


def run_ffmpeg(args: list[str]) -> str:
    """Run ffmpeg, return combined stderr (where ffmpeg prints its info)."""
    ff = get_ffmpeg()
    if not ff:
        raise RuntimeError("ffmpeg unavailable")
    proc = subprocess.run([ff, *args], capture_output=True, text=True)
    return (proc.stderr or "") + (proc.stdout or "")


def probe_media(path: Path) -> dict:
    """Parse duration / resolution / fps / pix_fmt from `ffmpeg -i` stderr."""
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        try:
            out = subprocess.check_output(
                [ffprobe, "-v", "error", "-select_streams", "v:0",
                 "-show_entries", "stream=width,height,pix_fmt,avg_frame_rate",
                 "-show_entries", "format=duration",
                 "-of", "json", str(path)],
                text=True, stderr=subprocess.DEVNULL,
            )
            data = json.loads(out)
            stream = (data.get("streams") or [{}])[0]
            fps = None
            afr = stream.get("avg_frame_rate", "")
            if afr and "/" in afr:
                num, den = afr.split("/")
                if float(den) > 0:
                    fps = float(num) / float(den)
            return {
                "duration": float(data.get("format", {}).get("duration", 0) or 0),
                "width": stream.get("width"),
                "height": stream.get("height"),
                "fps": fps,
                "pix_fmt": stream.get("pix_fmt"),
            }
        except Exception:
            pass
    # ffmpeg stderr fallback
    info = run_ffmpeg(["-i", str(path)])
    out: dict = {"duration": 0.0, "width": None, "height": None, "fps": None, "pix_fmt": None}
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.?\d*)", info)
    if m:
        h, mn, s = float(m.group(1)), float(m.group(2)), float(m.group(3))
        out["duration"] = h * 3600 + mn * 60 + s
    m = re.search(r"Video:.*?(\d{3,5})x(\d{3,5})", info)
    if m:
        out["width"], out["height"] = int(m.group(1)), int(m.group(2))
    m = re.search(r"(\d+(?:\.\d+)?)\s*fps", info)
    if m:
        out["fps"] = float(m.group(1))
    m = re.search(r"Video:\s*\w+[^,]*,\s*(\w+)", info)
    if m:
        out["pix_fmt"] = m.group(1)
    return out


def audio_duration(path: Path) -> float:
    return probe_media(path)["duration"]


def lufs_integrated(path: Path, ss: float | None = None, t: float | None = None) -> float | None:
    """Integrated loudness via ebur128, optionally on a [ss, ss+t] window."""
    cmd = ["-nostats"]
    if ss is not None:
        cmd += ["-ss", f"{max(ss, 0):.3f}"]
    if t is not None:
        cmd += ["-t", f"{max(t, 0.5):.3f}"]
    cmd += ["-i", str(path), "-af", "ebur128", "-f", "null", "-"]
    try:
        info = run_ffmpeg(cmd)
    except RuntimeError:
        return None
    matches = re.findall(r"I:\s*(-?\d+(?:\.\d+)?)\s*LUFS", info)
    return float(matches[-1]) if matches else None


def mean_volume(path: Path, start: float, length: float = 1.0) -> float | None:
    try:
        info = run_ffmpeg([
            "-nostats", "-ss", f"{max(start, 0):.3f}", "-t", f"{length:.3f}",
            "-i", str(path), "-af", "volumedetect", "-f", "null", "-",
        ])
    except RuntimeError:
        return None
    m = re.search(r"mean_volume:\s*(-?\d+(?:\.\d+)?)\s*dB", info)
    return float(m.group(1)) if m else None


def frame_mean_luma(path: Path, at: float) -> float | None:
    """Extract one frame and return its mean brightness 0-255."""
    try:
        from PIL import Image  # type: ignore
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "pillow"], check=False)
        try:
            from PIL import Image  # type: ignore
        except ImportError:
            return None
    with tempfile.TemporaryDirectory() as td:
        png = Path(td) / "frame.png"
        try:
            run_ffmpeg(["-ss", f"{at:.3f}", "-i", str(path), "-frames:v", "1", "-y", str(png)])
        except RuntimeError:
            return None
        if not png.exists():
            return None
        img = Image.open(png).convert("L")
        hist = img.histogram()
        total = sum(hist)
        if total == 0:
            return None
        return sum(i * c for i, c in enumerate(hist)) / total


# ---------------------------------------------------------------------------
# index.html parsing (machine-generated, stable shape)
# ---------------------------------------------------------------------------

def parse_composition(html: str) -> dict:
    root = re.search(
        r'data-composition-id="main"[^>]*data-duration="([\d.]+)"[^>]*'
        r'data-width="(\d+)"[^>]*data-height="(\d+)"',
        html,
    )
    comp = {
        "total": float(root.group(1)) if root else None,
        "width": int(root.group(2)) if root else None,
        "height": int(root.group(3)) if root else None,
        "clips": [],
        "tts": None,
        "music": None,
        "overlays": [],
    }
    for m in re.finditer(
        r'<video id="(clip-\d+)"[^>]*data-start="([\d.]+)" data-duration="([\d.]+)"'
        r'[^>]*src="assets/([^"]+)"([^>]*)>',
        html,
    ):
        comp["clips"].append({
            "id": m.group(1),
            "start": float(m.group(2)),
            "duration": float(m.group(3)),
            "filename": m.group(4),
            "muted": "muted" in m.group(5) or "muted" in m.group(0),
        })
    for m in re.finditer(
        r'<audio id="(tts|music)" data-start="([\d.]+)" data-duration="([\d.]+)"'
        r'[^>]*src="assets/([^"]+)"',
        html,
    ):
        comp[m.group(1)] = {
            "start": float(m.group(2)),
            "duration": float(m.group(3)),
            "filename": m.group(4),
        }
    for m in re.finditer(
        r'<div id="([^"]+)" class="clip overlay-text" data-start="([\d.]+)" '
        r'data-duration="([\d.]+)"[^>]*style="([^"]*)">(.*?)</div>',
        html,
    ):
        style = m.group(4)
        ov = {"id": m.group(1), "start": float(m.group(2)), "duration": float(m.group(3)),
              "text": re.sub(r"<[^>]+>", "", m.group(5)).strip()}
        for key in ("top", "bottom", "left", "right"):
            sm = re.search(rf"{key}:\s*(-?\d+(?:\.\d+)?)px", style)
            if sm:
                ov[key] = float(sm.group(1))
        comp["overlays"].append(ov)
    return comp


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------

class Report:
    def __init__(self) -> None:
        self.rows: list[dict] = []

    def add(self, code: str, status: str, detail: str) -> None:
        self.rows.append({"check": code, "status": status, "detail": detail})
        icon = {"PASS": "+", "FAIL": "x", "WARN": "!", "SKIP": "-"}.get(status, "?")
        print(f"  [{icon}] {code:4s} {status:4s} {detail}")

    @property
    def failed(self) -> bool:
        return any(r["status"] == "FAIL" for r in self.rows)


def main() -> int:
    p = argparse.ArgumentParser(description="QC gate for a hyperframes bundle")
    p.add_argument("--bundle", required=True)
    p.add_argument("--expect-total", type=float, default=40.0)
    p.add_argument("--preset", choices=["fast", "classic"], default="fast",
                   help="fast (v5 default): pacing + duck checks on, music target -20. "
                        "classic: v4 behavior, music target -28, no pacing gate.")
    p.add_argument("--width", type=int, default=1080)
    p.add_argument("--height", type=int, default=1920)
    p.add_argument("--end-card-min", type=float, default=2.8)
    p.add_argument("--music-lufs", type=float, default=None,
                   help="Music loudness target (default: -20 fast, -28 classic)")
    p.add_argument("--min-cuts", type=int, default=12, help="P1: minimum content cuts (fast preset)")
    p.add_argument("--max-avg-cut", type=float, default=3.0, help="P1: max average content cut seconds")
    p.add_argument("--no-lufs", action="store_true", help="Skip loudness checks")
    args = p.parse_args()
    music_target = args.music_lufs if args.music_lufs is not None else (-20.0 if args.preset == "fast" else -28.0)

    bundle = Path(args.bundle).resolve()
    index = bundle / "index.html"
    assets = bundle / "assets"
    if not index.is_file():
        print(f"FATAL: {index} not found")
        return 1

    comp = parse_composition(index.read_text())
    rep = Report()
    print(f"qc_bundle: {bundle.name} (expect {args.expect_total:.2f}s at {args.width}x{args.height})")

    # T1 total duration
    if comp["total"] is None:
        rep.add("T1", "FAIL", "could not parse composition data-duration")
    elif abs(comp["total"] - args.expect_total) <= 0.05:
        rep.add("T1", "PASS", f"composition total {comp['total']:.2f}s == {args.expect_total:.2f}s")
    else:
        rep.add("T1", "FAIL", f"composition total {comp['total']:.2f}s != {args.expect_total:.2f}s")
    if comp["width"] != args.width or comp["height"] != args.height:
        rep.add("T1b", "FAIL", f"canvas {comp['width']}x{comp['height']} != {args.width}x{args.height}")
    else:
        rep.add("T1b", "PASS", f"canvas {args.width}x{args.height}")

    # T2 clips present + muted
    clips = comp["clips"]
    if not clips:
        rep.add("T2", "FAIL", "no <video> clip elements found")
        print(json.dumps({"failed": True}), file=sys.stderr)
        return 1
    unmuted = [c["id"] for c in clips if not c["muted"]]
    if unmuted:
        rep.add("T2", "FAIL", f"unmuted clips (Veo baked audio would bleed through): {unmuted}")
    else:
        rep.add("T2", "PASS", f"{len(clips)} clips, all muted")

    # T3 media length, T4 format
    ff_ok = get_ffmpeg() is not None
    if not ff_ok:
        rep.add("T3", "SKIP", "ffmpeg unavailable in this environment")
        rep.add("T4", "SKIP", "ffmpeg unavailable in this environment")
    else:
        t3_bad, t4_bad = [], []
        for c in clips:
            media = probe_media(assets / c["filename"])
            if media["duration"] + 0.02 < c["duration"]:
                t3_bad.append(f"{c['filename']} media {media['duration']:.2f}s < element {c['duration']:.2f}s")
            if media["width"] != args.width or media["height"] != args.height:
                t4_bad.append(f"{c['filename']} {media['width']}x{media['height']}")
            elif media["fps"] is not None and not (23.7 <= media["fps"] <= 24.3):
                t4_bad.append(f"{c['filename']} {media['fps']:.2f}fps (want 24)")
            elif media["pix_fmt"] not in (None, "yuv420p"):
                t4_bad.append(f"{c['filename']} pix_fmt {media['pix_fmt']}")
        rep.add("T3", "FAIL" if t3_bad else "PASS",
                "; ".join(t3_bad) if t3_bad else "every clip covers slot + dissolve")
        rep.add("T4", "FAIL" if t4_bad else "PASS",
                "; ".join(t4_bad) if t4_bad else f"all clips {args.width}x{args.height} 24fps yuv420p")

    # T5 black end card
    last = clips[-1]
    if not ff_ok:
        rep.add("T5", "SKIP", "ffmpeg unavailable")
    else:
        last_media = probe_media(assets / last["filename"])
        if last_media["duration"] < args.end_card_min:
            rep.add("T5", "FAIL", f"final clip only {last_media['duration']:.2f}s (need >= {args.end_card_min}s end card)")
        else:
            luma = frame_mean_luma(assets / last["filename"], min(2.0, last_media["duration"] / 2))
            if luma is None:
                rep.add("T5", "WARN", "could not sample final clip frame")
            elif luma < 16:
                rep.add("T5", "PASS", f"final clip is a black end card (mean luma {luma:.1f})")
            else:
                rep.add("T5", "FAIL", f"final clip mean luma {luma:.1f}; end-card text needs a black card (append make_endcard.py output)")

    # P1 pacing (fast preset): catches the technically-clean screensaver.
    # Content cut lengths = deltas between consecutive clip starts; the list
    # covers every clip before the final end card.
    if args.preset == "fast":
        starts = [c["start"] for c in clips]
        bases = [round(starts[i + 1] - starts[i], 3) for i in range(len(clips) - 1)]
        n_cuts = len(bases)
        avg = (sum(bases) / n_cuts) if n_cuts else 0.0
        longest = max(bases) if bases else 0.0
        p1_bad = []
        if n_cuts < args.min_cuts:
            p1_bad.append(f"only {n_cuts} content cuts (need >= {args.min_cuts})")
        if avg > args.max_avg_cut + 0.01:
            p1_bad.append(f"avg cut {avg:.2f}s > {args.max_avg_cut:.1f}s (too slow)")
        if longest > 6.5:
            p1_bad.append(f"longest cut {longest:.2f}s > 6.5s")
        rep.add("P1", "FAIL" if p1_bad else "PASS",
                "; ".join(p1_bad) if p1_bad else
                f"{n_cuts} cuts, avg {avg:.2f}s, longest {longest:.2f}s (fast-cut pace)")
    else:
        rep.add("P1", "SKIP", "classic preset: pacing gate off")

    # A1/A2 narration
    total = comp["total"] or args.expect_total
    end_card_start = total - last["duration"]
    tts_end = None
    if comp["tts"]:
        tts_file = assets / comp["tts"]["filename"]
        if ff_ok:
            dur = audio_duration(tts_file)
            tts_end = comp["tts"]["start"] + dur
            if tts_end <= end_card_start - 1.0:
                rep.add("A1", "PASS", f"narration ends {tts_end:.2f}s ({end_card_start - tts_end:.1f}s before end card)")
            else:
                rep.add("A1", "FAIL", f"narration ends {tts_end:.2f}s; must end >= 1.0s before end card at {end_card_start:.2f}s")
            if args.no_lufs:
                rep.add("A2", "SKIP", "loudness checks disabled")
            else:
                lufs = lufs_integrated(tts_file)
                if lufs is None:
                    rep.add("A2", "WARN", "could not measure narration LUFS")
                elif -18.5 <= lufs <= -13.5:
                    rep.add("A2", "PASS", f"narration {lufs:.1f} LUFS")
                else:
                    rep.add("A2", "FAIL", f"narration {lufs:.1f} LUFS (target -16 +/- 2.5; run prep_audio.py)")
        else:
            rep.add("A1", "SKIP", "ffmpeg unavailable")
    else:
        rep.add("A1", "WARN", "no narration track (music-only reel: confirm intentional)")

    # A3/A4/A5/A6 music
    if comp["music"]:
        music_file = assets / comp["music"]["filename"]
        if ff_ok:
            mdur = audio_duration(music_file)
            if mdur >= total - 0.25:
                rep.add("A3", "PASS", f"music covers timeline ({mdur:.2f}s >= {total:.2f}s)")
            else:
                rep.add("A3", "FAIL", f"music {mdur:.2f}s shorter than timeline {total:.2f}s (hard audio stop)")
            if args.no_lufs:
                rep.add("A4", "SKIP", "loudness checks disabled")
            else:
                # Fast preset with narration: the bed is DUCKED under the VO
                # window, so measure the open section after the VO instead of
                # the whole file (whole-file integrated reads artificially low).
                if args.preset == "fast" and tts_end is not None:
                    open_start = min(tts_end + 1.2, max(total - 8.0, 0.0))
                    open_len = max(total - 2.6 - open_start, 2.0)
                    lufs = lufs_integrated(music_file, ss=open_start, t=open_len)
                    where = f"open section {open_start:.1f}s onward"
                else:
                    lufs = lufs_integrated(music_file)
                    where = "whole file"
                if lufs is None:
                    rep.add("A4", "WARN", "could not measure music LUFS")
                elif (music_target - 2.5) <= lufs <= (music_target + 2.5):
                    rep.add("A4", "PASS", f"music {lufs:.1f} LUFS ({where}; target {music_target:.0f})")
                else:
                    rep.add("A4", "FAIL", f"music {lufs:.1f} LUFS ({where}; target {music_target:.0f} "
                                          f"+/- 2.5; run prep_audio.py)")
            mid = mean_volume(music_file, max(total * 0.7 - 0.5, 0))
            tail = mean_volume(music_file, max(mdur - 1.1, 0))
            if mid is None or tail is None:
                rep.add("A5", "WARN", "could not measure music fade-out")
            elif tail <= mid - 10:
                rep.add("A5", "PASS", f"music fades out (tail {tail:.1f} dB vs late-track {mid:.1f} dB)")
            else:
                rep.add("A5", "FAIL", f"no music fade-out (tail {tail:.1f} dB vs late-track {mid:.1f} dB; ends abruptly)")
            # A6 duck depth: music under the VO window must sit clearly below
            # the open section. Catches a v4-style flat bed shipped into a v5 mix.
            if args.preset != "fast":
                rep.add("A6", "SKIP", "classic preset: duck check off")
            elif args.no_lufs:
                rep.add("A6", "SKIP", "loudness checks disabled")
            elif tts_end is None:
                rep.add("A6", "SKIP", "no narration track to duck under")
            else:
                vo_start = comp["tts"]["start"]
                duck_len = max(min(tts_end - vo_start - 1.0, 3.0), 1.0)
                ducked = mean_volume(music_file, vo_start + 0.5, duck_len)
                open_mv = mean_volume(music_file, min(tts_end + 1.5, max(total - 4.0, 0.0)), 3.0)
                if ducked is None or open_mv is None:
                    rep.add("A6", "WARN", "could not measure duck depth")
                elif open_mv - ducked >= 3.5:
                    rep.add("A6", "PASS", f"music ducks {open_mv - ducked:.1f} dB under narration")
                else:
                    rep.add("A6", "FAIL", f"music duck only {open_mv - ducked:.1f} dB (need >= 3.5; "
                                          "run prep_audio.py v5 with --vo)")
        else:
            rep.add("A3", "SKIP", "ffmpeg unavailable")
    else:
        rep.add("A3", "WARN", "no music track (confirm intentional)")

    # O1 safe zones (scaled to canvas)
    sx = (comp["width"] or BASE_W) / BASE_W
    sy = (comp["height"] or BASE_H) / BASE_H
    o1_bad = []
    for ov in comp["overlays"]:
        if "top" in ov and ov["top"] < SAFE_TOP * sy:
            o1_bad.append(f"{ov['id']} top {ov['top']:.0f}px < {SAFE_TOP * sy:.0f}px")
        if "bottom" in ov and ov["bottom"] < SAFE_BOTTOM * sy:
            o1_bad.append(f"{ov['id']} bottom {ov['bottom']:.0f}px < {SAFE_BOTTOM * sy:.0f}px")
        if "left" in ov and ov["left"] < SAFE_LEFT * sx:
            o1_bad.append(f"{ov['id']} left {ov['left']:.0f}px < {SAFE_LEFT * sx:.0f}px")
        if "right" in ov and ov["right"] < SAFE_RIGHT * sx:
            o1_bad.append(f"{ov['id']} right {ov['right']:.0f}px < {SAFE_RIGHT * sx:.0f}px")
    rep.add("O1", "FAIL" if o1_bad else "PASS",
            "; ".join(o1_bad) if o1_bad else f"{len(comp['overlays'])} overlays inside IG/TikTok safe zones")

    # O2 overlay timing
    o2_bad = [
        f"{ov['id']} ends {ov['start'] + ov['duration']:.2f}s > {total:.2f}s"
        for ov in comp["overlays"]
        if ov["start"] + ov["duration"] > total + 0.01
    ]
    rep.add("O2", "FAIL" if o2_bad else "PASS",
            "; ".join(o2_bad) if o2_bad else "overlay timings inside composition")

    # Write report
    report_path = bundle / "qc_report.json"
    report_path.write_text(json.dumps({
        "bundle": str(bundle),
        "expect_total": args.expect_total,
        "preset": args.preset,
        "music_lufs_target": music_target,
        "canvas": [args.width, args.height],
        "rows": rep.rows,
        "failed": rep.failed,
    }, indent=2))

    n_fail = sum(1 for r in rep.rows if r["status"] == "FAIL")
    n_warn = sum(1 for r in rep.rows if r["status"] == "WARN")
    print(f"\nqc_bundle: {'FAIL' if rep.failed else 'PASS'} "
          f"({n_fail} fail, {n_warn} warn) -> {report_path}")
    return 1 if rep.failed else 0


if __name__ == "__main__":
    sys.exit(main())
