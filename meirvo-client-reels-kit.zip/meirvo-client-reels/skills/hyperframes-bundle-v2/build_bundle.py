#!/usr/bin/env python3
"""
hyperframes-bundle · build_bundle.py

Generic bundle generator for the Hyperframes local-render workflow.

Takes:
  - A directory of video clips (clip_01.mp4, clip_02.mp4, ...)
  - A shot plan JSON with durations
  - Optional TTS audio file
  - Optional music bed audio file
  - Optional overlays JSON (text overlays with timing)
  - Optional brand config JSON (colors, fonts, wordmark)

Produces a ready-to-render bundle folder:
  {output}/
    assets/              (all media copied in)
    index.html           (hyperframes composition)
    listing.json         (metadata passthrough)
    package.json         (hyperframes dep)
    render.sh            (one-command render)
    README.md            (install + render steps)

Usage:
  python3 build_bundle.py \\
      --clips-dir ./clips \\
      --shot-plan ./shot_plan.json \\
      --tts ./tts.wav \\
      --music ./music.wav \\
      --overlays ./overlays.json \\
      --brand ./brand.json \\
      --metadata ./listing.json \\
      --output ./render_bundle \\
      --title "123 Maple St" \\
      --total-duration 40 \\
      --width 1920 --height 1080 \\
      --zip

Does NOT render. Sandbox-safe (no Chrome, no ffmpeg). User renders locally.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_BRAND: dict[str, Any] = {
    "name": "HYPERFRAMES",
    "bg": "#0E0C0A",
    "ink": "#F4F0E8",
    "accent": "#C65A2E",
    "muted": "#6B6560",
    "heading_font": "Instrument Serif",
    "body_font": "Inter",
    "font_import_url": "https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Inter:wght@400;500;600;700&display=block",
    "wordmark_position": "top-right",
}

DEFAULT_CROSSFADE = 0.5  # dissolve length when a shot requests one; fast-cut plans set xfade_out 0 per shot
RENDER_FPS = 24  # match Veo native output; rendering at 30 caused judder on camera moves
# Pinned to the v0.6.89 release line (Jun 10 2026). That release fixes muted-video
# audio leaking into renders and IEEE 754 frame-index boundary duplicates, both of
# which matter for this workflow. Caret range picks up patch releases on update.
HYPERFRAMES_PKG_VERSION = "^0.6.89"
GSAP_CDN = "https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def log(msg: str) -> None:
    print(f"[build_bundle] {msg}", file=sys.stderr)


def load_json(path: Path) -> Any:
    with path.open() as f:
        return json.load(f)


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)


def copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def probe_duration(media_path: Path) -> float | None:
    """Optional: try ffprobe to get real duration. Returns None if ffprobe unavailable."""
    try:
        out = subprocess.check_output(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                str(media_path),
            ],
            stderr=subprocess.DEVNULL,
        )
        return float(out.strip())
    except (subprocess.CalledProcessError, FileNotFoundError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Shot plan normalization
# ---------------------------------------------------------------------------


def normalize_shots(shot_plan: Any, clip_paths: list[Path]) -> list[dict]:
    """
    Accept either:
      - list of dicts with at least 'duration' (and optional 'filename', 'id')
      - dict with 'shots' key containing the above list
      - dict with 'clips' key (alt naming)

    Returns a normalized list: [{index, duration, filename}, ...]
    sorted by index, matched to clip_paths by position if filename missing.
    """
    if isinstance(shot_plan, dict):
        shots = shot_plan.get("shots") or shot_plan.get("clips") or []
    elif isinstance(shot_plan, list):
        shots = shot_plan
    else:
        raise ValueError("shot_plan must be a list or a dict with 'shots'/'clips' key")

    if len(shots) != len(clip_paths):
        raise ValueError(
            f"shot plan has {len(shots)} shots but clips dir has {len(clip_paths)} clips; "
            "they must match 1:1"
        )

    normalized: list[dict] = []
    for i, shot in enumerate(shots):
        if not isinstance(shot, dict):
            raise ValueError(f"shot {i} is not a dict: {shot!r}")
        duration = float(shot.get("duration", shot.get("duration_seconds", shot.get("duration_s", 0))))
        if duration <= 0:
            raise ValueError(f"shot {i} has invalid duration: {duration}")
        filename = shot.get("filename") or clip_paths[i].name
        normalized.append(
            {
                "index": i + 1,
                "duration": duration,
                # Per-shot crossfade INTO the next clip. None = use global default.
                "xfade_out": shot.get("xfade_out"),
                "filename": filename,
                "source_photo": shot.get("source_photo"),
                "veo_prompt": shot.get("veo_prompt"),
            }
        )
    return normalized


# ---------------------------------------------------------------------------
# HTML composition builder
# ---------------------------------------------------------------------------


def build_clip_tracks(shots: list[dict], default_xfade: float = DEFAULT_CROSSFADE) -> tuple[list[dict], list[dict]]:
    """
    Distribute clips across tracks 0 and 1 with crossfade overlap.
    Each shot may carry its own `xfade_out` (seconds of dissolve INTO the next
    clip); otherwise `default_xfade` applies. The OUTGOING clip's element is
    extended by the fade length, so its media file must be at least
    (slot duration + xfade_out) long or the frame freezes mid-dissolve.
    Returns (clip_elements, transitions); transitions carry per-pair duration.
    """
    clips: list[dict] = []
    transitions: list[dict] = []

    cursor = 0.0
    for i, shot in enumerate(shots):
        is_last = i == len(shots) - 1
        track = i % 2  # alternate tracks 0, 1, 0, 1...
        clip_id = f"clip-{i + 1}"
        start = cursor
        base_duration = shot["duration"]
        # NOTE: explicit 0 means HARD CUT; only None falls back to the default.
        # (v3 used `or default_xfade`, which silently turned xfade_out: 0 into
        # a 0.5s dissolve because 0 is falsy. Fast-cut plans rely on 0.)
        raw_xf = shot.get("xfade_out")
        xfade_out = float(default_xfade if raw_xf is None else raw_xf)
        # Extend duration by crossfade overlap except for last clip
        duration = base_duration if is_last else base_duration + xfade_out
        clips.append(
            {
                "id": clip_id,
                "start": round(start, 3),
                "duration": round(duration, 3),
                "track": track,
                "filename": shot["filename"],
                "media_required": round(duration, 3),  # min media length for clean dissolve
            }
        )
        if i > 0:
            # Transition at the boundary: new clip fades in over the PREVIOUS
            # shot's xfade_out while the old one fades away. 0 = hard cut.
            prev_raw = shots[i - 1].get("xfade_out")
            prev_xfade = float(default_xfade if prev_raw is None else prev_raw)
            prev_id = f"clip-{i}"
            transitions.append(
                {
                    "from_id": prev_id,
                    "to_id": clip_id,
                    "at": round(start, 3),
                    "duration": round(prev_xfade, 3),
                }
            )
        cursor += base_duration  # advance by base, overlap is extra

    return clips, transitions


def build_overlay_timeline(overlays: list[dict], total_duration: float) -> str:
    """
    Generate GSAP tweens for text overlays.
    Each overlay: {id, start, duration, entrance_ease?, final?, no_exit?}
    - entrance: slow 0.7s fade+rise (12-18 frame dissolve is the premium standard;
      instant pop-on reads as template content).
    - exit: EVERY overlay that ends before the composition does gets a 0.45s
      fade-out timed to finish exactly at its end. v2 only faded the `final`
      overlay, so mid-reel text vanished in a single frame (amateur tell).
      Overlays running to composition end (wordmark, end card) hold instead,
      unless final=true requests the explicit early exit.
    """
    lines: list[str] = []
    for o in overlays:
        oid = o["id"]
        start = float(o["start"])
        duration = float(o.get("duration", 3))
        ease = o.get("entrance_ease", "power3.out")
        lines.append(
            f"      tl.from('#{oid}', {{ opacity: 0, y: 40, duration: 0.7, ease: '{ease}' }}, {start});"
        )
        end = start + duration
        runs_to_end = end >= total_duration - 0.1
        if o.get("final"):
            exit_at = min(end - 0.6, total_duration - 0.6)
            exit_at = max(exit_at, start + 0.5)
            lines.append(
                f"      tl.to('#{oid}', {{ opacity: 0, y: -20, duration: 0.5, ease: 'power2.in' }}, {exit_at});"
            )
        elif not runs_to_end and not o.get("no_exit"):
            exit_at = max(end - 0.45, start + 0.5)
            lines.append(
                f"      tl.to('#{oid}', {{ opacity: 0, duration: 0.45, ease: 'power2.in' }}, {round(exit_at, 3)});"
            )
    return "\n".join(lines)


def build_crossfade_timeline(transitions: list[dict]) -> str:
    """
    Generate GSAP tweens for clip transitions. Dissolves tween opacity over
    the pair's duration; durations under 0.05s are HARD CUTS and use instant
    sets at the boundary (no half-rendered dissolve frame).
    """
    lines: list[str] = []
    for t in transitions:
        from_id = t["from_id"]
        to_id = t["to_id"]
        at = t["at"]
        dur = t.get("duration", DEFAULT_CROSSFADE)
        lines.append(f"      tl.set('#{to_id}', {{ opacity: 0 }}, 0);")
        if dur < 0.05:
            lines.append(f"      tl.set('#{to_id}', {{ opacity: 1 }}, {at});")
            lines.append(f"      tl.set('#{from_id}', {{ opacity: 0 }}, {at});")
        else:
            lines.append(
                f"      tl.to('#{to_id}', {{ opacity: 1, duration: {dur}, ease: 'power1.inOut' }}, {at});"
            )
            lines.append(
                f"      tl.to('#{from_id}', {{ opacity: 0, duration: {dur}, ease: 'power1.inOut' }}, {at});"
            )
    return "\n".join(lines)


def build_composition_html(
    *,
    title: str,
    width: int,
    height: int,
    total_duration: float,
    shots: list[dict],
    overlays: list[dict],
    tts_path: Path | None,
    music_path: Path | None,
    music_volume: float,
    tts_volume: float,
    brand: dict,
    default_xfade: float = DEFAULT_CROSSFADE,
    tts_start: float = 0.0,
) -> str:
    clips, transitions = build_clip_tracks(shots, default_xfade=default_xfade)

    # Build video elements
    video_elements: list[str] = []
    for c in clips:
        video_elements.append(
            f'      <video id="{c["id"]}" class="clip clip-video" '
            f'data-start="{c["start"]}" data-duration="{c["duration"]}" '
            f'data-track-index="{c["track"]}" '
            f'src="assets/{c["filename"]}" muted playsinline></video>'
        )

    # Audio elements (always track 2 for TTS, track 3 for music)
    audio_elements: list[str] = []
    if tts_path:
        tts_dur = round(max(total_duration - tts_start, 1.0), 3)
        audio_elements.append(
            f'      <audio id="tts" data-start="{round(tts_start, 3)}" data-duration="{tts_dur}" '
            f'data-track-index="2" data-volume="{tts_volume}" '
            f'src="assets/{tts_path.name}"></audio>'
        )
    if music_path:
        audio_elements.append(
            f'      <audio id="music" data-start="0" data-duration="{total_duration}" '
            f'data-track-index="3" data-volume="{music_volume}" '
            f'src="assets/{music_path.name}"></audio>'
        )

    # Overlay elements
    # Note: NO inline `opacity: 0`: hyperframes clip-gating handles visibility by
    # data-start/data-duration. GSAP tl.from(opacity:0) animates FROM 0 TO the CSS
    # value (1), so CSS must leave opacity at default.
    # Each overlay gets its own unique track index (starting at 4) to avoid
    # same-track-overlap lint errors. Track 4+ is reserved for overlays.
    overlay_elements: list[str] = []
    for idx, o in enumerate(overlays):
        track_idx = 4 + idx  # unique track per overlay
        style_parts = [
            "position: absolute",
            f"color: {o.get('color', brand['ink'])}",
        ]
        for key in ("top", "bottom", "left", "right"):
            if key in o:
                style_parts.append(f"{key}: {o[key]}")
        if "font_size" in o:
            style_parts.append(f"font-size: {o['font_size']}")
        if "font_family" in o:
            fallback = "sans-serif" if "inter" in o["font_family"].lower() else "serif"
            style_parts.append(f"font-family: '{o['font_family']}', {fallback}")
        if "letter_spacing" in o:
            style_parts.append(f"letter-spacing: {o['letter_spacing']}")
        if "text_transform" in o:
            style_parts.append(f"text-transform: {o['text_transform']}")
        if "font_weight" in o:
            style_parts.append(f"font-weight: {o['font_weight']}")
        if "text_align" in o:
            # v2 silently dropped this key, so "centered" end cards rendered
            # left-flushed at the canvas edge. Honor it.
            style_parts.append(f"text-align: {o['text_align']}")
        if "line_height" in o:
            style_parts.append(f"line-height: {o['line_height']}")
        style_str = "; ".join(style_parts)
        text = o.get("text", "").replace("<", "&lt;").replace(">", "&gt;")
        # class="clip overlay-text": clip class enables visibility gating
        overlay_elements.append(
            f'      <div id="{o["id"]}" class="clip overlay-text" '
            f'data-start="{o["start"]}" data-duration="{o["duration"]}" '
            f'data-track-index="{track_idx}" style="{style_str}">{text}</div>'
        )

    crossfade_js = build_crossfade_timeline(transitions)
    overlay_js = build_overlay_timeline(overlays, total_duration)

    html = f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width={width}, height={height}" />
    <title>{title}</title>
    <script src="{GSAP_CDN}"></script>
    <link href="{brand["font_import_url"]}" rel="stylesheet" />
    <style>
      * {{ margin: 0; padding: 0; box-sizing: border-box; }}
      html, body {{
        margin: 0;
        width: {width}px;
        height: {height}px;
        overflow: hidden;
        background: {brand["bg"]};
        font-family: "{brand["body_font"]}", sans-serif;
      }}
      .clip-video {{
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
      }}
      .overlay-text {{
        pointer-events: none;
        text-shadow: 0 2px 18px rgba(0, 0, 0, 0.45);
      }}
      .vignette {{
        position: absolute;
        inset: 0;
        pointer-events: none;
        background: radial-gradient(
          ellipse at center,
          rgba(0, 0, 0, 0) 55%,
          rgba(0, 0, 0, 0.35) 100%
        );
        z-index: 5;
      }}
    </style>
  </head>
  <body>
    <div
      id="root"
      data-composition-id="main"
      data-start="0"
      data-duration="{total_duration}"
      data-width="{width}"
      data-height="{height}"
    >
{chr(10).join(video_elements)}

{chr(10).join(audio_elements) if audio_elements else "      <!-- no audio -->"}

{chr(10).join(overlay_elements) if overlay_elements else "      <!-- no overlays -->"}

      <div class="vignette"></div>
    </div>

    <script>
      window.__timelines = window.__timelines || {{}};
      (function () {{
        const tl = gsap.timeline({{ paused: true }});

        // Crossfades between clips
{crossfade_js if crossfade_js else "        // (single clip, no crossfades)"}

        // Overlay entrances
{overlay_js if overlay_js else "        // (no overlays)"}

        window.__timelines["main"] = tl;
      }})();
    </script>
  </body>
</html>
"""
    return html


# ---------------------------------------------------------------------------
# Package files
# ---------------------------------------------------------------------------


def build_package_json(name: str) -> str:
    return json.dumps(
        {
            "name": name,
            "private": True,
            "version": "1.0.0",
            "scripts": {
                "render": f"npx hyperframes render --output main_reel.mp4 --quality high --fps {RENDER_FPS}",
                "render:draft": f"npx hyperframes render --output main_reel.mp4 --quality draft --fps {RENDER_FPS}",
                "lint": "npx hyperframes lint",
                "preview": "npx hyperframes preview",
                "doctor": "npx hyperframes doctor",
            },
            "dependencies": {"hyperframes": HYPERFRAMES_PKG_VERSION},
        },
        indent=2,
    )


RENDER_SH_TEMPLATE = """#!/usr/bin/env bash
set -euo pipefail

# hyperframes-bundle · render.sh
#   1. Installs hyperframes (first run only, ~1-2 min)
#   2. Lints the composition
#   3. Renders to main_reel.mp4 at high quality (24 fps · matches Veo source,
#      rendering at 30 resamples 24fps clips and causes visible judder on pans)

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$here"

# Always run npm install: it is a fast no-op when the pinned hyperframes
# version is already satisfied, and it UPDATES hyperframes when the bundle
# pin moved (the old node_modules guard stranded operators on stale versions).
echo "[render] ensuring hyperframes matches the bundle pin..."
npm install --no-audit --no-fund

echo "[render] linting composition..."
npx hyperframes lint

echo "[render] rendering main_reel.mp4 (this may take a few minutes)..."
npx hyperframes render --output main_reel.mp4 --quality high --fps 24

echo ""
echo "[render] done: $here/main_reel.mp4"
"""


README_TEMPLATE = """# {title} · Hyperframes render bundle

Generated by `hyperframes-bundle`. Render this on your own machine, then drop
`main_reel.mp4` back into the thread.

## Requirements

- **Node.js 22 or newer** (`node --version`)
- **FFmpeg** on your PATH (`ffmpeg -version`)
- ~2 GB free disk (Chromium gets downloaded by hyperframes on first run)

Install Node from https://nodejs.org (LTS is fine if it's 22+).
Install FFmpeg: macOS `brew install ffmpeg` · Windows `winget install ffmpeg` · Linux `apt install ffmpeg`.

## Render

One command:

```
./render.sh
```

Or manual:

```
npm install                 # first run only
npx hyperframes lint
npx hyperframes render --output main_reel.mp4 --quality high
```

Output: `main_reel.mp4` in this folder.

## Preview in browser (optional)

```
npx hyperframes preview
```

Opens the hyperframes studio with live reload. Edit `index.html`, refresh,
see changes instantly. Re-render when you're happy.

## Troubleshoot

| Symptom                               | Fix                                                                  |
| ------------------------------------- | -------------------------------------------------------------------- |
| `hyperframes: command not found`      | Run `npm install` first, or use `npx hyperframes ...`                |
| `ffmpeg not found` / `Chrome missing` | Run `npx hyperframes doctor`: it tells you what to install          |
| Lint errors about track overlap       | `index.html` already uses alternating tracks 0/1: don't change them |
| Render crashes mid-way                | Low memory. Close Chrome/browsers. Or `--workers 1` in render.sh     |

## Files

- `index.html`: the composition (HTML + GSAP timeline)
- `assets/`: all video and audio assets
- `listing.json`: metadata reference (not used by render)
- `package.json`: pins `hyperframes` ^0.6.89 (muted-audio render fix)
- `render.sh`: the one-command wrapper (also updates hyperframes to the pin)

## Full docs

https://hyperframes.heygen.com/introduction
"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def build_bundle(args: argparse.Namespace) -> Path:
    out = Path(args.output).resolve()
    if out.exists() and args.clean:
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "assets").mkdir(exist_ok=True)

    # --- Load inputs ---
    clips_dir = Path(args.clips_dir).resolve()
    clip_paths = sorted(p for p in clips_dir.iterdir() if p.suffix.lower() in {".mp4", ".mov", ".webm"})
    if not clip_paths:
        raise SystemExit(f"no clips found in {clips_dir}")
    log(f"found {len(clip_paths)} clips in {clips_dir}")

    shot_plan_raw = load_json(Path(args.shot_plan)) if args.shot_plan else [
        {"duration": probe_duration(p) or 5.0} for p in clip_paths
    ]
    shots = normalize_shots(shot_plan_raw, clip_paths)
    total = sum(s["duration"] for s in shots)
    if args.total_duration and abs(total - args.total_duration) > 0.05:
        log(
            f"WARN: shot durations sum to {total:.2f}s but --total-duration={args.total_duration}s. "
            "Proceeding with the shot-plan sum."
        )
    total_duration = total

    # --- Media-length preflight ---
    # Every non-last clip's element plays (slot + xfade_out) of media during the
    # dissolve into the next clip. If the file is shorter, the frame freezes or
    # blacks out mid-transition (the classic "abrupt stop"). Verify with ffprobe
    # when available; hard-fail because this is never recoverable at render time.
    starve_errors: list[str] = []
    probe_available = True
    for i, (src, shot) in enumerate(zip(clip_paths, shots)):
        is_last = i == len(shots) - 1
        raw_xf = shot.get("xfade_out")
        xfade_out = float(args.xfade if raw_xf is None else raw_xf)
        required = shot["duration"] + (0.0 if is_last else xfade_out)
        media = probe_duration(src)
        if media is None:
            probe_available = False
            continue
        if media + 0.02 < required:
            starve_errors.append(
                f"clip {i + 1} ({src.name}): media {media:.2f}s < required {required:.2f}s "
                f"(slot {shot['duration']:.2f}s + dissolve {0.0 if is_last else xfade_out:.2f}s)"
            )
    if not probe_available:
        log("WARN: ffprobe unavailable, skipped media-length preflight. Run qc_bundle.py before shipping.")
    if starve_errors:
        for e in starve_errors:
            log(f"ERROR: {e}")
        raise SystemExit(
            "media starvation: clips shorter than slot + dissolve. Generate longer clips "
            "(8s Veo media for 4-6s slots) or shorten the slot durations."
        )

    # --- Copy media into assets/ ---
    for src, shot in zip(clip_paths, shots):
        dst = out / "assets" / shot["filename"]
        copy_file(src, dst)

    tts_path: Path | None = None
    if args.tts:
        tts_src = Path(args.tts).resolve()
        tts_path = Path("assets") / tts_src.name
        copy_file(tts_src, out / tts_path)

    music_path: Path | None = None
    if args.music:
        music_src = Path(args.music).resolve()
        music_path = Path("assets") / music_src.name
        copy_file(music_src, out / music_path)

    # --- Load overlays + brand ---
    overlays: list[dict] = []
    if args.overlays:
        overlay_data = load_json(Path(args.overlays))
        overlays = overlay_data if isinstance(overlay_data, list) else overlay_data.get("overlays", [])

    brand = dict(DEFAULT_BRAND)
    if args.brand:
        brand.update(load_json(Path(args.brand)))

    # --- Metadata passthrough ---
    metadata: dict = {}
    if args.metadata:
        metadata = load_json(Path(args.metadata))
    metadata["_bundle"] = {
        "title": args.title,
        "total_duration": total_duration,
        "width": args.width,
        "height": args.height,
        "shot_count": len(shots),
    }
    write_text(out / "listing.json", json.dumps(metadata, indent=2))

    # --- Composition HTML ---
    html = build_composition_html(
        title=args.title,
        width=args.width,
        height=args.height,
        total_duration=total_duration,
        shots=shots,
        overlays=overlays,
        tts_path=Path(args.tts) if args.tts else None,
        music_path=Path(args.music) if args.music else None,
        music_volume=args.music_volume,
        tts_volume=args.tts_volume,
        brand=brand,
        default_xfade=args.xfade,
        tts_start=args.tts_start,
    )
    write_text(out / "index.html", html)

    # --- package.json + render.sh + README.md ---
    pkg_name = args.package_name or out.name.lower().replace(" ", "-")
    write_text(out / "package.json", build_package_json(pkg_name))
    render_sh = out / "render.sh"
    write_text(render_sh, RENDER_SH_TEMPLATE)
    render_sh.chmod(0o755)
    write_text(out / "README.md", README_TEMPLATE.format(title=args.title))

    log(f"bundle written: {out}")
    log(f"  {len(shots)} clips · total {total_duration:.2f}s · {args.width}x{args.height}")

    # --- Optional zip ---
    if args.zip:
        zip_path = out.with_suffix(".zip")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in out.rglob("*"):
                if f.is_file():
                    zf.write(f, f.relative_to(out.parent))
        log(f"zipped: {zip_path}")
        return zip_path

    return out


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Build a Hyperframes render bundle.")
    p.add_argument("--clips-dir", required=True, help="Directory of video clips (sorted alphabetically)")
    p.add_argument("--shot-plan", help="JSON list/dict of shot durations (falls back to ffprobe)")
    p.add_argument("--tts", help="Optional TTS narration audio file")
    p.add_argument("--music", help="Optional music bed audio file")
    p.add_argument("--overlays", help="Optional overlays JSON (list of overlay specs)")
    p.add_argument("--brand", help="Optional brand config JSON (colors, fonts)")
    p.add_argument("--metadata", help="Optional metadata JSON (passes through to listing.json)")
    p.add_argument("--output", required=True, help="Output bundle directory")
    p.add_argument("--title", default="Untitled", help="Bundle title")
    p.add_argument("--package-name", help="npm package name (defaults to output dir name)")
    p.add_argument("--total-duration", type=float, default=0, help="Expected total (warn if mismatch)")
    p.add_argument("--width", type=int, default=1920)
    p.add_argument("--height", type=int, default=1080)
    p.add_argument("--xfade", type=float, default=DEFAULT_CROSSFADE,
                   help=f"Default dissolve length between clips in seconds (default {DEFAULT_CROSSFADE}; "
                        "per-shot override via 'xfade_out' in the shot plan)")
    p.add_argument("--tts-start", type=float, default=0.0,
                   help="Delay narration start by N seconds without padding the wav")
    p.add_argument("--tts-volume", type=float, default=1.0)
    p.add_argument("--music-volume", type=float, default=0.25)
    p.add_argument("--clean", action="store_true", help="Wipe output dir before writing")
    p.add_argument("--zip", action="store_true", help="Zip the bundle into {output}.zip")
    return p.parse_args(argv)


if __name__ == "__main__":
    args = parse_args()
    try:
        build_bundle(args)
    except Exception as e:
        log(f"ERROR: {e}")
        sys.exit(1)
