<!-- CreateSkill fields for recreation:
name: hyperframes-bundle-v2
description: Build a ready-to-render Hyperframes video bundle with a deterministic QC gate. v4 fast-cut era: per-shot xfade_out honored exactly (0 = HARD CUT, the v3 falsy-zero bug is fixed), end-card overlay timing derived from the shot plan's last clip, hyperframes pinned ^0.6.89 (muted-audio render fix), render.sh always updates to the pin. qc_bundle.py is a 15-check gate (duration, canvas, conform, black end card, P1 pacing 12+ cuts avg <=3.0s, VO -16 LUFS, music -20 LUFS open-section, A6 duck depth, fade, safe zones) that must exit 0 before any bundle ships. Operator renders locally via ./render.sh.
whenToUse: Step 4b of the Meirvo Producer pipeline (the edit). Use build_meirvo_bundle.py for listing reels after sources are generated, graded (grade_clips.py), sliced (slice_clips.py), and audio is leveled (prep_audio.py v5: VO -16, music -20 ducked). ALWAYS run qc_bundle.py after building and before zipping: exit 0 is the ship condition; preset fast (default) enforces pacing P1 + duck A6. Defaults: vertical 1080x1920, 24fps, per-shot xfade_out from the plan (0 = hard cut), tts-start 1.6s. The black end card (make_endcard.py, 3.0s in v5 plans) must be the final clip. Use build_bundle.py for non-Meirvo projects.
tags: video, hyperframes, gsap, html5, meirvo, render-local
credentialSchema: none
-->

# hyperframes-bundle (v4 fast-cut era, Jun 10 2026)

Build a ready-to-render Hyperframes video bundle that the operator (human) runs locally. The skill does NOT render in the sandbox; it packages clips, audio, overlays, and a one-command `render.sh` into a folder (+zip) the operator downloads, renders, and uploads back.

Hyperframes is HeyGen's open-source HTML-based video framework (github.com/heygen-com/hyperframes). HTML + GSAP instead of React. Apache 2.0. Bundles pin `hyperframes ^0.6.89` (Jun 10 2026 release: fixes muted-video audio leaking into renders and IEEE 754 frame-index boundary duplicates, both directly relevant to this workflow).

## v4 changes (the fast-cut enablement)

| Fix | What was wrong before |
| --- | --- |
| xfade_out: 0 = HARD CUT | v3 read `xfade_out or default`, so an explicit 0 silently became a 0.5s dissolve (0 is falsy in Python). Fast-cut plans rely on 0; only a MISSING xfade_out falls back to the default. Hard cuts render as instant GSAP sets, dissolves as opacity tweens. |
| End-card timing from the plan | The overlay deck hardcoded a 5.0s end card. Now the LAST shot's duration in the plan drives end-card overlay timing, so 3.0s cards (v5 video pipeline) place text correctly. |
| hyperframes pinned ^0.6.89 | "latest" left operators with stale node_modules on old engine versions; the pin guarantees the muted-audio and frame-index fixes. |
| render.sh always installs | The old node_modules guard skipped npm install on re-renders, stranding operators on old hyperframes forever. npm install is a no-op when the pin is satisfied. |
| QC v5: P1 + A6 + music -20 | The gate now FAILS a slow edit (P1) and a non-ducked music bed (A6). A reel that passes everything technical but watches like a screensaver fails here. |

Inherited from v3: 24fps render lock (Veo native; 30 caused judder), media-starvation preflight, single duration truth (timeline length always derives from the shot plan; --total-duration is assertion-only), vertical 1080x1920 defaults, text-align honored, universal overlay fade-outs, IG/TikTok safe zones.

## When to use

- Assembling video segments (sliced Veo outputs, stock, screen recordings) with hard cuts, selective dissolves, text overlays, narration, and music.
- Meirvo listing reels: `build_meirvo_bundle.py` (brand tokens + safe-zone overlay deck pre-wired).

## When NOT to use

- You need the MP4 rendered inside the sandbox (use the v3 ffmpeg fallback in meirvo-video-pipeline-v3).
- Clips are not finalized: generate, grade, SLICE, and conform them first.

## Invocation

First fetch scripts: `FetchSkillScripts({skillName: "hyperframes-bundle-v2"})`.

### Meirvo listing reel (primary path)

```bash
python3 ~/workspace/skills/hyperframes-bundle-v2/build_meirvo_bundle.py \
    --session-dir ~/workspace/{sessionId} \
    --listing ~/workspace/{sessionId}/listing.json \
    --clips-dir ~/workspace/{sessionId}/video/clips \
    --shot-plan ~/workspace/{sessionId}/video/shot_plan.json \
    --tts ~/workspace/{sessionId}/tts.wav \
    --music ~/workspace/{sessionId}/music.wav \
    --output ~/workspace/{sessionId}/render_bundle \
    --total-duration 40.0 \
    --clean --zip
```

Defaults: 1080x1920, per-shot xfade_out from the plan (global --xfade 0.5 applies only to shots that OMIT xfade_out), tts-start 1.6s, tts/music volume 1.0 (audio MUST be pre-leveled by prep_audio.py v5: VO -16 LUFS, music -20 LUFS ducked under VO). `--total-duration` is an assertion that must match the plan sum.

### QC gate (MANDATORY before zipping/shipping)

```bash
python3 ~/workspace/skills/hyperframes-bundle-v2/qc_bundle.py \
    --bundle ~/workspace/{sessionId}/render_bundle --expect-total 40.0
```

15 checks, preset `fast` by default: T1 total +/- 0.05s and canvas, T2 clips muted, T3 media covers slot + dissolve, T4 1080x1920/24fps/yuv420p, T5 black end card (>= --end-card-min, default 2.8), P1 PACING (>= --min-cuts 12 content cuts, avg <= --max-avg-cut 3.0s, longest <= 6.5s), A1 narration ends >= 1s before the end card, A2 VO -16 LUFS, A3 music covers timeline, A4 music -20 LUFS measured on the OPEN section after the VO window (the bed is ducked under narration), A5 music tail fade, A6 duck depth >= 3.5 dB, O1 safe zones, O2 overlay timings. Writes `qc_report.json`. Exit 0 = ship. Exit 1 = fix and re-run; NEVER present a failing bundle.

Legacy bundles: `--preset classic` restores v3 behavior (music -28 whole-file, no P1/A6).

### Generic bundle (non-Meirvo)

`build_bundle.py` with `--clips-dir --shot-plan --overlays --brand --output --xfade --tts --tts-start --music`; same engine, no Meirvo preset.

## Shot plan contract

JSON with `shots: [{duration, xfade_out?, filename?}]`, matched 1:1 to sorted clips. `duration` is TIMELINE seconds (floats fine); composition total = sum of durations. `xfade_out` is the dissolve INTO the next clip: 0 (or 0.0) = hard cut, omitted = global default. Each non-last clip's media must be >= duration + xfade_out (preflight + QC enforce). v5 plans from plan_shots.py emit explicit xfade_out for every segment (0 everywhere except the hook dissolve and the closer-to-end-card dissolve).

## Meirvo overlay deck (safe zones, 1080x1920)

- wordmark: top 232 / right 144, resolved per listing (brokerage then agent_name then "LISTING"), 32-char cap
- address: bottom 460 / left 96, on screen at 0.5s; spec line at 0.9s. Both persist over the first few fast cuts (text riding over cuts reads as intentional).
- end card on the black clip: price (Rust, auto-scale), agent name, CTA, full address, centered; timings derive from the plan's actual end-card length.

## Black end card (mandatory)

A solid #0E0C0A clip is ALWAYS the final clip (clips dir + shot plan). Generate with meirvo-video-pipeline-v3's `make_endcard.py --seconds <plan end_card_seconds>` (3.0 in v5 plans).

## Track layout (lint-clean)

Track 0/1: clips alternate. Track 2: narration (data-start = tts-start). Track 3: music. Track 4+: one track per overlay. All video elements muted.

## Local render (operator)

```bash
cd {bundle_dir} && ./render.sh
```

render.sh runs npm install every time (fast no-op when the hyperframes pin is satisfied; updates the engine when the pin moved), lints, renders at `--quality high --fps 24`. Needs Node 22+, FFmpeg, ~2GB disk. After upload, ffprobe the MP4: duration matches the plan +/- 0.1s.

## Common failure modes

| Symptom | Fix |
| --- | --- |
| build fails "media starvation" | A sliced segment is shorter than slot + dissolve. Re-run slice_clips.py; check the slice report. |
| qc P1 fails | The edit is too slow: fewer than 12 cuts or avg cut over 3.0s. Re-plan with plan_shots.py v5 (it cannot emit a failing plan); a hand-built plan needs more, shorter segments. |
| qc T5 fails | Final clip is not the black end card. Run make_endcard.py, append as last clip + shot entry. |
| qc A4/A6 fail | Audio not leveled/ducked. Run prep_audio.py v5 with --vo, rebuild. |
| end-card text on wrong clip | Shot plan does not sum to the asserted total. Fix the plan. |
| Overlay invisible in render | Do not hand-edit overlays with opacity: 0 CSS. |
| Operator renders with old engine | They edited render.sh back to the node_modules guard. The shipped render.sh always installs; leave it. |
| libnss3.so missing | Operator's Linux lacks Chrome libs (macOS/Windows fine). |

## References

- https://hyperframes.heygen.com/introduction
- https://github.com/heygen-com/hyperframes (pinned: ^0.6.89)