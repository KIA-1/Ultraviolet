<!-- CreateSkill fields for recreation:
name: meirvo-delivery
description: Delivery + transit skill for the Meirvo Producer pipeline. Two jobs: (1) deliver.py packages a session's client deliverables (main reel, MLS copy, IG captions, email, 4 graphics) to the branded page at meirvo.com/delivery/{sessionId}. (2) upload_bundle.py ships the pre-render bundle zip to the OPERATOR as one direct download link under {sessionId}-bundle (Worker v7.7.0: zip allowed, 95MB cap, streaming put). No Drive uploads, no 3-part SaveFile splits.
whenToUse: Two trigger points in the Meirvo Producer pipeline. MID-PIPELINE (end of STEP 4): after qc_bundle.py exits 0 and the bundle is zipped, run upload_bundle.py to hand the operator ONE download link for local rendering; never use Google Drive or SaveFile splits for bundles. FINAL STEP: after the rendered main_reel.mp4 comes back and all deliverables exist, run deliver.py to publish the client delivery page. Requires MEIRVO_INTAKE_SHARED_SECRET (matches Worker's INTAKE_BUCKET_SHARED_SECRET).
tags: meirvo, delivery, r2, cloudflare, producer-pipeline
credentialSchema: [{"name":"MEIRVO_INTAKE_SHARED_SECRET","label":"Meirvo Intake Shared Secret","type":"password","hint":"Same secret as meirvo-r2-signed-urls. Matches the Worker's INTAKE_BUCKET_SHARED_SECRET encrypted Secret in Cloudflare. Used to authenticate server-to-server uploads to /api/delivery-upload.","required":true}]
-->

# meirvo-delivery

Delivery and transit skill for the Meirvo Producer pipeline. Two distinct jobs:

1. CLIENT delivery (`deliver.py`): packages a session's finished deliverables and publishes the branded page at `https://meirvo.com/delivery/{sessionId}`.
2. OPERATOR bundle transit (`upload_bundle.py`, NEW Jun 10 2026): ships the pre-render bundle zip to the operator as ONE direct download link. This replaces the Google Drive attempts (base64 payload limits choke big zips) and the 3-part SaveFile splits (the cat-parts ritual). Never use those again.

## Pipeline position

```
1. meirvo-r2-signed-urls       (fetch agent's uploads from intake)
2. meirvo-listing-copy         (agent writes MLS + IG + email text)
3. meirvo-social-graphics      (4 branded graphics)
4. meirvo-video-pipeline-v3    (plan, generate, slice, bundle, QC)
   4b. upload_bundle.py        <-- OPERATOR TRANSIT (this skill)
       [operator renders locally, uploads main_reel.mp4 back]
5. ffprobe verify the returned reel
6. deliver.py                  <-- CLIENT DELIVERY (this skill)
7. [agent emails the delivery URL via Gmail / flips Airtable Status]
```

## upload_bundle.py (operator transit)

```
RunWithCredentials({
  skillName: "meirvo-delivery",
  command: "python3 ~/workspace/skills/meirvo-delivery/upload_bundle.py \
            --zip ~/workspace/{session}/render_bundle.zip \
            --session-id {sessionId}"
})
```

- Uploads to R2 via the Worker's /api/delivery-upload under the session `{sessionId}-bundle`, so the zip NEVER appears on the client-facing delivery page.
- Prints `downloadUrl` (https://meirvo.com/delivery/{sessionId}-bundle/bundle.zip) + size + sha256. Post that ONE link to the operator with `unzip bundle.zip && ./render.sh`.
- Requires Worker v7.7.0+ (live since Jun 10 2026): application/zip allowed, 95MB cap, bodies over 32MB stream straight to R2.
- v5 fast-cut bundles run 50-70MB. Over 95MB means stray full-length source clips leaked into assets/ (only sliced segments belong); fix the bundle instead of fighting the cap.

## deliver.py (client delivery)

```
python3 ~/workspace/skills/meirvo-delivery/deliver.py \
  --session-id {sessionId} --session-dir ~/workspace/{session} [--strict]
```

1. Scans `--session-dir` for the standard layout (below)
2. POSTs each file to `https://meirvo.com/api/delivery-upload` (X-Meirvo-Secret auth)
3. Prints JSON with `deliveryUrl` + upload results; exit 0 success, 2 on failure

| Local path (candidates in order) | Uploaded as | Content-Type |
|---|---|---|
| `video/output/main_reel_v3.mp4` or `video/output/main_reel.mp4` | `main_reel.mp4` | `video/mp4` |
| `text/mls_description.md` | `mls_description.md` | `text/markdown` |
| `text/instagram_captions.md` | `instagram_captions.md` | `text/markdown` |
| `text/just_listed_email.md` | `just_listed_email.md` | `text/markdown` |
| `graphics/just_listed.png` (or `_1080.png`) | `graphic_just_listed.png` | `image/png` |
| `graphics/under_contract.png` | `graphic_under_contract.png` | `image/png` |
| `graphics/price_improvement.png` | `graphic_price_improvement.png` | `image/png` |
| `graphics/just_sold.png` | `graphic_just_sold.png` | `image/png` |

After deliver.py: agent parses `deliveryUrl`, then (record runs) flips Airtable Status=Delivered and the Airtable automation sends the email; (recordless runs) manual hand-off, nothing auto-sends.

## File limits + security (Worker v7.7.0)

- Per-file cap: 95MB (was 50). Main reels 15-25MB typical, bundle zips 50-70MB.
- Allowed types: mp4, md/txt, png/jpeg, zip.
- Session ID: 8-64 chars `[a-zA-Z0-9_-]`. Auth model: unguessable UUID is the auth; bundle zips live under a separate `-bundle` session namespace.

## Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| HTTP 401 unauthorized | Wrong shared secret | MEIRVO_INTAKE_SHARED_SECRET must match the Worker's INTAKE_BUCKET_SHARED_SECRET |
| HTTP 400 invalid_mimetype on zip | Worker older than v7.7.0 | Deploy KIA-1/meirvo-landing main (commit 8fc245b or later), retry |
| HTTP 413 file_too_large | Over 95MB | Bundle has stray source clips; rebuild with only sliced segments |
| HTTP 503 delivery_not_configured | Worker missing secret | Set INTAKE_BUCKET_SHARED_SECRET in Cloudflare dashboard |
| Delivery page "not found" | No files for that sessionId | Verify uploads; check R2 `deliveries/{sessionId}/` |