#!/usr/bin/env python3
"""
meirvo-delivery / deliver.py

Packages a producer-agent session's outputs and delivers them to the client
via a branded Meirvo page at https://meirvo.com/delivery/{sessionId}.

What it does:
  1. Finds all expected deliverables in --session-dir (main_reel, MLS copy,
     IG captions, email template, 4 social graphics) + any extras.
  2. Uploads each to Cloudflare R2 via the Worker's /api/delivery-upload
     endpoint (server-to-server, auth via MEIRVO_INTAKE_SHARED_SECRET).
  3. Returns the delivery URL on stdout as JSON.

The agent should then email the delivery URL to the listing agent using
the Gmail integration (this script does NOT send email — keeps the script
credential-lean and lets the producer agent compose the email).

Usage:
    python deliver.py \\
        --session-id abc12345-def6-7890-ghij-klmnop123456 \\
        --session-dir /home/sprite/workspace/smoke_session \\
        [--base-url https://meirvo.com]

Expected file layout inside --session-dir (all optional; missing files skipped):
    video/output/main_reel_v3.mp4          → uploaded as main_reel.mp4
    video/output/main_reel.mp4             → fallback if v3 not found
    text/mls_description.md                → uploaded as mls_description.md
    text/instagram_captions.md             → uploaded as instagram_captions.md
    text/just_listed_email.md              → uploaded as just_listed_email.md
    graphics/just_listed.png               → uploaded as graphic_just_listed.png
    graphics/under_contract.png            → uploaded as graphic_under_contract.png
    graphics/price_improvement.png         → uploaded as graphic_price_improvement.png
    graphics/just_sold.png                 → uploaded as graphic_just_sold.png

Credential:
    MEIRVO_INTAKE_SHARED_SECRET — same secret used by meirvo-r2-signed-urls and
    meirvo-r2-upload. Matches the Worker's INTAKE_BUCKET_SHARED_SECRET encrypted
    Secret.

Exit codes: 0 = all requested files uploaded, 1 = usage error, 2 = upload failure.
"""

import argparse
import json
import os
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path


# Maps local-relative path → remote filename that the worker expects.
# Worker's /delivery/{sessionId} page renders by these filenames.
DELIVERY_LAYOUT = [
    # (local_relpath_candidates_ordered, remote_filename, content_type)
    (["video/output/main_reel_v3.mp4", "video/output/main_reel.mp4"],
     "main_reel.mp4", "video/mp4"),
    (["text/mls_description.md"],
     "mls_description.md", "text/markdown"),
    (["text/instagram_captions.md"],
     "instagram_captions.md", "text/markdown"),
    (["text/just_listed_email.md"],
     "just_listed_email.md", "text/markdown"),
    (["graphics/just_listed.png", "graphics/just_listed_1080.png"],
     "graphic_just_listed.png", "image/png"),
    (["graphics/under_contract.png", "graphics/under_contract_1080.png"],
     "graphic_under_contract.png", "image/png"),
    (["graphics/price_improvement.png", "graphics/price_improvement_1080.png"],
     "graphic_price_improvement.png", "image/png"),
    (["graphics/just_sold.png", "graphics/just_sold_1080.png"],
     "graphic_just_sold.png", "image/png"),
]


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def resolve_local(session_dir: Path, candidates: list) -> Path | None:
    """Return the first existing path from candidates (relative to session_dir)."""
    for rel in candidates:
        p = session_dir / rel
        if p.exists() and p.is_file():
            return p
    return None


def upload_one(base_url: str, session_id: str, remote_name: str,
               content_type: str, local_path: Path, secret: str,
               max_retries: int = 3) -> dict:
    """POST raw bytes to /api/delivery-upload. Retry on 5xx, abort on 4xx."""
    url = f"{base_url.rstrip('/')}/api/delivery-upload"
    data = local_path.read_bytes()
    headers = {
        "Content-Type": content_type,
        "Content-Length": str(len(data)),
        "X-Meirvo-Secret": secret,
        "X-Session": session_id,
        "X-Filename": remote_name,
        "User-Agent": "meirvo-delivery/1.0",
    }
    last_err = None
    for attempt in range(1, max_retries + 1):
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                return json.loads(body)
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace") if e.fp else ""
            # 4xx = client error, don't retry
            if 400 <= e.code < 500:
                raise RuntimeError(f"{remote_name}: HTTP {e.code} {body[:500]}")
            last_err = f"HTTP {e.code} {body[:200]}"
        except urllib.error.URLError as e:
            last_err = str(e)
        except Exception as e:
            last_err = repr(e)
        if attempt < max_retries:
            sleep_s = 2 ** (attempt - 1)
            eprint(f"  ↻ {remote_name}: attempt {attempt} failed ({last_err}); retrying in {sleep_s}s")
            time.sleep(sleep_s)
    raise RuntimeError(f"{remote_name}: exhausted {max_retries} attempts; last: {last_err}")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--session-id", required=True,
                   help="Session UUID (8-64 chars, [a-zA-Z0-9_-]). This becomes the delivery URL path.")
    p.add_argument("--session-dir", required=True,
                   help="Root directory containing the session's produced files.")
    p.add_argument("--base-url", default="https://meirvo.com",
                   help="Worker origin (default https://meirvo.com)")
    p.add_argument("--strict", action="store_true",
                   help="Fail (exit 2) if any standard deliverable is missing. Default: skip missing.")
    args = p.parse_args()

    secret = os.environ.get("MEIRVO_INTAKE_SHARED_SECRET")
    if not secret:
        eprint("error: MEIRVO_INTAKE_SHARED_SECRET env var required "
               "(run via RunWithCredentials with this skill's credential configured)")
        sys.exit(1)

    session_id = args.session_id.strip()
    if not (8 <= len(session_id) <= 64) or not all(c.isalnum() or c in "_-" for c in session_id):
        eprint(f"error: invalid session-id '{session_id}' — must be 8-64 chars [a-zA-Z0-9_-]")
        sys.exit(1)

    session_dir = Path(args.session_dir).expanduser().resolve()
    if not session_dir.is_dir():
        eprint(f"error: session-dir does not exist: {session_dir}")
        sys.exit(1)

    # Resolve each expected deliverable → local path (may be None if missing)
    jobs = []
    missing = []
    for candidates, remote_name, content_type in DELIVERY_LAYOUT:
        local = resolve_local(session_dir, candidates)
        if local is None:
            missing.append(remote_name)
            eprint(f"  - {remote_name}: MISSING (looked in {candidates})")
            continue
        jobs.append((remote_name, content_type, local))
        eprint(f"  + {remote_name}: {local.relative_to(session_dir)} ({local.stat().st_size:,} bytes)")

    if not jobs:
        eprint("error: no deliverables found — nothing to upload")
        sys.exit(2)

    if missing and args.strict:
        eprint(f"error: --strict mode, missing: {missing}")
        sys.exit(2)

    # Upload
    uploaded = []
    errors = []
    for remote_name, content_type, local in jobs:
        try:
            eprint(f"↑ uploading {remote_name} ...")
            result = upload_one(args.base_url, session_id, remote_name,
                                content_type, local, secret)
            uploaded.append({
                "name": remote_name,
                "size": local.stat().st_size,
                "contentType": content_type,
                "result": result,
            })
            eprint(f"  ✓ {remote_name}")
        except Exception as e:
            eprint(f"  ✗ {remote_name}: {e}")
            errors.append({"name": remote_name, "error": str(e)})

    delivery_url = f"{args.base_url.rstrip('/')}/delivery/{session_id}"

    output = {
        "ok": len(errors) == 0,
        "sessionId": session_id,
        "deliveryUrl": delivery_url,
        "uploadedCount": len(uploaded),
        "missing": missing,
        "errors": errors,
        "uploaded": uploaded,
    }
    print(json.dumps(output, indent=2))

    if errors:
        sys.exit(2)


if __name__ == "__main__":
    main()
