#!/usr/bin/env python3
"""
meirvo-delivery / upload_bundle.py

Operator-handoff transit for the pre-render bundle zip. Uploads bundle.zip
to R2 through the Worker's /api/delivery-upload endpoint under the session
"{sessionId}-bundle", and prints ONE direct download URL.

This replaces the old fallbacks that annoyed everyone:
  - Google Drive integration upload (base64 payload limits choke >50MB)
  - SaveFile 3-part splits (cat parts | shasum ritual)

The bundle namespace is "{sessionId}-bundle" so the zip NEVER appears on the
client-facing delivery page at /delivery/{sessionId}. Operator-only artifact.

Requires Worker v7.7.0+ (zip mimetype allowed, 95MB cap, streaming put).
Auth: MEIRVO_INTAKE_SHARED_SECRET (same credential as deliver.py).

Usage:
    RunWithCredentials({
      skillName: "meirvo-delivery",
      command: "python3 ~/workspace/skills/meirvo-delivery/upload_bundle.py \\
                --zip ~/workspace/{session}/render_bundle.zip \\
                --session-id {sessionId}"
    })

Output (stdout JSON):
    { "ok": true,
      "downloadUrl": "https://meirvo.com/delivery/{sessionId}-bundle/bundle.zip",
      "size": 61234567, "sha256": "..." }

Exit codes: 0 = uploaded, 1 = usage error, 2 = upload failure.
"""

import argparse
import hashlib
import json
import os
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

MAX_BYTES = 95 * 1024 * 1024  # Worker-side cap (v7.7.0)


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def main():
    p = argparse.ArgumentParser(description="Upload a render bundle zip for operator download")
    p.add_argument("--zip", required=True, help="Path to the bundle zip")
    p.add_argument("--session-id", required=True,
                   help="Base session id; the zip lands under {session-id}-bundle")
    p.add_argument("--filename", default="bundle.zip")
    p.add_argument("--base-url", default="https://meirvo.com")
    args = p.parse_args()

    secret = os.environ.get("MEIRVO_INTAKE_SHARED_SECRET")
    if not secret:
        eprint("error: MEIRVO_INTAKE_SHARED_SECRET env var required "
               "(run via RunWithCredentials with the meirvo-delivery skill)")
        sys.exit(1)

    zip_path = Path(args.zip).expanduser().resolve()
    if not zip_path.is_file():
        eprint(f"error: zip not found: {zip_path}")
        sys.exit(1)

    base_session = args.session_id.strip()
    bundle_session = f"{base_session}-bundle"
    if not (8 <= len(bundle_session) <= 64) or not all(c.isalnum() or c in "_-" for c in bundle_session):
        eprint(f"error: invalid session id '{base_session}' (bundle session must be 8-64 chars [a-zA-Z0-9_-])")
        sys.exit(1)

    data = zip_path.read_bytes()
    size = len(data)
    if size > MAX_BYTES:
        eprint(f"error: zip is {size / 1e6:.1f}MB > {MAX_BYTES / 1e6:.0f}MB Worker cap. "
               "A v5 fast-cut bundle should be 50-70MB; check for stray full-length "
               "source clips in assets/ (only sliced segments belong in the bundle).")
        sys.exit(2)
    sha256 = hashlib.sha256(data).hexdigest()
    eprint(f"uploading {zip_path.name}: {size / 1e6:.1f}MB, sha256 {sha256[:16]}...")

    url = f"{args.base_url.rstrip('/')}/api/delivery-upload"
    headers = {
        "Content-Type": "application/zip",
        "Content-Length": str(size),
        "X-Meirvo-Secret": secret,
        "X-Session": bundle_session,
        "X-Filename": args.filename,
        "User-Agent": "meirvo-delivery-bundle/1.0",
    }

    last_err = None
    for attempt in range(1, 4):
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=600) as resp:
                body = json.loads(resp.read().decode("utf-8", errors="replace"))
                out = {
                    "ok": True,
                    "downloadUrl": f"{args.base_url.rstrip('/')}/delivery/{bundle_session}/{args.filename}",
                    "size": size,
                    "sha256": sha256,
                    "worker": body,
                }
                print(json.dumps(out, indent=2))
                return
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace") if e.fp else ""
            if e.code == 400 and "invalid_mimetype" in body:
                eprint("error: Worker rejected application/zip. The Worker needs the v7.7.0 "
                       "delivery-upload patch (zip allowlist + 95MB cap). Deploy "
                       "KIA-1/meirvo-landing main, then retry.")
                sys.exit(2)
            if e.code == 413:
                eprint(f"error: Worker says file too large ({size / 1e6:.1f}MB). Worker cap may "
                       "still be 50MB (needs v7.7.0 patch).")
                sys.exit(2)
            if 400 <= e.code < 500:
                eprint(f"error: HTTP {e.code} {body[:300]}")
                sys.exit(2)
            last_err = f"HTTP {e.code} {body[:200]}"
        except Exception as e:
            last_err = repr(e)
        if attempt < 3:
            sleep_s = 3 * attempt
            eprint(f"  attempt {attempt} failed ({last_err}); retrying in {sleep_s}s")
            time.sleep(sleep_s)
    eprint(f"error: exhausted retries; last: {last_err}")
    sys.exit(2)


if __name__ == "__main__":
    main()
